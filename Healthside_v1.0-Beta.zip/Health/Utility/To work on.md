- omega 3 vs omega 6
- consider old notes for cold exposure, breath work, sleep, etc.
- seperate water note
- cold exposure how to
- electrical flosser and what toothbrush to use (Routine)
- sunscreen self test
![[Pasted image 20240630073438.png]]
![[Pasted image 20240630074301.png]]
![[Pasted image 20240630074350.png]]
- Experiment raw milk vs non raw milk and schimpeln
- Maybe create note for microbiome
- Protein maybe put metabolism of it there
- Fasting vegetables yes/no? (add more)
- Honey (add more)
- Red light (maybe fusion the red light part of light note with the red light note)
- Difference between risewell normal and pro
# To research:
- watch videos on fish and fish oil
- Training and how muscles grow, what muscles need to grow
- What blood work markers
- finish watching videos about honey
- Hydration and minerals
- vegetables yes/no
- posture (mewing, sitting, sleep)
- Fluoride huberman
- Watch cold exposure videos from huberman - later