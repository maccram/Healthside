---
tags:
  - 📥/📜/🔴
Philosopher: 
type: qoute
---
## The Quote:

## Relevant Context:

## What led me here?