---
tags:
  - 📥/👤
---
> [!meta] Metadata
> keywords:: 
> profession:: 
> how_we_met:: 
> shared_interests:: 
> connection_points:: 
