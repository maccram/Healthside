---
tags:
  - 📥/💭/🔴
aliases:
  - <%tp.file.title%>
type: thought
---
## The Thought:

## Relevant Context:

## What led me here?