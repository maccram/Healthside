# Tooth care:
- Floss
- Toothbrush
### Toothpaste:
- Fygg:
	- US: 
		- https://fygg.com/collections/toothpaste/products/hydroxyapatite-toothpaste
- Risewell:
	- US: 
		- https://risewell.com/products/mineral-toothpaste
	- UK & Europe:
		- https://www.supplementhub.co.uk/products/natural-hydroxyapatite-toothpaste-118ml?variant=41525852176582
		- https://www.amazon.co.uk/dp/B09HGHKFGK?ref=cm_sw_r_cso_cp_apin_dp_2FKX5F11WQ1M3CXM3HRA&ref_=cm_sw_r_cso_cp_apin_dp_2FKX5F11WQ1M3CXM3HRA&social_share=cm_sw_r_cso_cp_apin_dp_2FKX5F11WQ1M3CXM3HRA&starsLeft=1
- Boka:
	- US:
		- https://www.boka.com/products/ela-mint-toothpaste
	- UK & Europe:
		- https://www.amazon.co.uk/dp/B083JHCCV2?ref=cm_sw_r_cso_cp_apin_dp_E9R7KK76AR63H92GZBKS&ref_=cm_sw_r_cso_cp_apin_dp_E9R7KK76AR63H92GZBKS&social_share=cm_sw_r_cso_cp_apin_dp_E9R7KK76AR63H92GZBKS&starsLeft=1
### Other:
- Zellies Gum: 
	- https://zellies.com/collections

# Body Care:
- Dr. Bronners Soap: 
	- https://www.drbronner.com/products/baby-unscented-pure-castile-bar-soap
# Nutrition:

# Tea
NEED TO LOOK MORE INTO IT BUT THATS WHAT I FOUND FOR NOW
- Numi
- Full leaf tea co
- FGO
- Art of tea


- Mouthtape
- Cast pan
- Red flashlight
- Glass container

## Related to:
- [[+Natural Dentist Reveals the CLEANEST Toothpaste on the Planet - Dr. Mark Burhenne]]
## Tags:
  