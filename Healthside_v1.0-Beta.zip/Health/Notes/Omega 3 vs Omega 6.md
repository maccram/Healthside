---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Types of fatty acid
- Saturated fat which is typically solid at room temperature.
- Unsaturated fat which is typically liquid at room temperature.
	- Unsaturated fats can be further divided.
	- Mono unsaturated fats
	- Polyunsaturated fats
		- Omega 3
		- Omega 6

- ![[SaturatedUnsaturatedFats.png|300]]
## Fatty acid in the body:
- Most tissues contain of saturated fat and mono unsaturated fat, that's why we have a increased intake need for those both.
- Polyunsaturated fats are not that highly required but omega 3 is a very good one though.
# Why the ratio between omega-6 and omega-3 matters 
- 100 years ago the omega-6 to omega-3 ratio was around 4:1 or even less. Today we have a average ratio of 20:1 omega-6 to omega-3.
- But some of the oils have even higher ratios like corn with 60:1 and safflower oil 77:1.
- So the ratio should be as little as possible ideally as close to 1:1 ratio.
## The problem:
- Both Omega-3 and Omega-6 are polyunsaturated fats. 
- And they compete for the enzyme (desaturase) to get broken down, this is the real problem cause if you already are loaded up with omega 6 then you can't utilize that much of the omega 3.
- That's why the omega 6 to omega3 ratio is important.
- Also a increase in the omega-6/3 ratio has shown the rise in numerous autoimmune, inflammatory, allergic diseases and all sorts of other health issues.
# Omega 6:
- Omega 6 is not as highly required as omega 3 although it has its right to exist.
- Not all of the omega 6 is inflammatory but most of it is.
## Problems with Omega 6
- One of the main problems is the of it and especially the high amounts of [[Omega 3 vs Omega 6#Linoleic acid|linoleic acid]] (LA) which is primarily in plant based oils.
- The omega 6 fatty acids are also easily oxidized which can cause free radicals to damage the cell membranes and also damage to the mitochondria. 
- Oxidized fats get also trapped in cell membrane and can cause inflammation and poor cellular function.
## Seed Oils:
#### History:
- Actually in the 18 hundreds machines where lubricated with synthetic seed oil.
#### Problems with them:
- When seed oils oxidate its also linked to poor immune system function and increased insulin resistance.
- Especially contain higher amounts of [[Omega 3 vs Omega 6#Linoleic acid|linoleic acid]].
##### The problematic with their production
- For the production of seed oil the food industry often uses chemicals for different purposes. One of the chemicals would be hexane. 
- Furthermore they often use GMO based plants to make the oil.
- Also to process involves the heating of the oils to high temperature which actually turns them rancid. When you heat them often they also become trans and hydrogenated fats which then release oxidized free radicals into our body.
- Sometimes they are even deodorized with sodium hydroxide, carcinogen hexane (known neurotoxin).
## Linoleic acid
- The overconsumption of linoleic acid is pro-inflammatory, pro-allergic, pro-thrombotic state.
- Its also contained in corn fed animal products. But in [[Grass Fed vs. Grain Fed|grass fed]] animal products it is reduced significantly.
- The linoleic acid from the seed oil makes the skin more susceptible to damage of the sun thus higher risk of skin cancer. ^6a8cc8
# Omega-3:
- Omega-3 fatty acids are essential fats that means the body can't produce them in its own.
## The 3 Types:
- There are basically 3 types of omega-3 sources:
	- ALA (alpha linoleic acid): 
		- Primarily in vegetables. Also butter, ghee have it.
	- EPA
		- Only in marine life and some in meat.
	- DHA
		- Only in marine life/algae and some in meat.
- Egg yolks have all 3 of the types.
## ALA conversion into DHA & EPA
- The ALA type is converted into DHA and EPA but that conversion is not that efficient. The conversion only results in 6% of EPA and 4% DHA.  
	- Its also depended on the person some can convert it little better but most won't.
- And its even harder to convert plant oil into the two.
## Benefits of Omega 3
- In general omega 3 has lots of health benefits. From which a big one is overall decreases in inflammation.
- Observations have shown that higher omega-3 intake can lower risk of asthma, eczema and atopic wheeze.
- Also omega 3 favors the growth of short-chain fatty acid producing bacteria.
- Both EPA and DHA also have phosphatidylcholine which protects the cell membrane, this is actually needed for [[How salt impacts our body#Sodium and Neural function|cellular communication]] (Sodium Potassium Pump)
### Benefits of DHA
- DHA is very healthy for the eyes, function of ears, brain function and heart health.
- But that aren't the only effects it decreases blood triglycerides, helps with inflammation, helps with muscle recovery, lowers blood pressure and even protects [[telomeres]]. So it overall decreases mortality.
- Its also very beneficial and essential for toddlers.
### Benefits of EPA
- EPA also has lot of health benefits. It can reduces cellular inflammation also decreases neuro inflammation (it's what causes dementia), it's good for the cardiovascular system and also helps with burning excess fat.
### Omega 3 and Pregnancy
- DHA is one of the components that is beneficial during pregnancy.
- Studies have shown that Omega-3s in pregnancy reduce allergic disease in offspring.
## ALA vs LA
- LA is linoleic acid (omega 6)
	- Increases inflammation
	- It is bad.
- ALA is alpha linoleic acid (omega 3)
	- Decreases inflammation
	- It is not bad.
# What fatty foods to not consume:
- Basically almost all seed oils beside extra virgin olive oil and avocado oil is bad to consume.
- Also you should avoid dressings that contain seed oils.
# What fatty foods to consume:
- Tallow
- Butter
- Ghee
- Coconut oil
- Extra virgin olive oil
	- Best is brand from Italy and cold pressed
    - You need to look at label and see if it is diluted with other seed oils, if so don't buy them.
- Nuts that are low in linoleic acid:
	-  Macadamias
    - Cashew
    - Pistachios
    - hazelnuts
- Fish
	- If you eat fish eat wild caught one
	- Problem with fish is that it often contains heavy metals.
- Meat

==**ALL of the animal products should be from grass fed (grass finished) animals.==**
Why here: [[Grass Fed vs. Grain Fed]]
## Fats to cook with:
- Periodization index gives info when oil is damaged
### Fats you can cook with:
- Tallow
- Butter
- Ghee
- Coconut oil
#### Benefits of them:
- Won't denature when heated
- Not oxidize or get rancid when heated
### Fats to avoid cooking with:
- Don't want to heat olive and avocado oil.
- Olive oil when heated can create trans fats.
# Main take away
# Health conditions related to it
- [[Dandruff]]
- [[Dry Eyes]]
- [[Dry Lips]]
## Related to:
- [[+Polyunsaturated Fats Breakdown- Omega-3’s vs Omega-6’s]]
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]]
- [[+Seed Oils, The Dirty 8 That Are Destroying Your Health - Ultimate Human Short with Gary Brecka]]
- [[+7 Best Sources of DHA & EPA Essential Omega-3 Fatty Acids]]
- [[+7 DHA-rich Foods (And 3 Fakers with NONE) Best Omega-3 - 2024]]
- [[+Do NOT cook with these oils]]
- [[+Omega-3 and Omega-6 Fatty Acids Food Sources and Inflammation]]
- [[+The Best Natural Sources of Omega-3 Fatty Acids – Dr. Berg]]
- [[(The Importance of Maintaining a Low Omega-6 Omega-3 Ratio for Reducing the Risk of Autoimmune Diseases, Asthma, and Allergies]]
- [[(Effects of Omega-3-Rich Pork Lard on Serum Lipid Profile and Gut Microbiome in C57BL6NJ Mice]]
#### Direct links to the Studies:
- Importance of maintaining... : https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8504498/
- Effects of Omega-3 Rich Pork Lard... : https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9708346/
#### Other Resources:
- List of top 200 DHA rich foods https://tools.myfooddata.com/nutrient-ranking-tool/DHA/All/Highest
## Tags:


# NEED TO LOOK INTO FISH OIL FIRST
# Food recommendations
- Foods:
    - Mackerel
    - Fish roe
    - Herring
- - 7 DHA rich foods:
    - ​Egg yolk (29mg)
    - Cod liver (421mg/can), not oil or oil capsules
    - Oysters (620mg/can)
    - Sardines (758mg/can)
    - Anchovies (774mg/3oz)
    - Tuna (1940mg/6oz)
    - Salmon (2477mg/6oz)


- Inexpensive fish oil is often very low quality so he wouldn't consume it
- Virgin cod liver oil is better
- Larger fish are higher in mercury
- The more selenium the less mercury effect in body
- Wheatgrass (kamut) juice has also a lot selenium (supports enzymes for detoxification in liver)
- - Fish oil often gets bad fast
- Better source is krill oil (fish similar to shrimp, won't turn bad that fast)
[[+Why Paul Saladino, MD Quit A 100% Carnivore Diet, Impacts of Cholesterol, And the Value of Insulin]]

- Fish oil seems to turn rancid fast (also oxidces)

# Study 1:

- ![[DietarySourcesOmega-3.png|300]]
- ![[DietarySourcesOmega-6.png|300]]