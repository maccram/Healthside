---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- Theanin not that good before bed if vivid dreams/night terrors/sleep walking
	- Is in green tea
- Tends to stimulate glutamate and Glutamin pathway
- general effect is to compete for the receptors of certain neurotransmitters (all excitetory ones)
- Theanin does decrease alertness a little bit
- 200-400mg of it are effective to offset the jitteriness
- Also data on reduction do depression and anxiety when taking it, also increase in Funktion of blood vessels
- Pro sleep effect when taken before sleep
- Peak of theanin is after a 1h
## Related to:
- [[+Using Caffeine to Optimize Mental & Physical Performance - Huberman Lab Podcast 101]]
## Tags:
  