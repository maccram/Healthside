---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# ==CAUTION: I STILL DON'T REALLY KNOW IF ITS SAFE TO CONSUME RAW DAIRY ALLTHOUGH IT SEEMS SO I WANT TO DO MORE RESEARCH TO KNOW IF IT IS, YOU PROBABLY SHOULD DO THE SAME.==
# Diary and our Ancestors:
- Milk was one of the favorable foods of the human evolution.
- A lot of tribes had milk in their diet.
	- Some had the practice of drinking it combined with animal blood.
- There not only where a lot of African tribes but also some relicts of antient times show that it was already used there.
- There where Egyptian hieroglyphs found talking about it. And there are even findings of the bronze and iron ages where they had clay "bottles" in which they stored milk.
# Evolutionary purpose of milk:
- The purpose of milk in mammals is actually to give all needed nutrients to a small animal/child to grow and gain weight as fast as possible.
# Why to consume dairy:
- Dairy especially raw dairy is a wonder food.
- When we take milk as the example it has a perfect ratio of the 3 macro nutrients (carbs/fat/protein). 
- Milk contains 2500 proteins. Also 400 types of fatty acids.
# Raw vs Pasteurized:
- The high amount of heat with pasteurization denatures proteins (enzymes), breaks down antibody effects, and kills good bacteria. We also kill or harm over 350 fatty acids. Also it gets rid of lactase ([[All about dairy#Lactose intolerance and how raw milk solves it|Benefit of lactase]]).
- However killing off the bacteria doesn't get rid of them so you simple drink the dead bacteria.
## Why we pasteurize dairy
### Brief history
- Basically in the 19 hundreds the hygiene was not good on farms and that's why more people got ill due to the infections through raw milk that's when they introduced pasteurization. Also animals were fed with low quality stuff.
### What pasteurization is for
- The whole pasteurization process is to get rid of pathogens.
- Without pasteurization there is a 20-40% chance of occurrence and with pasteurization there is still a 9-10% likelihood.
#### A natural process that protects us from pathogens
- Raw milk has lot of things in it that keep it from becoming a pathogenic breathing ground.
- The numerous bioactive components that kill off pathogens in the milk (some of them are lactoperoxidase, lactoferrin, leukocytes, macrophages, neutrophils, antibodies, medium chain fatty acids, lysozyme, B12 binding protein, bifidus factor, beneficial bacteria)
- There are also ones that prevent pathogen absorption across the intestinal wall (polysaccharides, oligosaccharides, mucins, fibronectin, glycomacropeptides, bifidus factor, beneficial bacteria)
- Furthermore there are components that strengthen the immune system (lymphocytes, immunoglobulins, antibodies, hormones and growth factors)
- We additionally form also a safety system through fat in the form of medium chain fatty acids and fat-soluble vitamins A and D.
- All this combined protects the body.

==**Important: You always want the best quality of raw milk and pasture raised (more illness in the animal otherwise) this will make the milk saver.**==
###  Benefit of dairy from grass fed animals:
- The grain feeding has an impact on the quality of milk.
- Also the fat in the grass fed milk is higher in CLA and other nutrients.
- More on [[Grass Fed vs. Grain Fed|grass fed vs. non grass fed]]
### Experiment of Raw milk vs. pasteurized milk forming fungus
- 


# Benefits of raw dairy:
- The general benefit is that it contains more of the nutrients due to it being natural and not changed in any way. This leads to a lot of health benefits.
## The Wulzen factor
- The wulzen factor was discovered by Rosalind Wulzen.
- The effect of it is:
	- Anti stiffness in the joints
	- Anti inflammatory 
- Raw dairy is the single best source of MSM which is also good for the joints.
## Benefits for the gut
- With drinking raw milk we generally have a better metabolization. And in addition will have more energy.
### Lactose intolerance and how raw milk solves it
- Pasteurized milk doesn't contain the enzyme lactase which actually helps to break down lactose, however raw milk does.
- Due to drinking the pasteurized milk we also develop a lactase persistency.
- Thus drinking raw milk helps us to better metabolize dairy products containing lactose.
#### Lactose in processed food
- You should be aware that a lot of processed foods also contain lactose in them. Even in things you wouldn't think so.
#### Recommendation for people with lactose intolerance
- Although if you are lactose intolerant and you want to add raw dairy to your diet then begin slowly, a good alternatives that are better to metabolize are kefir and Joghurt (less lactose due to fermentation). They are also both less inflammatory and they provide additional healthy bacteria to the [[How metabolism works#Fiber|gut microbiome.]]
	- Although be aware that yoghurt often is only available in pasteurized form.
- **[[Fermented food|Other beneficial fermented foods for the gut microbiome]]** 
## Benefits for the immune system
- After about 1-2 weeks using raw dairy in your diet you can see changes in the immune system.
- You'll in general strengthen the immune system and also recover better.
## Benefits due to more essential fatty acids:
- After 2-3 weeks you'll also see the effects of better mental acuity and better mood.
- You'll be also less hungry.
## General health benefits
- Lower risks of heart attack
- Also milk intake is correlated with lower risk of cancer
- Reduced risk in diabetics type 2
- Provides lots of protein to keep our muscles
## Benefits of raw milk for children:
- In a study showed children growing up drinking raw milk have less allergic conditions, Asthma, eczema. It also improves there overall immune system.
- Raw cow milk actually has the same protective effect then breast milk for children.
## Benefit of raw milk for breast feeding
- There have been reports that when women who struggled with breast feeding and then drank raw milk where able to improve there ability to breast feed.
# Why IGF-1 shouldn't be a concern
- 

- Thinks igf1 concerns about milk are not really needed
- mTor and igf1 are actually good for humans
# Milk
## Milk and its nutrients
- Milk is literally a power food full of nutrients.
- The nutrients in half a liter of raw full fat milk:
	- 336 calories
    - 17g protein
    - 30g carbs
    - 17g Fat
    - 52% Calcium
    - 28% Vitamin A
    - In general it has lots of B vitamins
	    - 125% Vitamin B12
	    - Also has vitamin B2 (which usually get eighter through dairy or organ meat)
    - 17% Folate (especially good for pregnant women)
    - 20% Potassium
    - [[Trans fats]] (Not all trans fats are the same, in milk its [[Conjugated Linoleic Acid|conjugated linoleic acid]] has positiv effects on body instead of linoleic acid)
    ![[MilkNutrients1.png]]
    ![[MilkNutrients2.png]]
    ![[MilkNutrients4.png|400]] ![[MilkNutrients3.png|400]]
- Source: https://cronometer.com/
## A1 vs. A2 milk
- The difference is in the proteins.
- A1:
	- More inflammatory and G1 problems.
	-  Also A1 could be associated type 1 diabetes (better not feed kids with it)
- A2:
	- Is the better option.
	- It leads to less bloating and digestive inflammation
	- Better for people sensitive with milk
## Colostrum
- Colostrum is basically the first milk a mammal gets from its mother.
- ![[ColostrumVsMatureMilk.png|200]]
- You can drink colostrum without any thought about taking it away from the baby cow cause the female cow tends to always overproduces it.
### Benefits of it:
- Only source of two growth factors
- Beneficial for the immune system and improvement in recovery (also good for wound healing).
## Non animal milk and why its not good
- Study that showed almond milk was related to kidney stone, painful urination and recurring bladder infections.
# Alternatives for milk:
- Raw cheese (Parmesan reggiano)
	- If want raw cheese don't want it to be heated over 38-40 degree Celsius.
- Yoghurt
- Kefir
- raw Butter and ghee
- Other dairy products
# Homogenized Dairy
- Homogenization is when break down fat in little parts. This leads to destroying all 400 types of fatty acids.
# Tools:
- https://www.realmilk.com/
- https://www.realmilk.com/raw-milk-finder/

## Related to:
- [[+Dairy good or bad for humans]]
- [[+Is DAIRY Scary Inflammation & Obesity Concerns - 2024]]
- [[+Should You AVOID DAIRY - GRASS-FED Vs. NON - GRASS-FED]]
- [[+The Fascinating Benefits of RAW MILK Dairy]]
- [[+Here’s What Eating Dairy EVERY DAY Does to Your Stomach Fat, Brain, and Gut]]
- [[+This SUPERFOOD is ILLEGAL All about RAW MILK]]
- [[+Did our ancestors eat vegetables]]
- [[(Safety of raw dairy]]
## Tags:

