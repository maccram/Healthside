---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Dry Lips
## The two reasons for it:
- Lack of essential fatty acids:
	- One reason is the lack of omega 3 which also can come due to [[Omega 3 vs Omega 6|overconsumption of omega 6 fatty acids]].
	- For good omega 3 sources go [[Omega 3 vs Omega 6#What fatty foods to consume|here]].
- Vitamin B2 deficiency:
	- This leads to try lips and eventually also to cracked corners of the mouth.
	- Cause B2 is a anti microbial and you lack it you then can become infected with fissures (candida).
	- Therefore it can be also caused by lack of microbiome.
## Why Vitamin B2 is important:
- Vitamin b2 is actually a co enzyme that has the function of breaking down fats and ensuring that the skin is lubricated.
- Food that has vitamin B2:
    - Eggs
    - Leafy greens
    - Nuts
    - Dairy
    - Meats and fish
- Deficiency can also come from birth control, being vegan and refined foods (especially carbs).
# Chapped lips:
- Chapped lips is kind of a cross over with dry lips. 
- But chapped lips can be combination of deficiency in omega 3 and vitamin d, that's why you often see chapped lips in winter time.
- It also can be caused by a zinc deficiency.
	- Zinc is in red meat and seafood.
- In seldom cases it can also be from a vitamin a overdose which only comes from supplementing it too much.
# The Problem of lip balsam
- The major problem with lip balsam is that it rather does the opposite of what it should do.
- This is due to its ingredients like alcohol/some solvents or mineral oil that pulls oil out of your lips and thus makes them dry. With its the same with [[handcreme]].
- Especially the mineral oil causes disruption in fat suable vitamins and the pulling out of oil. 
## Related to:
- [[+5 Things Your LIPS Can Tell You about Your Nutritional State]]
- [[+How To Fix Your Chapped Lips – Dr.Berg On Remedy For Chapped Lips]]
## Tags:
  