---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What is Lactose
- Lactose is a disaccharides that contains of galactose and glucose.
- It has low effects on insulin.
## Related to:
- [[+Dairy good or bad for humans]]
## Tags:
  