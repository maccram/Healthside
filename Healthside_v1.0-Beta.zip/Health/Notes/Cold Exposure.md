---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What cold exposure can do in our body:
- Water is 29 times more thermal effective then air. This is why its so effective.
- This thermal effectiveness is also why you can die of 22 decree celsius water and not from air.
	- Story of 3 NFL players on fishing trip
## Arteries and cold exposure:
- When you get the cold exposure the arteries will spasm down to clamp all blood and force it into the core and the brain. The increased amount of blood there is already a benefit.
- This basically exercises the smooth muscle by contracting and loosening.
- Smooth muscle is the muscle that lines our arteries. 
- Therefore this also exercises our cardiovascular system.
##  Liver and cold exposure:
- If the exposure was cold enough the liver releases cold shock proteins.
- When these proteins hit the bloodstream they get rid of [[Free Radicals|free radicals]]. In addition they even increase protein synthesis (muscle repair).
## Dopamin and cold exposure:
- When getting cold exposure you'll also release dopamine which will effect you even several hours after the exposure.
## Brown fat and cold exposure:
- Cold exposure also leads to activation of [[brown fat]] (our thermostat).
- Mitochondria has a affinity for it.
- It also helps to burn fat.
# Benefits of cold exposure
- Cold exposure has a variety of benefits like:
	- reduced inflammation
	- increased metabolism
	- it helps to lower blood sugar and benefits insulin sensitivity
	- better mood
	- better focus 
	- improved sexual satisfaction (could be to testosterone increase)
	- improved anxiety regulation
	- It even helped with fat loss
# Cold exposure and exercise
- You shouldn't use a cold plunge in the time of 6h after strength training. This is due to the fact that this then negatively impacts muscle growth. Although cold showers don't affect that. 
# How to do it:
- Before the cold shower/plunge you can do a warm shower before if you want.
- You should expose yourself to 3-6min of 8-10 degree celsius cold water. Actually 3min already has all the benefits.
- You also want to hit the head, back of your neck and your back these is cause there are big amounts of brown fat there.
- Hitting those areas especially triggers the adaptation of brown fat.
- After the exposure you should warm up naturally.
# Cold exposure and Training
## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]] 
- [[+Cold Water Exposure for Fat Burning, Mood Boosts, and More - Ultimate Human Short with Gary Brecka]]
- [[+He Can Predict When YOU DIE How To HEAL Your Inflammation & Fix Your Health - Gary Brecka]]
- [[+Why Gary Brecka Changed his Mind on Keto, Fasting, and 3 other things]]
## Tags:


