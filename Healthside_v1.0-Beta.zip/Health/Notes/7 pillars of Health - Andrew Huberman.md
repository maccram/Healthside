---
"up:": 
tags:
  - 📝/⭐
aliases:
---

# The Pillars
- Sleep
	- Ressources: 
		- [[Sleep]]
- Sunlight & Light exposure
	- Ressources: 
		- 
- Nutriments
	- Ressources: 
		- 
- Exercise & movement
	- Ressources: 
		- 
- Stress management
	- Ressources: 
		- 
- Relationships & Social Engagement (including relationship to self)
	- Ressources: 
		- 
- Oral and gut health:
	- Ressources: 
		- [[+How to Improve Oral Health & Its Critical Role in Brain & Body Health]]
		- [[Oral Health]]