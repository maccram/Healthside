---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What makes normal sunscreen bad:
- Most normal sunscreens contain seed oils.
	- ![[Omega 3 vs Omega 6#^6a8cc8]]
	- There is also oxybenzone/octocrylene/avobenzone in them which is linked to cancer.
# Natural sunscreen
- All the ingredients are not comedogenic meaning they don't cause pores to clog up. In addition the ingredients are all natural so you could even it them.
## Non Nano Zinc Oxide
- This is the natural ingredient that can protect from UVB and UVA.
## How to make it
 - 2tbs bee wax
- 1/2 cup coconut oil
- 1/2 cup of tallow
- Melts those 3 then add the zinc
 - Then put it away from heat and stir it
- To make it more tinted you can add cacao in there

# My self test:
- I wanted to try if it really is that effective so I started a little experiment. 
- There are 3 stripes one is sun exposure without protection, one is with regular sun screen and one is with the homemade one.

## Related to:
- [[+How to make homemade animal-based sunscreen]]
- [[+Natural Sunscreen Recipe – Dr. Berg]]
## Tags:
  