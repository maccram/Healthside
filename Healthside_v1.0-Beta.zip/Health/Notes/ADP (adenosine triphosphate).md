---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- We are not powered by nutrients we eat or by oxygen we breath, we are powered by adp (made in mitochondria)
- 110 trillion mitochondrial