---
"up:": 
tags:
  - 📝/⭐
aliases:
---

To clear out adenosine completely is to spike the cortisol
	    - Chronic cortisol bad, normal one good, enhances the efficientcy of our body
        - Good when released to cycadian cycle so at right time with right amount
        - Late shifted cortisol peak is one marker of depression
        - Want early cortisol peak early in day, can achieve that by getting bright light in eyes (go outside 20-30min is good)
	        - Increased peak when sunlight until 1h of waking

Dr. Lustig-Huberman:
- Increased cortisol (normally antiflammentory) due to sleep deprivation leads to increased inflammation
- Cortisol is good if on right time of day and acutely (late shifted one bad, too much or to frequent bad, you actually need cortisol it's essentially)

## Related to:
- [[+Using Caffeine to Optimize Mental & Physical Performance - Huberman Lab Podcast 101]]
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]]
## Tags:
  