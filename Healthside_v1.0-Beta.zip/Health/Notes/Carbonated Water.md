---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Bohr effect:
- To absorb oxygen by the tissues you need CO2
- That's why when someone is hyperventilating you then give them a paper bag to breath in. they then have more co2 which leads to oxygen being taken.
# Health benefits:
- Increase in activation of parasympathetic nervous system
- Co2 is anti tumor
- Co2 also ant inflammatory
# Natural occurrence of higher CO2
- After thunderstorm you typically get more co2 in air or you also have it in hot springs.
# Carbonated pool:
- Carbonated pools also can be good.

# 
- Could be more acidic though (have to look into that)

## Related to:
- [[+Why You Should Drink Carbonated Water]]
## Tags:
  