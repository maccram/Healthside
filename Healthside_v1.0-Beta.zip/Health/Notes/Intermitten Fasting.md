---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Who should fast
- Its beneficial for most people although if we really want to know if it could be beneficial for us then we should look at data thus [[Blood work|blood work]]. Based on that gathered data ([[Blood work|on glycemic profile]]) you can then narrow the feeding window down.
- On average you should begin with a 12h feeding window and 12h fasting window.
# What is does to the body
 - [[How metabolism works#Fasting|Intermitten fasting actually depletes the gut microbiome]] for the time doing it that's why giving it some good food afterwards is important.
 - More on that [[How metabolism works#Fasting|here]].
 - But the body also eats waste components in the body (autophagy).
# Fasting and our ancestors
- Fasting was used in many civilizations as a way to detox the body. This also is in a lot of religions the case to cleanse the body from the bad.
- Some civilizations that used fasting include the romans, greeks and egyptens.
# Fasting and animals:
- There are also a lot of animals that use fasting.
# How it works:
- Basically we want to restrict our feeding window and push our breakfast back (12h eating window 12h fasting window).
- One rule of thumb can be to not eat and snack when you are not hungry.
- For the meals you usually want to add something fatty to it this helps with not being as hungry.
# Benefits of fasting
- It improves waste elimination, repair, detoxification and regeneration of cells (both fasting and caloric restriction have this effect).
- It also helps with fatty liver. In addition can also beneficial for treating [[Dry & Oily hair|oily hair]].
- Also fasting and time restricted feeding improves metabolic health and overall longevity.
# Water fasting:
- Online guide: https://www.theultimatehuman.com/guides
- 3 day water fast:
	- 0-12h after last meal still digest some food and insulin still little high
	    - We want to be sensitive to insulin cause the less insulin it takes to regulate our blood sugar the longer we life.
    - 12-18h this is when fat burning begins
	    - Body goes into ketosis (fat burning)
    - 18-24h glucagon rises
	    - It counter acts the effect of insulin by stimulating the liver to turn stored glucose into sugars (gluconeogenesis).
    - 24-48h is when real magic happens
	    - waste elimination, repair, detoxification, cellular decision
        - Is called the cleansing part (more clarity in mind)
    - 48-54h more magic happens
	    - Growth hormone is increased
        - HGH is released to repair things
    - 54-72h is where insulin increases its sensitivity
	    - Authpaegy is highest there
        - Stem cells get released in bloodstream and hunt around for damaged/inflamed tissue.
# Side effects and how to solve them
- Some of the side effects of fasting are keto fatigue, keto flu, cramps, thyroid symptoms.
- All that basically means you are sufficient in certain nutrients.
	- Make sure to take B vitamins and electrolytes.
## Related to:
- [[+Fasting for Detoxification and Longevity Ancient Wisdom Meets Modern Science - Ultimate Human Short]]
- [[+The MOST Important Intermittent Fasting Basics for Beginners MUST WATCH - Dr. Berg]]
- [[+Why Gary Brecka Changed his Mind on Keto, Fasting, and 3 other things]]
## Tags:


- Maybe big salad
- Should be eaten in beginning of meal, cause if eat protein first then you are likely filled up already
- Fiber feeds microbiom
- Gives potassium and magnesium (helps insulin, gives energy, prevents cramps)
- For Salat need more but for vegetables less amount