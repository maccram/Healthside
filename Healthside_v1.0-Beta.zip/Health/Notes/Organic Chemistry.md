---
"up:": 
tags:
  - 📝/⭐
aliases:
---

# Antioxidants and reactive oxygen species
- Water in the cells gets incorporated through different proteins, organelles.
- Many of the processes involve the bonding or lack of bonding with water molecules and proteins
- Reactive oxygen species (or free radicals, anti oxidants, all that really describes the presents or absents of charges that are bound or unbound)
- Free radicals can damage cells because they are free electrons. If they are free they can bind to cells and change them causing the damage.
- Cells deal with those free radicals through anti oxidants 
- Antioxidants are molecules that can be in different forms (sometimes vitamins). They bind up free radicals or repair bonds between cells so that the cells don't have the bad influence anymore.
- There is no disease that doesn't have reactive oxygen species involved
- Also no benefit into antioxidant interference getting in the way of the oxidative process
- All learned so far is organic chemistry
- Water can act as antioxidant if it bonds to things in proper way which requires it to go into cells in the right amount and rate therefore the temperature and ph must be correct
- Also there needs to be enough water and it shouldn't contain things that are damaging
- Potentially carring good things in it potassium, sodium
- When water is inside cells then it can interact and change conformation of different proteins and exelerate or slow down different cellular reactions
- Water can effect disease, health, repair of different cells

## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]]
## Tags:
  