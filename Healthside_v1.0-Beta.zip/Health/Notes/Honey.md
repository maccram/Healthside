---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Honey and our Ancestors:
- Honey without doubt is the favorite food of tribes if they found a bee hive they would go crazy for it. 
# Composition of honey
- 60% fructose, 40% glucose
# Benefits of honey
- Honey his a very nutrient rich food it not only contains lots of vitamins but also antioxidants.
- Nutrients that its especially rich in:
	- Vitamin B
	- Calcium, potassium
- All this leads to various health benefits like:
	- Anti inflammatory
	- Anti allergic
	- Anti microbial and has a protective effect against metabolic syndrome.
	- And lowering of blood pressure
	- It might even be able to raise testosterone levels in men.
# Pasteurized Honey
- Similar like with [[All about dairy#Raw vs Pasteurized|pasteurized dairy]] we lose vital nutrients.
- So make sure you get raw honey.
# Honey vs High fructose corn sirup (HAVE TO CHECK THAT)

- Study about response to honey, sugar, high fructose sirup
	- Blood sugar was checked after 20, 60, 90, 120 minutes after ingestion (if want to check then use that)
    - Also checked insulin levels
    - Glucose response was same in all 3 the same (with people with normal glucose Toleranz)
    - Also pretty similar with people with a impaired glucose Toleranz
    - Insulin spike after all 3 also
    - Also triglyceride levels also go up afterwards
    - Also checked hsCRP (inflammation marker) only increased in people with impaired glucose tolerance

## Related to:
- [[+HONEY -vs- High-Fructose Corn Syrup (Is Honey Healthier) 2024]]
- [[+Is Honey a Better Substitute for Sugar]]
- [[+The Health Benefits of Honey – Dr.Berg]]
- [[+Why I Quit The Carnivore Diet]]
- [[+Did our ancestors eat vegetables]]
## Tags:
  