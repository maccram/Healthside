---
"up:": 
tags:
  - 📝/⭐
aliases:
---

# Hydrogen enriched water
 Hydrogen enriched water:
	- You can create it when putting magnesium tablets in water
    - You should drink it 5-15 minutes
    - There is a review on it
    - So basically that all comes down cause the hydrogen also increases the pH which is the real factor
    - Also study on it
    - Reduced inflammation
    - He also drinks it
    - If tap water already has high magnesium then he thinks you don't need to hydrogen enrich the water (although analyze the water and filter out byproducts)
    - To create hydrogen water is to purchase molecular hydrogen tablets which are basically magnesium tablets that resolve in water and create free hydrogen
- Study that explains how it works
- Other magnesium tablets won't work
- Want to do it once or twice a day
- Don't need to do it in all water you drink
- Also don't want to put them into carbonated water, also not hot water

## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]]
## Tags:
  