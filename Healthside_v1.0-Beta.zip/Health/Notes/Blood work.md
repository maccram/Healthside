---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- Look at glycemic profile (glucose, hemoglobin A1, insulin)
		- When more insulin ressistant a narrow feeding window can be benefitial
        - If hypoglycemic then not good
    - So 12h on 12h off is the average
	    - Also Thomas also says same

## Related to:
- [[+Why Gary Brecka Changed his Mind on Keto, Fasting, and 3 other things]]
## Tags:
  