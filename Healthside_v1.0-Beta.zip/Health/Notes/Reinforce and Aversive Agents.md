---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Reinforcers in nature
![[Caffeine#Reinforcer in Nature]]

## Reinforcer vs. Aversive:
- Reinforcer:
	- A reinforcer makes us feel slightly or a lot better.
- Aversive:
	- If something contains a aversive and we feel off with a thing, then the probability of drinking/eating the same thing again is lower, or if its strong enough you won't even like the environment anymore.
	- It makes us feel worse.