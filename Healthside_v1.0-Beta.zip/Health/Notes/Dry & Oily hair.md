---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# The mechanism behind it
- The sebaceous gland is responsible for releasing oil called sebum which lubricates and protects the surface of our skin. ^cfb744
- ![[SebaceousGland.png|200]]
# Dry hair
- One of the major causes is deficiency in fat suable vitamins specifically vitamin A.
- Vitamin A helps regulating the sebaceous gland.
- Also a deficiency in vitamin D and E is playing into it.
## Solution:
- To get the vitamins could use cod liver oil.
- You can get vitamin E from leavy greens, nuts.
# Oily hair
- The major cause of oily hair is low zinc which helps to reduce androgens and DHT.
- DHT is a powerful type of testosteron that can leads to increasing the size of the gland and therefore makes it produce more oil. 
- A other cause is a high level of insulin.
### What leads to a zinc deficiency
- Too many grains
- History of antibiotics
- Eating to much refined carbohydrates
- Digestive problems
- Alcohol
- Diarrhea
- Low HCL (hydrochlorothiazide) this leads zo not being able to absorb zinc and other minerals.
	- Symptom would be a acid reflux
## Solution:
- Reduce as many of problems of zinc deficiency).
- And increase zinc:
	- Seafood (like oysters)
	- Red meat
	- Liver (especially beef liver is high in zinc)
- Also [[Intermitten Fasting|intermitted fasting]] can be beneficial.
## Related to:
- [[+Vitamin Deficiencies that cause dry or oily hair - Dr. Berg]]
## Tags:
  