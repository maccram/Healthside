---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Physics and biology of light
## Physics of light:
- There are a many different wavelengths of light.
	- ![[LightWavelengths.png|400]]
- White light has all of the wavelengths.
- There are also certain wavelengths we can't see like ultraviolet or infrared light.
## Biology of light:
- The biology of light means the conversion of light into signals for the body. This works cause light in its basic form is electromagnetic energy thus that energy can cause reaction in cells of plants, animals and humans.
# How light penetrates tissue
- The different wavelengths can penetrate tissue of the body in different depths.
- Long wavelengths have the ability to penetrate through skin and potentially can even go down to the bone. 
	- Red and infrared light
- On the other hand some shorter wavelengths won't easily penetrate tissues.
	- Blue/green/ultraviolet light
# Light and its conversion into biological events
- The different wavelengths of light are best absorbed by different [[Organelles|organelles]] within the cells. So their function can be stimulated by light.
- This is due to certain pigments/colors in the receiver of light energy that then absorb/reflect the different wavelengths of light.
- So we have eighter a absorption/reflection or passing through of light.
## 3 ways light can affect the body
### Eyes:
- The eyes have photoreceptors on back of it, there are actually two types rods and cones. They both have photo pigments in them.
- Rods:
	- The rods absorb any wavelength of light. In addition they are used in low light conditions.
- Cones:
	- With cones there are 3 types red/green/blue so they can eighter absorb long/mid/short wavelengths of light. They have different photo pigments for that.
### Skin:
- The other place we can use to utilize light is the skin, it's pigment is called melanin. 
- On the top layer of skin we have keratinocytes and melanocytes. The melanocytes create the pigmentation of skin, the way they do it is by absorption of UV light.
### Cells:
- Actually every cell of the body, provided the light can access them can be changed by it in positive or negative ways.
- For the cells that can't get the light directly they'll get it indirectly through the eyes or the skin.

- Basically all starts with absorption of the light through particular pigments of the surfaces the light lands on.
# Fast & Slow effects of light
- Light can affect our biology eighter in fast/moderately or in slow ways.
- A fast effect would be releasing adrenaline when moving from dark to very bright environment.
- A slow integrating effect would be the average light information over a day or over the entire year.
- Also our hormones that are effected by that.
# Melatonin
- In our eye we have a particular cell type called intrinsically photosensitive ganglion cells, they communicate to specific stations in brain which connect to the pineal gland. The pineal gland is there for the production of melatonin.
- When light is absorbed by the ganglion cells this shuts down the production of melatonin by the pineal gland.
## Two type of effects of melatonin:
- Regulatory effects:
    - Positiv impact on bone mass
    - Maturation of gonads during puberty, overview/testes (lowers amount of sperm, that's why you young kids have high melatonin to not get into puberty)
    - Also involved in placental evolvement
    - Powerful impact on central nervous system
    - Effects on waking up and feeling sleepy        
- Protective effects:
	- Can activate the immune system (one of the most potent anti oxidants, anti cancer properties)
- It's the rise and fall of melatonin and duration of melatonin signal that gives these effects.
## Winter vs. Summer
- There are normal changes in melatonin release during the year, that's cause you'll get more/less light (sunlight) each day on average, depending on where you are located. This happens due to the fact that the earth travels around the sun.
- In winter (short days) little light on average is landing on the body's cells so duration of melatonin release is much longer.
- In summer (long days) more light on average is landing on the body's cells so duration of melatonin release is much shorter.
- Therefore in summer months you want more sunlight in your eyes and in winter it can be less, the exception is if you have bad mode in winter.
- If you have depression in the winter months (seasonal affective disorder) it can be beneficial to go outside or to use a bright artificial light source like the Sad lamps.
- And even on cloudy days you'll get more light then from normal artificial light.
## How to optimize Melatonin
- Get proper amount of sunlight each day. The proper amount depends on the time of the year.
## Negative effects of Melatonin supplementation
- Melatonin supplements aren't good cause they have a static effect, meaning it has a full impact right away. Normally melatonin increases dynamically.
- Also most of the melatonin supplements have to much melatonin in them.
# Sleep disruption
- If getting up in the middle of the night, for example to go to the toilet, you shouldn't use bright light , this will destroy your melatonin thus your sleep.
- The trick to bypass this is to eighter dim lights or use longer wavelengths of light (won't impact receptors that impact melatonin).
    - Therefore use Amber colored light or red light.
    - But be aware that any light that's bright enough will shut down melatonin production.
## Keeping your sleep environment dark
- Sleeping 1 night in a moderately light environment can cause increase in night time heart rate, decrease in heart rate variability and increase in insulin resistance on the next morning.
# Light an mating behavior
- The mating behavior is increased in the long days of spring/summer for animals as well as humans.
### Two mechanisms that increase mating behavior
- First one is due to melatonin which can inhibit testosterone and estrogen output from the testes and ovaries.
- The second pathway, actually a [[Parallel pathway|parallel pathway]], is more like an accelerator. It can trigger increase in testosterone and estrogen and desire to mate by exposure to UVB (UV blue light) to the skin, not eyes. 
	- This is cause the skin can be a hormone producing or influencing organ.
- So a protocol for that could be light exposure for 20-30 minutes, in the middle of the day for 2-3 times a week.
- Through that we can also see seasonal changes in testosteron, with in the winter it being its lowest and in summer its highest.
# Light and pain tolerance
- The UVB light can also effect out pain tolerance.
- That also means due to the changing amount of sun exposure over the year our pain tolerance also changes.
- This improved pain tolerance comes from light landing on the eyes and being absorbed, then they signal areas of brain to release endogenous opioids, these lead to a lower perception of pain.
- So its beneficial for people with chronic pain to expose there selves with sun light.
# Light and mood
- Sunlight exposure to eyes can increase mood.
# Light and improved immune function
- When UVB hits our eyes it triggers the activation of the neurons in the sympathetic nervous system (part of autonomic nervous system).
- When enough UVB hit the eyes, a specific channel in sympathetic nervous system is activated. The spleen then deploys immune cells/molecules that combat infection.
# Red/Infrared Light therapy
- Infrared and red light has the advantage that it can pass down to deeper layers of skin where it can change the metabolic function of different cells.
- Shining red light on skin can renew skin cells by first burning off the first layer of skin slightly and then triggering certain biological pathways that then promote growth of new skin cells.
## Benefits of red light therapy:
- Red light therapy can help with treatment of acne, reduction in skin lesions, wound healing, reduction in scars. It also helps with age related vision loss. (beneficial for people older then )
# Sunglasses and blue light blockers
- If you wear sunglasses you will reflect the sun thus not getting the benefit of it. 
- For the same reason you shouldn't wear blue light blockers at daytime. They can be beneficial in the nighttime.
## Related to:
- [[+Using Light (Sunlight, Blue Light & Red Light) to Optimize Health - Huberman Lab Podcast 68]]
## Tags:
  