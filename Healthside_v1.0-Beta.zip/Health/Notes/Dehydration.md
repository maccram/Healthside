---
"up:": 
tags:
  - 📝/⭐
aliases:
---
- There are many studies that show that when we are dehydrated our body and brain doesn't function as well (even 2% has impact)
    - It effects physical performance, cognitive performance (memory, focus, creative thinking, flexible thinking)
    -  Dehydration can show up in brain fog

Salt-Huberman
Dehydration:
    - If drink to much water in short time you can actually kill yourself
    - That's called hyponotrimia
    - The problem is you excrete to much sodium quickly and ability to regulate kidney function is disrupted, and also brain actually could stop functioning
    - If the water doesn't have sufficient electrolytes
    - It's also this why dehydration leads to confusion and lack of coordination
## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]] 
- [[+Using Salt to Optimize Mental & Physical Performance - Huberman Lab Podcast 63]]
## Tags:
  
