---
"up:": 
tags:
  - 📝/⭐
aliases:
---

# Dopamin Stacking:
- Is the stacking of dopamine releasing things (For example caffeine + loud music + intense workout).
- When you stack more then dopamine peak will be higher thus bigger drop below baseline
- So can be good sometimes but shouldn't create a habit out of it cause it will be more difficult to create motivation.
- Also don't stack to many stimuli

## Related to:
- [[+Using Caffeine to Optimize Mental & Physical Performance - Huberman Lab Podcast 101]]
## Tags:
  