---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Breath work in general:
- There are many different types of breathwork. 
- Some sorts of breathwork types are:
	- shamanic
	- vivation
	- pranayama
	- transformational
	- holotropic
# Science behind Breathwork:
- "The presence of oxygen is the absence of disease" - [[@Garry Brecka|Gary Brecka]]
- The importance of oxygen was basically discovered with the Otto Warburg effect. Basically saying [[How metabolism works#Cells and cell doubling|oxygen is closely related to cell function]].
# Benefits of breathwork
- Breathwork therefore has many benefits such as with depression/mood/digestion/ and even increasing the bodies ability to absorb certain nutrients and helping microbiome.
- Overall this combined with [[other tools]] improves longevity.
- Also if you activate your diatreme more you basically exercise it which is also good.

#### **For Instructions on how to do it the best way go [[Tool - Breathwork|here]].**

## Related to:
- [[+Breathwork - Ultimate Human Short]]
- [[+World No.1 Biohacking Expert Tested 100,000 People's DNA. This Diet Will Kill You - Gary Brecka]]
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]]
### Other resources:
- Breathwork guide at: ultimatehuman.com/breathwork
## Tags:
  