---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Fluoride usage:
- Fluoride is actually also found in nature but in very low amounts.
- Basically it's a byproduct of phosphate fertilizer is fluorosilicic  acid, if they would keep it it would kill the plant.
- Then it was discovered that it prevents tooth decay therefore its used in toothpaste, but governments put it into the water supply under the same digues (actually 4 times higher content in water). 
- It's other usages involve medical sterilization, electroplating, Glas etching.
## Why it is preventing tooth decay:
- Fluoride uses a similar approach to a humans normal remineralization process, it also creates these bonds to protect the teeth, but they are much more stronger. Infect Hyperstrong. ^831d44
# Fluoride and it's health risks:
- One factor that makes fluoride bad is that it can cross the [[How salt impacts our body#Blood Brain Barrier|blood brain barrier]] thus directly effect the brain. In addition it causes several toxin effects in the brain and is basically a neuro toxin.
- It also generates free radicals and leads to cause of several pathogenic conditions of the brain.
## Fluoride and cognitive function:
- 52 of 55 studies showed a decreases in child IQ related to the fluoride consumption.
## Fluoride in pregnancy
- Fluoride not only crosses the [[How salt impacts our body#Blood Brain Barrier|blood brain barrier]] it also can cross the placental barrier and can reach the fetal brain.
## Fluoride and the thyroid system
- Furthermore it disrupts our thyroid hormone system.
- The thyroid system has lots of important roles in brain and body. 
# How dangerous is it:
- Even 0.5mg per l of water can effect effect the thyroid hormone T3.
- Toothpaste with fluoride even needs to have a warning lable that says if children under age 6 use more then the typical dose then you need to contact poison control.
- ![[ToothpasteWarningLable.png|300]]
# Studies and their suppression
- The information of 26 studies that confirm the bad health effects of fluoride were suppressed and later released by a court order.
- The program that was suppressed was the national toxicicology program fluoride.
# Conclusion and Solution
- So you want to minimize the amount of fluoride you consume as much as possible.
- So use [[Recommended Products|fluoride free toothpaste]].
- Also ideally you use some sort of [[Water Filtration|water filtration system]].
## Related to:
- [[+How to Improve Oral Health & Its Critical Role in Brain & Body Health]]
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]]
- [[+Is Fluoride Lowering IQs Why Tap Water Needs to Be Filtered From Your Life For Good - Gary Brecka]]
- [[+What is fluoride really]]
- [[+Natural Dentist Reveals the CLEANEST Toothpaste on the Planet - Dr. Mark Burhenne]]
## Tags:
  