---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Importance of Oral Health:
- Brain/Body Health
- Gut health
- Cardiovascular Health
# Teeth
## Anatomy of a tooth:
- Outside Layer is the enamel
- Inside layer is the dentin

- ![[HealthyTooth.jpeg|400]]
# Tooth mineralization:
- Based on mouths pH, thus being acidic or basic, it is either in a demineralization (de min) or remineralization (re min) state. 
- The pH of the mouth largely depends on how much salvia you produce and how mineralized it is.
- If the pH is right, thus not acidic, the bad bacteria will be killed off.
- So our foods pH effects the mouths pH.  [[Oral Health#^7bf097|More on that here.]]
### Saliva:
- Saliva production isn't always the same all day long. There are certain times when there is more and less production.
- In the times where we have more production we have optimal opportunity to have the right pH.
- We have the most production in the morning and during the middle of the day. And have the least amount of production during night time.
- But what can disrupt this production is eating. Thus time restricted eating (intermitted fasting) can be beneficial.
- Based on the reduced production in the night, brushing before going to bed, to remove food particles that potentially can feed the bad bacteria, becomes crucial. Cause we don't have much salvia that can mitigate the bacteria feeding on the food.
## Remineralization:
- It's happening in enamel and dentin layer.
- Through minerals ([[Oral Health#Hydroxyapatite|Hydroxyapatite]]) it forms a robust chain of crystals. These bonds are very strong and protect the tooth. But the acid of the cavities bacteria can break these bonds, if we are in a demineralized state.
- We can solve cavities, if its not already in deeper layers (dentin layer).
### Fluoride:
![[Fluoride#^831d44]]
# How cavities forms:
- Cavities is not caused by any food nor by sugar.
- It forms by bacteria (streptococcus mutants), we receive them like a infection. So we aren't born with it.
- Strep mutants primary feed on sugar, thus also carbs, but if you starve them from sugar they'll also feed on other stuff.
- What creates cavities: 
	- The bacteria creates a acid that then creates holes from outside to inside of the tooth and demineralizes it. The more demineralization we have the faster the cavities can move forward.
- Knowing that our goal is to ensure a remineralized state of the tooth.
- Although the key point is this: ^7bf097
	- **The degree to which mouth is in de min or re min state and the degree to which cavities has the opportunity to form is dependent on the amount of time the mouth is net acidic/alkaline. (No one can avoid the mouth being acidic once in a while)**

- ![[ToothWithCavity.jpeg|500]]
# What disrupts the mouth:
- Alcohol:
	- disrupts oral microbiome, demineralizes
- Stimulants:
	- Everything that contains epinephrin and norepinephrine
	- Changes pH of mouth
	- Promotes mouth breathing
- Mouth breathing:
	- More bacteria can get into the mouth
- Smoking
- Sugar:
	- if eat it then rinse/brush after it
- Mouth wash
- Left food particles
- Acidic food:
	- rinse/brush after it
	- Limit time they are in your mouth
# Gum Health:
- The gum (gingiva) protects the teeth and keeps them stable.
- If bacteria gets through the gum it can lead to periodontal disease which ultimately leads to Alzheimer's disease.
- By tooth health you also support gum health.
# Mouth Hygiene and why we do what:
## Tooth Brushing:
- Main goal break biofilm layer created by the bad bacteria (Step mutants).
- First its plaque and when it gets hard its tatar (yellow tint). Usually tatar needs to be scrubed off by a dentist.
- Dentist polish the teeth cause then it's harder for bacteria to stay on that smooth surface.
## Flossing:
- The main goal is to get food particles out of the spaces between the teeth.
## Tongue Brushing
- Different locations in mouth have different microbiome with good and bad bacteria so does the tongue have one.
- We want to get rid of the bad bacteria there too.

**But for perfect oral health view this guide: [[Tool - Toothcare Routine]]**
# Why Mouthwash is bad:
- The deplete certain things and disrupt the healthy components of the oral microbiome.
- They contain alcohol which itself is not good for the mouth.
- Alcohol based mouthwashes also reduce nitric oxide produced in oral cavity.
- Nitric oxide is important cause it promotes vasodilation (when nasal breath, when oral microbiome is healthy we improve it)
	- It's good for arterial and capillary health
# What to look in a Toothpaste:
## Xylitol:
- It's a low calorie sweetener
- bad bacteria feed on it instead of the other food. It then prevents step mutants from creating acid, and also kills some of them.
- It also reduces inflammation of the gum tissues and other inflammation in the mouth.
- There is also some evidence that it benefits the gut microbiome.

- So there are xylitol gums (1-2 after meal)
	- Also increases production of saliva
    - He has a link in description
## Hydroxyapatite:
- Natural mineral we ourselves produce

 [[Recommended Products|Oral health products recommentation]]
# Fillings:
- Before getting a filling ask the dentist if remineralizing the tooth still would help (that works when caveties is not to deep).
- Metal fillings (Ones out of lead are bad, many metal fillings also contain mercury)
	- Do try to not disrupt those mercury ones avoid mastic gum (thick gum) or hard candy.
# Canker sore
- We can improve or heal it. We can do that by utilizing the link between the oral and gut microbiome.
- What helps is eating low sugar [[Fermented food|fermented foods]] and [[How metabolism works#Fiber|fiber]].
# Dentist visits:
- Twice a year is recommendation
- Routine cleanings are there to get rid of plaque/tatar.
## Related to:
- [[+How to Improve Oral Health & Its Critical Role in Brain & Body Health]]
- [[+Natural Dentist Reveals the CLEANEST Toothpaste on the Planet - Dr. Mark Burhenne]]
- [[Fluoride]]
- [[Tool - Toothcare Routine]]
- [[Recommended Products]]
- [[@Mark Burhenne]]
## Tags:

  