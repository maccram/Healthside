---
"up:": 
tags:
  - 📝/⭐
aliases:
---
- Often even when you have a lot of one nutrient you won't absorb a lot of it due to anti nutrients

## Related to:
- [[+Dairy good or bad for humans]]
## Tags:
  