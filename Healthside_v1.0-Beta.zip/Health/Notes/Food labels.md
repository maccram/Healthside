---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Why its hard to read them
- The basic problem is that food companies can use categories instead of having to mention one ingredient.
- ![[How metabolism works#^bc306c]]
# Worst ingredients:
- High fructose corn sirup:
	- Labeled as all natural sugars, HFCS (shortform, also longform is used), also labeled as corn syrup/corn sugar/natural fructose flavoring/natural flavoring.
 - Sodium nitrate:
	 - Its not a salt
	 - The cancer institute categorized it as not safe.
	 - 
	    - Good is (labels like grass fed/uncured/free range/nitrate free)
- Aspartame which is used as an artificial sweetener:
	- Has effects on behaviorale and cognitive function.
- Partially hydrogenated oils:
	- Are trans fats and they actually don't have to lable it when there is less then half of a gram in it.
	- On the lable look for hydrogenated or partially hydrogenated in front of a oils name.
## Related to:
- [[Food labels]]
## Tags:
  