---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What grounding is:
- Basically with grounding we use the magnetism of the earth.
- We basically stand barefoot on grass/sand/dirt simply on the earth. When then discharge into the earth.
# What grounding does to our body:
- There is a electron exchange so we basically discharge into the earth that leads to changing our electrical field in your body.
- Grounding can have a impact on the body's pH. This is cause pH is potential of Hydrogen so its a charge that therefore can be changed.
- The more acidic we become the more sick we become because disease can't thrive in a alkaline environment.
# Health benefits of grounding:
- When changing the electrical field we also repolarize the surface of your cells.
- Our cells repelling by charge is a positive thing, cause if they instead clump together they lose surface area to interact with nutrients and gases.
- This also helps to get more oxygen in the cell especially into red blood cells.
- It also restores iron channels which act as security to get waste out and nutrients/gases in.
- You also benefit the mitochondria which is there to create ADP.
# How to do it?
- As little as 3-5 min of touching the earths surface barefoot will be enough to change the pH and the polarization of the body.
- You could actually see the difference of the blood under a microscope before and after grounding.
- ![[BloodWithGrounding.png|400]]
# Grounding mattresses:
- Mimic the surface of the earth so basically the same. They are actually connected to the ground wire.
## Related to:
- [[+GROUNDING - Ultimate Human Short]]
- [[+World No.1 Biohacking Expert Tested 100,000 People's DNA. This Diet Will Kill You - Gary Brecka]]
## Tags:
  