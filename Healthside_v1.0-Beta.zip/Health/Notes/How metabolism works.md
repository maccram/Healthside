---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Why a calorie eaten is not a calorie eaten
- If you eat something not every part of it will be used as fuel for the body, there is the part of the food namely fiber that's used by the gut microbiome.
- Also not everything you eat has the same impact on your body.
# Fiber:
- Two types:
	- Soluble
	- Insoluble
- The insoluble fiber forms a jell like fishnet the soluble plugs the holes in it, together they prevent the absorption from the 30 calories, they go further down the intestine to where the micro biome is.
- Feeding your gut (microbiome) is very good cause then the gut will turn it into things like short chain fatty acids which are protective against chronic metabolic diseases.
# Proteins
- If you are eat to much protein, and not utilize it for working out, then the amino acids are turned to organic acid by the liver and this is then used to feed the process that creates [[ADP (adenosine triphosphate)]]. So all this is good.
-  [[ADP (adenosine triphosphate)]] is the chemical energy our body needs to power itself.
- It also takes twice as much energy to prepare protein to burn as it takes to prepare a carb or fat to burn.
- Protein generates more heat.
# Fats
## 3 Fats:
- Omega 3:
	- heart healthy, anti inflammatory, anti Alzheimer's, and basically save your life
	- Don't even get broken down for energy usage cause they are so important and your brain and heart needs them.
- Omega 6:
	- Not good
- Trans fats:
	- Trans fats can't be broken down cause they have double bonds. So overtime they line arteries and the liver, cause chronic metabolic disease and insulin resistance.

- Magarine lined your liver cause couldn't break transfats down
- If olive oil is heated behond cooking point you create transfats
# Carbohydrates
- We can leave galactose out of the equation because it basically becomes glucose.
## Glucose
- Glucose is basically the energy of life. Every cell on the planet burns glucose for energy. It's so important that if you don't consume it your body makes it (that's called gluconeogenesis)
- You need glucose for specific structural changes in proteins and hormones.
- Eating something containing glucose (like beagle) is not necessary a bad thing provided it's in your caloric requirements and it depends on how much you clear and how high the insulin spikes.
### Metabolism of glucose:
- Glucose is basically turned into uric acid which then is in the bloodstream and eventually needs to go out through the kidney.
- If uric acid doesn't go out it can inhibit mitochondrial function and also the enzyme that is there to lower your blood pressure. This leads to higher blood pressure.
## Fructose
- Fructose on the other hand is not needed for life and is like consumable poison. However, just like with alcohol, we have a limited capacity to process it.
- Fructose in nature always comes with glucose.
### Problem with Fructose:
- First of all it can be addictive thus it can lead to overconsumption.
- But the main problem is that it inhibits 3 necessary enzymes needed for normal mitochondrial function. If the mitochondria works at peak efficiency that's metabolic health.
- The 3 enzymes are:
	- AMP kinase: 
		- Tells the liver to create new [[Mitochondria|mitochondria]] in the cell.
		- Fructose basically locks that process without ever unlocking it.
	- ACADL:
		- They prepare fatty acid fot metabolism.
	- CPT-1:
		- Brings fatty acid from outer mitochondrial membrane to inner one so that there can be energy created out of it.
- Fructose is also addictive cause it stimulates the reward center.
### Fructose in fruits:
- Fructose in fruits is not a concern cause it contains only little of it and its also mixed with fiber, the fiber in it mitigates it.
- Out of the fruits berries have the lowest amount fructose in them.
### Metabolism of fructose:
- The intestine will metabolism some of fructose actually 10% of the fructose will be turned into fat molecules (triglyceride) right away these then get into the blood stream. 
- The rest goes will go through the portal vein to the liver.
- Some of 
## Lactose
- Lactose has not much impact on insulin.
# Barriers in the intestine
## Physical barrier
- The physical barrier is a mucin layer. If you won't feed your gut with bacteria it will feed of that mucin layer that's why fiber is so important.
## Leaky gut
- The intestine is basically a big sewer for junk and its job is to absorb the good stuff and put the rest out through the anus.
- The intestine is bound together with proteins which form the barrier, that proteins are called tight junction proteins. 
- If you change the nitrate status of that tight junction the intestine gets leaky that means that some of the junk goes through to your bloodstream this is a leaky gut.
- Fructose nitrates some of the tight junction that's why 93% of americans have leaky gut.
- Leaky gut can also lead to inflammation at the level of the liver. Which ultimately leads to systemic inflammation.
# Fasting
- By [[Intermitten Fasting|intermitten fasting]] you actually deplete the microbiome which leads to bacteria feeding of that mucin layer. But the caveat is that if you then it enough fiber and high quality [[Fermented food|fermented food]] (low sugar fermented) the gut microbiome gets replenished even better then it was before.
- Another reasons intermittent fasting is good is because you give the liver time to offload some of it's fat.
# Why fermented food is good
- [[Fermented food|Fermented food]] is good because of the short chain fatty acids.
- Basically the gut microbiome also turns fiber into short chain fatty acids.
# Insulin and its effects
- 65% of what is ingested is used for resting energy expenditure, 10% goes thermic effective food (fat doesn't have any) and 25% goes to activity.
- When intake glucose you get a big glucose rise in bloodstream and insulin makes it go down. The higher the glucose goes the more insulin you need to bring it down.
- That glucose rise itself also isn't good and leads to health issues like problems with the arteries and kidney disease, because of change in blood pressure. Although the insulin response really makes it all bad.
- Insulin takes whatever you are not burning (blood glucose) and puts it into fat for storage this takes 90min
- If you are active within that 90 min then your muscles will take the glucose as immediate fuel and glycogen storage.
- These insulin spikes are one of biggest factors for metabolic disease.
## Lower insulin 
- If you get insulin down you'll lose weight cause fat will give up its stored triglyceride as soon as insulin goes down.
- To get to low insulin need to get rid of refined carbohydrate, of sugar, increase the fiber, get rid of branch chain amino acids which are in corn feed meat and also in protein powder, if build muscle it's okay.
# Cells and cell doubling
- There are 41 doublings of cells to turn the body into grown state of an adult 36 doublings. Overall an adult has 10 trillion cells.
- 36 of these doublings happen pre natali (before birth) and 5 post natali (after birth). 
- A cell can eighter burn or grow, the signal for that is oxygen.
- This is cause oxygen is signals to the mitochondria to burn. In absence of oxygen the cell only knows to grow.
- Otto Warburg won the nobel prize for that same concept in discovering that in cancer cells.
- It's the insulin rise that drives the growth in the absence of oxygen. Otherwise when you have oxygen you don't need that much insulin cause you burn instead of store.
# Price economics:
## Price elasticity:
- Price elasticity is that if price of a good goes up that should lead to reduction in purchaser consumption because price influences consumption. 
- A example for this is eggs:
	- When egg price goes up by 1% then consumption goes down 0.68% that means the difference so 0.32 is the price elasticity.
- The pendant to it is price inelasticity this means that when price goes up consumption stays the same.
	- This is often seen in fast food, soft drinks, juice. That's because it contains lots of sugar which is consumers are addicted to.
## Consumer economic models:
- First there was the Keynesian economics model this is based on the concept of a rational actor, who can determine value thus utility over cost.
- In 1979 [[@Daniel Kahneman|Daniel Kahneman]] and [[@Amos Tversky|Amos Tversky]] described the irrational actor. The irrational actor is one who can't determine value because he is risk averse thus the cost is always to great.
- Jeffrey Sachs described hedonic actor. The hedonic actor is one who also can't determine value cause it doesn't matter what it costs they need their fix. That's what's happening in the food industry right now.
# Sugar
- Sucrose is the sugar you know like cane sugar or beets sugar
- It consists of one molecule of glucose and one of fructose.
	- Body separates them instantly and then glucose goes to entire body (insulin response) and the fructose goes straight to liver and generates fat.
- High fructose corn syrup is also 1 molecule of glucose one of fructose but they're not bound together.
	- But they both do the same. The only difference is that high fructose corn syrup is easier to add to stuff cause it doesn't crystalize.
## Problem with knowing if their is added sugar:
- The problem is that it is usually difficult to read anything from [[Food labels|food labels]].
- Like sugar has over 262 names for it. So basically the only way to figure out if their is sugar in something is when you have a line for added sugars. ^bc306c
- And you actually don't want anything higher then 4g of sugar per serving.
# The 3 fat depositories
- There are 3 different fat depositories in the body and they all have there own limit. The fast cell itself is not the problem, the problem is that it can't handle the amount anymore.
- First one is subcutaneous fat:
	- Big but fat
	- If you gain 10kg of it you are metabolically ill. 
	- This happens due to the fat cell not being able to handle the amount anymore and basically breaking down this then leads to release of cytokines which a pro inflammatory.
	- This all then drains into the systemic circulation.
- Second is visceral fat:
	- Big belly fat
	- Only need 5kg fat to get metabolically ill.
	- This now drains the cytokines through the portal vein direct to the liver.
	- Actually the fat didn't come from calories it actually came through stress (cortisol).
- Third one is the liver:
	- If you gain 1/4kg of it you are metabolically ill. 
	- If you have fat in liver it causes metabolic disfunction right away.
	- That fat comes from alcohol or sugar.
- Ranking of worst things for metabolic health:
	1. Alcohol and sugar
	2. Stress
	3. Subcutaneous fat which is least important for metabolic health.
# Tools
- There is a categorization system of processed foods that can help choosing products this system is called Nova classes.
- Nova class 4 is the category with the problematic food so you should stay away from those. Anything that has more then 4 ingredients is nova class 4
- Nova class 1 is everything without a need for a food lable.
- The website https://perfact.co:8443/Info/Info.html uses this filter to filter out products.
# Impacts of ultra processed food
- Ultra processed food inhibits growth and hijacks growth of cancer.
- 73% of food in grocery store is consumable poison.
# Inflammation
- A lot of the already mentioned healthier dietary choices can help inflammation so getting rid of fructose, etc.
- Also you should get enough sleep cause sleep deprivation leads to increased inflammation due to increased cortisol.
- Emulsifiers can also create gut inflammation.
# Artificial sweeteners
- Artificial sweeteners block leptin which is the hormone that tells brain you had enough.
- Therefore this makes us hungrier and and blocks the rewards for it.
	- This is due to protection of [[neuron overstimulation]] by [[Dopamin|dopamine]].
# The bad guys:
- [[The modern diet and its problems]]

## Related to:
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]]
## Tags:
  