---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Two types of fermented food:
- The first type of fermented food is wild fermenting foods this means they naturally ferment on their own, examples for that would be sauerkraut or kimchi.
- The other type is a fermented food which is influenced by a starter culture that then leads to the fermentation, examples for that would be kefir, kombucha or yoghurt.
- Basically besides the fermentation technique there are no difference in the benefits of the both.
# Diary based fermented food:
- Diary based fermented food is not only good for the microbiome it also provides a alternative to raw milk and therefore has lots of other [[All about dairy|benefits of raw dairy.]]
## Yoghurt vs Kefir:
- Yoghurt seems to be best source for microbial diversity.
- Kefir is pretty similar to yoghurt but it uses a different starter culture.
	- It is better for people with sensitive gut because it contains galactosidase producing bacteria. These bacteria helps to break down lactose which finally leads to a 30% less lactose content.
### Problem with yoghurt and kefir
- Yoghurt even natural yoghurt is often high in added sugars. The same applies for kefir. 
# Other fermented foods
- Kombucha:
    - There is not really much evidence (only vitro studies).
    - Also has added sugar into it to just create the fermentation effect.
- Sauerkraut:
    - Sauerkraut is an interesting candidate cause it doesn't really show a big effect on the microbiome but it has probiotic effects.
    - Also Sauerkraut juice has a anti oxidant effect due to kaempferol and also increase glutathione (there to repair cells) products.
- Kimchi:
    - Changes the microbiome even if its a similar plant as sauerkraut.
    - Diverse amount of bacteria when starting with the starter culture but after some days it mainly has Leuconostoc bacteria in it.
    - It also had a increases in short chain fatty acid producing bacteria
- Tempeh & Natto:
    - Fermented soy
    - Also beneficial
- Also Pickles can be used.
## How much:
- A few servings per week should do the job.

## Related to:
- [[+The BEST and WORST Fermented Foods for Gut Health (avoid number 3)]]
- [[+Which Fermented Foods Can You Eat on Ketogenic Diet – Dr. Berg]]
- [[How metabolism works]]
## Tags:
  