---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# GLP-1:
- Glp-1:
	- Found in certain caffeinated drinks
    - Benefitial for weight loss, mental performance and controlling blood sugar levels
    - Acts on brain and body
    - Reduces hunger by
	    - activating certain neurons in the hypothalamus
        - And acts on certain receptors on the gut to make us feel full
    - There are animals that use that to not eat for a long time
    - Also drug that intimitates glp-1 (effective against obesity and diabetes, but those should only be used in extreme cases)
    - Promotes thermogenesis (is utilization of metabolic energy)
	    - Beige, brown fat cells are fat cells you want more off (they generate heat, have lot of mitrochondria)
        - Helps convert weight into brown/beige ones
	        - Cold shower has same effect
        - Also raises base energy burning
    - Other ways to release it is fasted exercise and certain formes of exercise

Dr.Lustig -Huberman
Glp1 (acts on brain and gut, decreases rate of gastric emptying)
- Glp1 analogs (used for fat loss, is injected, loose same amount of muscle too so not good)
- These drug causes stomach literally to turn to stone

## Related to:
- [[+Using Caffeine to Optimize Mental & Physical Performance - Huberman Lab Podcast 101]]
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]]
## Tags:
  