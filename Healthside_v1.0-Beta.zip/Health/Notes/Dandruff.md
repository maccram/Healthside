---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What dandruff actually is and how it happens
- Dandruff is actually based on a normal process that is speeded up drastically due to certain factors.
- Normally its a monthly cycle in which the scalp resets.
- Dandruff is basically a overgrowth of a friendly fungus thats part of our normal flora. It's called malassezia fungus.
- The fungus feeds from fats (eats [[Dry & Oily hair#^cfb744|sebum]]). But it only likes saturated fats and eats triglycerides and doesn't like [[Omega 3 vs Omega 6#Omega 6|omega 6]].
- The main cause is that we have a imbalance in the scalp microflora. Therefore also an imbalance between fungal and bacteria.
- But basically the real root cause comes from a disrupted gut microbiome.
## Conventional treatments
- Head and shoulders uses the ZPT chemical which then kills microbes in scalp this means its anti fungal and bacterial. So it not only kills bad bacteria and fungal but also good ones.
	- Actually banned in Europe cause it is toxic for the reproduction organs.
- Antibiotic actually also kills bacteria but the problem is that you also kill bacteria that keeps your fungus under control.
# How to solve dandruff
- Fix the microflora on the scalp:
	- 1tb of kimchi + water and then put that on scalp wait 15min (so you put probiotic back)
	- Other option is 2tb olive oil, 1/2tb coconut oil rub it in then leave over night
	- Apple cider vinegar can also help restore the microflora:
		- 1tb with 16 oz water
		- Can use it once or twice a week
- Fix your diet thus the microflora in the gut:
	- You should go low carb, low omega 6 avoid sugar and add back in some probiotics.
- Optimize your bathroom:
	- Change shampoo
	- Install a Shower filter
## Related to:
- [[+The real cause and cure for dandruff]]
- [[+Use Probiotics for Dandruff]]
- [[+Is it safe to use apple cider vinegar for hair - Dr. Berg]]
## Tags:
  