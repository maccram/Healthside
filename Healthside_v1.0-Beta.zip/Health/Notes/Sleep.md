---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Basic facts
- We on average spent 25 years of our life sleeping.
- People who sleep 6 1/2 to 7 1/2 tend to live the longest
- Average person needs 10-15min to fall asleep (if just in under 5min then you probably where sleep deprived)


- Blue light reduces the production of melatonin
	- Also reduces the amount of time in rem phase, which is needed for cognitive function
- Before bed dim light
# Making your bed to your sanctuary
- Don't use your bedroom as your work room.
# The importance of a night time routine
- It's important to have a night time routine that can help you wind down and prepare for sleep. It also acts as a signal to the brain. This goes hand in hand with [[Sleep#Making your bed to your sanctuary|making your bed to your sanctuary]].
- Good habits for night routines are:
	- Bed time tea
    - Warm baths
    - Stretching
    - Breathing exercise (Best to use is box breathing it brings you in a relaxed state)
    - Journaling to get your thoughts out
# The 12 3 2 1 0 Rule
- 12h before sleep no caffein
- 3h before sleep no food or alcohol
- 2h before sleep no more work
- 1h before sleep no screen time
- 0 times hitting the snooze button
	 - That extra minute won't help you and will rather have a negative effect on you.
# Caffein and sleep

# Melatonin

# Red light and sleep

# Sleep and effects on health

# Problems sleep deprivation leads to
- Sleep deprivation leads to the body's functions being disrupted.
- Has negative effects on gut and oral microbiome.

## Related to:
- [[+Sleep - Hacks, Supplements, and Routines for Better Sleep - Ultimate Human Short with Gary Brecka]]
## Tags:
  