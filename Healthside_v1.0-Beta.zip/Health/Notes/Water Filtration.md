---
"up:": 
tags:
  - 📝/⭐
aliases:
---
Boiling water will not help with the containment cause some are made even worse through it

# Filtration of Water
- Look for water filtration system best would be reverse osmosis
- At least get chlorine and fluoride out of water
- After its been under reverse osmosis add minerals back in water (Celtic salt)
- He does hydrogen water after the reverse osmosis
- There is all sorts of flouride free toothpaste

- If have the money for filtering system stage 4 one get one and add back minerals with baja gold sea salt salt or Celtic salt to remineralize the water
- - It's hard to filter out fluoride without reverse osmosis
- Also with showering it's not good

## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]] 
- [[+Is Fluoride Lowering IQs Why Tap Water Needs to Be Filtered From Your Life For Good - Gary Brecka]]
- [[+What is fluoride really]]
## Tags:
  
