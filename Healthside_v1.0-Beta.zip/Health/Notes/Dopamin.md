---
"up:": 
tags:
  - 📝/⭐
aliases:
---

Chronic overstimulation of neurons leads to neuronal cell death but the exitetory neuron has a plan b, it down regulates the dopamin receptor (less chance of dopamin molecul will find receptor to bind to)
- You get hit, rush, receptors go down, next time bigger hit, until huge hit to get nothing that's tolerance, and when the neurons start to die that's addiction
- A neuron needs energy (most energy depend tissue in the body)

Have old notes on it
[[Dopamine Stacking]]

## Related to:
- [[+Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast]] 
## Tags:
  