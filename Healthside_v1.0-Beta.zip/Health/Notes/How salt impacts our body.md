---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Basic facts:
- Salt = Sodium
- 1g Table salt = 388mg sodium
# The sensing of Salt
- Little Clusters of Neurons that can sense salt. These sense the salt content in the bloodstream, in response it sets of certain events that make you eighter want to drink more or stop drinking.
- And when seeking water you not only seek water you also seek salt (sodium).
## Blood Brain Barrier
- Prevents certain substances to enter the brain, to protect itself from injury.
- Injury for the brain is especially bad cause it can't heal itself.
	- Also a similar barrier in the testis and ovaries (Assumption there is protection of genetic material)
- The only molecules that have access to the brain are small and critical molecules.
- Some regions of brain have a weaker/stronger fence around then
## Two types of thirst:
- Osmotic thirst:
	- Concentration of salt in bloodstream
	- Vasopressin regulates Urin release
- Hypovolemic thirst:
	- When drop in blood pressure.
	- Causes are blood loss, Vomiting or diarrhea.
# Kidney
- There for release of substances (glucose, amino acids, urea, uric acid, salt, potassium, magnesium)
- The kidney is like a knowledgeable filter and filters out things based on the body's demand.
- Urin basically is filtered blood.
- When we are thirsty the kidney gets told by the vasopressin to not release fluid, although when there is enough fluid its the other way around.
# Vasopressin:
- Prevents fluid to go from kidney to bladder. Therefore its a anti diuretic.
# Salt and Stress:
- Adrenal glands make glucocorticoids (Also stress system) which effect the fluid balance and partly they do that by regulating craving and tolerance of salt we have
- Study with mice where removed adrenal glands and the mice where much more tolerant with the amount of sodium intake.
- It showed that low sodium = increased stress/anxiety
# Other electrolytes:
- For [[magnesium|Magnesium]] there are lots of different forms
- [[Potassium]] goes hand in hand with sodium (2:1 ratio recommended)
# Diets and there impact on sodium
- For low carb diets you'll excrete more water and also lose sodium and potassium.
- The same goes for intermittent fasting.
## Caffein and excretion of Urin:
- It's a diuretic (pee more)
- For every oz coffee/tea 1.5 more water
# How much Salt needed:
- Depends on different Factors:
	- level of blood pressure
	- Diet
	- fluid intake
	- caffein
	- electrolytes
	- environment (hot/or cold which is dry)
- 2g up to 4.5-5g, More then 7g bad
- Best to hear on craving but before that stop eating a processed diet.
- For workouts you can use the [[Water#^2b3f31|galpin equation]].

- From Book "The salt fix"
	- 3.2-4.8g sodium (8-12g salt per day)
# Salt and Sugar:
- Basically neutralize each other and therefore its used in food industry to make you eat more
# Sodium and Neural function:
- Without sodium our neurons wouldn't function and we would be dead
- If drink to much too fast, thus you are deficient in sodium you'll die
- Also therefore if dehydrated you are often disoriented and confused
- ![[NeuronUnstimulatedSalt.excalidraw]]
- ![[NeuronStimulatedSalt.excalidraw]]
- Sodium potassium pump stops the process (restores charge)

## Related to:
- [[+Using Salt to Optimize Mental & Physical Performance - Huberman Lab Podcast 63]]
## Tags:
  