---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- Most Infrared sauna don't get hot enough to trigger effects on growth hormone and heat shock proteins and other benefits saunas are known for.

## Related to:
- [[+Using Light (Sunlight, Blue Light & Red Light) to Optimize Health - Huberman Lab Podcast 68]]
## Tags:
  