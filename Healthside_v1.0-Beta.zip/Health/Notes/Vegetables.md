---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Vegetables and our ancestors
- Our ancestors usually not ate any vegetables except they where starving.
- So it was more like a fallback food for them
# What's the issue of Vegetables
- The issue with vegetables is that most vegetables contain [[Anti Nutrients|anti nutrients]] which inhibit the absorption of good nutrients. And also some vegetables can cause inflammation.
- Often symptoms of not being able to really handle vegetables are gut issues and autoimmune disease.
- With vegetables it really depends on how you thrive with them, if you thrive then you can use them if not then cut them out.
- Also some vegetables accumulate a lot of [[Heavy metals|heavy metals]] when grown in soil that has heavy metals in it.
- Also you could get the same nutrients in better and higher amount from meat/organ meat/[[Fruits|fruits]] and [[All about dairy|raw dairy]].
# Fiber in vegetables might not be that important
- Some studies suggest that vegetable fiber isn't actually that effective for gut health.
- Some studies show there is no change in alpha diversity. So it doesn't have big impact on [[|microbiome]] diversity
- Although high fermented foods had increased microbiota diversity and decreased inflammatory markers. 

**HAVE TO LOOK INTO THIS**
- Discord says some vegetables okay

# Also a difference between starches

## Related to:
- [[+Are vegetables really bad for us]]
- [[+I Was WRONG About Veggies (Plant Problems) 2024]]
- [[+Did our ancestors eat vegetables]]
- [[+Do we need vegetables for a healthy gut]]
- [[+Paul Saladino Added Rice & Potatoes to His Diet (and this happened)]]
## Tags:
  



