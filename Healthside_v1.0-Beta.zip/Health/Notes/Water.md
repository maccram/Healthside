---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Chemistry of water:
 - H2O is polarized that means it has a negative charge on the oxygen and a positiv one one the two hydrogen.
 - Positiv and negative connect.
- ![[WaterChemistry.png]]
- The different arrangement of water molecules is highly depended on Temperature.
## Physical states of water:
- 3 of water (liquid, gas, solid)
- Other then other things water is less dense in it's solid state, that why ice is able to float. If that wouldn't be so then life probably wouldn't exist.
- It's cause there is a very thin layer on the water surface that is more dense. 
### 4th state of water:
- The 4th state is called structured water
- In presence of certain solids/liquids the water molecules can change, so that the positive molecules attract one another.
- These bonds are not as strong as water in it's solid state.
- Example of structured water is water being like a bubble on a glass surface or water sticking to a car window when it rains.
## Dissolving with water
- Water is one of the best dissolvents, its even better then acid.
- The substances that are hydrophilic, that means they have a tendency to mix with water.
- On the other hand Lipids (oils) won't easily dissolve cause they are hydrophobic, so they have tendency to repel from water.
# Water absorption of our body:
- Every cell in our body needs water.
- We can get water through drinking and also through inhaling humid air.
- The water moves from the stomach to the bloodstream and finally to the cells.
## Ways of absorption:
- There are two ways water can access cells:
	- First way is diffusion: 
		- The outside of most cells is out of lipid (fat), water and that lipid alter just so that they can connect and the water can be dissolved, this is the slow approach.
    - Second way is by aquaporin channels: 
	    - This are portables through the membrane where the molecules can pass through (1 million water molecules per second), the inside of those channels is very hydrophobic (water repulsive). This is the faster approach.
		- ![[Aquaporin.png|300]]
- The reason of two ways is that there are certain tissues that need to take or release water more often and also very quickly (tear glands, gut). 
- But most cells have these channels, only ones not having them are bones and ligaments.
# How pH and temperature effects us
- Temperature and pH can heavily effect the movement of water through this aquaporin channels thus the absorption of water.
## Effects of pH in water:
- The pH of water has impact on how good we can absorb and utilities water.
- The more alkalin (pH>7.4) water can be absorbed more quickly. But we don't necessarily need high pH water to hydrate the body well.
### Myths of pH in water:
- A big myth is that the pH of water directly affects the pH of body is wrong. It only changes the absorption rate of the cell.
## Hard water:
- Hard water contains more magnesium and calcium this effects the pH of it, the higher the concentration of those two the higher pH.
- This higher pH therefore better absorption of water has positive effects on cardiovascular health.
## Effects of temperature of water:
- Temperature affects rate of absorption and impact on cells/tissues/organs.
- Cold water will resort in a slower to absorbtion.
- Can by temperature or filtering of water can affect the rate of absorption of water in the gut.
- This will reduce inflammation and also makes sure you get proper hydration of different cell types in the body.
# The pH levels in the body:
- The pH of the body itself (pH of cells at different locations) is pretty stable and doesn't change that much. The process for that regulation is Homeostatic regulation.
- Although some cells can have different pH, for example the gut has a very different pH.
# Hydration
### Baseline hydration:
- For every hour awake in the first 10h of the day you should consume on average 8oz (240ml) of fluid. So total amount would be 2.4 liters in the first 10h.
- We take the 10h in consideration cause that's when the kidney is mostly active, in the nighttime it downregulates its function.
### Galpin Formular:

^2b3f31

- The galpin formular is used when exercising:
	- bodyweight in pound/30 = number of oz fluid to ingest every 15-20min on average while exercise
- In metric system:
	- 2ml per kg bodyweight every 15-20min
### Special cases:
- Exercising in hot environment:
	- Double galpin formular.
- Sauna:
	- Double baseline intake (16oz).
- If feeling dehydrated
	- Then you can drink more like 16oz per hour while feeling dehydrated.
	- Avoid diuretics (increased fluid excretion)
### Problem with Thirst as a guide for dehydration:
- Thirst is a reasonable guide for when we are dehydrated but it doesn't really keep up with our bodies level of dehydration.
# Water and cells
- Water can act as antioxidant if it bonds to things in proper way. Which requires right amount and rate of absorption of water to the cell therefore the temperature and pH must be correct.
- Through that water can effect disease, health, repair of different cells.
# Fluid and alertness:
- Fluid intake elevates alertness it's due to the sympathetic arm of the autonomic nervous system that's the aspect that makes you more alert.
- When we have fluid in gut, cells are well hydrated and our bladder contains fluid there is a elevated activation of the sympathetic nervous system by two pathways:
	- Mechanical: 
		- Sense stretching of tissue in gut and bladder.
    - Chemical level:
	    - Sends info to areas of brain associated with sympathetic arousal which makes us more alert, that's what wakes us up from sleep if we need to pee.
- This alertness also translates to enhanced cognitive/physical function.

# Filtration of fluid by kidney
- The process of filtration of fluids in the body is highly depended on the body's circadian cycle depend.
	- Especially kidney and the gut are strongly influenced by it.
	- That's why the kidney is most active in the first 10h after waking.
- In addition the rate of filtration of through the kidney doesn't depend on the volume ingested but on the rate of ingestion. Thus drinking faster, faster excresion.
# Tap water
- DBP's in water:
	- DPB's (disinfection byproduct) are byproducts of chemicals used to disinfect water in water treatment facilities.
	- These byproducts strongly effect the pH of water by changing the concentration of magnesium and calcium.
	- They also can cause endogene disruption which is not good for reproduktiv health.
- Flouride:
	- Fluoride is also in tap water and is not really beneficial for our health.
	- If you have the possibility to check the concentration of it in your area then check it.
		- Google water analysis and zip code

- Other sources for disruptions are the pipes and the faucet mash.
# Water types
- Distilled and double distilled water:
	- In that process also magnesium and calcium is removed so that's not good. Therefore it's better to not drink it.
- Reverse osmosis:
	- Is a good way of filtering water it also still contains magnesium and other minerals, although it decreases them.
- Deuterium depleted water:
	- Water near sea level has more deuterium in them.
	- Deuterium means the enrichment or lack of hydrogen in the water.
- Electrolyte reduced water/hydrogen rich water/hydrogen enriched water/deuterium depleted water all have the property of having higher pH then other forms of water.
## Related to:
- [[+How to Optimize your water Quality & Intake for health - Huberman Lab Podcast]] 
## Tags:
  