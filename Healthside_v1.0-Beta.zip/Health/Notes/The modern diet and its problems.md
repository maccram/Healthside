---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# The basic problems of the modern diet:
Before ever starting to really optimize your nutrition you should understand the basic problems we are fighting against. 
This is best done by understanding of how the body works: [[How metabolism works]].

With that knowledge you can then decide what diet you want to chose and what suits you best.
Also its key to always listen to your body and also get data (blood work) to see the differences. 

**There is no such thing as one size fits all, every human is individual.**

## The Bad guys with diet:
These are the types of foods that every individual should cut out.
- Ultra processed food with carbohydrates
	- Not every carb is the similar. Pasta is not berry.
	- The problem with it is not the carb itself its the high insulin spike that comes with it.
	- Go here to find out more: [[How metabolism works#Carbohydrates|Carbohydrates]], [[How metabolism works#Insulin and its effects|Insulin]]
- Sugar and added sugar
	- It's basically consumable poison. The body doesn't need sugar (fructose, sucrose).
	- However it is strongly used by the food industry to make you addicted to their products.
	- Go here to find out more: [[How metabolism works#Fructose|Fructose]]
- Omega 3 vs omega 6 ratio being disrupted 
	- Our omega 3 to omega 6 ratio inflated drastically over the last hundred years. We are at a ratio of 20:1 (omega 6 to omega 3) but actually should be near to 1:1.
	- Go here to find out more: [[Omega 3 vs Omega 6]]
- Seed oils:
	- Basically the reason why omega 6 to omega 3 is disrupted is basically due to seed oils. 
	- They also contain linoleic acid which is also bad for the human body.
	- Furthermore they also often undergo multiple chemical processes when being made.
- (Vegetables:)

## Related to:
- [[How metabolism works]]
- [[Omega 3 vs Omega 6]]
## Tags:
  