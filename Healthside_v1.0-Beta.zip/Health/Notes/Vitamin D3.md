---
"up:": 
tags:
  - 📝/⭐
aliases:
---


   Using light-huberman
- People with darker skin need more vitamin d3 (cause of darker skin you have more melanocytes so more light absorbed)
## Related to:
- [[+Using Light (Sunlight, Blue Light & Red Light) to Optimize Health - Huberman Lab Podcast 68]]
## Tags:
  