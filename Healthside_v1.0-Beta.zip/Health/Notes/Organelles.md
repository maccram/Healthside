---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- Organelles are different compartments and functions in cells

## Related to:
- [[Light and its Health benefits]] 
## Tags:
  