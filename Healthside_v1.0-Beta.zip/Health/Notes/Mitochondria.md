---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- We have organell called mitrochondrial in cells (we have 110 trillion of these in body, actually 10% of body weight is actually mitrochondria)
- Inside mitrochondria there's a little motor its called the Kreb cycle (its what generates ATP)
- ADP is the actual life force as humans
	- The more adp the more energy our system has at a cellular level

[[ADP (adenosine triphosphate)]]

## Related to:
- [[+Recover Faster, Fight Neurological Issues & Reverse Signs of Aging with Red Light Therapy]]
## Tags:
  