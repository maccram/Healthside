---
"up:": 
tags:
  - 📝/⭐
aliases:
---

- Green tea is good cause helps insulin resistance
- Other good ones are cinnamon, Garcinia, ginger, ginseng
## Related to:
- [[+The MOST Important Intermittent Fasting Basics for Beginners MUST WATCH - Dr. Berg]]
## Tags:
  