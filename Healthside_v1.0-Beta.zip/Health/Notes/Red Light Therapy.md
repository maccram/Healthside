---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# The science behind red light therapy
- We are very photovoltaic beings
# Benefits of red light therapy
- It has effects on:
	- Reducing inflammation (also in brain)
	- increasing microvascular circulation 
	- benefiting the immune system
	- good for wound healing (therefore good for post surgical repair)
	- beneficial for the lungs and the spinal chord
	- It has also been shown that red light therapy before exercise can improve recovery.
	- Anti depressant effects
	- improved collagen elastin/fibrin
	- hair follicle restauration, thickening them and allowing to get more nutrients to the roots.
	- positive effects on Parkinson
	- Also 15min of red light can reduce blood glucose levels
# Red light panel
- Usually red light panels are very expensive especially the good ones. 
- When buying one though its important to have one that is able to hit certain wavelengths to get the full benefits. Because different nanometers of light have different effects on the body.
	- It should have the 680-720 nanometers, and specifically should have the 810 and 940 nanometer one.
# Mitochondria and red light
- Certain wavelengths of red light are even able to go down to the [[Mitochondria|mitochondria]].
- This then kicks out mitochondrial nitic oxide and lets oxygen instead dock to it. This docking of oxygen leads to 16 times more efficiency in creating energy. 
- This overall is a very beneficial thing.
- Would also see the effect with nitric oxide test strips when you put them in the mouth.
# Natural source
- You also can get some of the benefits of it by sunlight. Furthermore [[Sunlight|sunlight exposure]] in general is a very beneficial thing.
# How to do it:
- If you use red light therapy then use it for minimum 10 minutes and if you are able to then 20 minutes.
- Also alternatively some gyms or spas offer red light therapies.

## Related to:
- [[+Recover Faster, Fight Neurological Issues & Reverse Signs of Aging with Red Light Therapy]]
- [[+He Can Predict When YOU DIE How To HEAL Your Inflammation & Fix Your Health - Gary Brecka]]
- [[+Gary Brecka’s 8 Methods to Increase Longevity on a Budget]]
- [[+World No.1 Biohacking Expert Tested 100,000 People's DNA. This Diet Will Kill You - Gary Brecka]]
## Tags:

Maybe put red light part out of light and its health benefits to here