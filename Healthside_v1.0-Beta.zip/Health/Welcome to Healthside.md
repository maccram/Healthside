This is a website where you can learn everything about health. 
**But always still do your own research and form your own opinion.**

All the notes come from my personal research (**SOURCE NOTES**). Based on that information i created the actual **NOTES** which contain the **WHY** and **HOW**. Last i also created **TOOLS** which are simplified action plans.
## How to use the website:
If you aren't familiar with Obsidian then here is a short introduction that you get on what this is based on. Obsidian is a note managing program where you can use links to link notes together, just like you have in Wikipedia. 

The notes are stored in a so called vault. You can download the Healthside one here:
### The interface:
![[Interface.png]]


# How to start exploring
Here are the notes that are best to start with, but feel free to immerse yourself in any topic of interest.
## Basics:
- [[Our Ancestors - Where they really as healthy as we think?]]
- [[The modern diet and its problems]]

Also feel free to also look at the **Tools**.
## Advanced:
Most of the advanced stuff is just the basic natural stuff in form of a device. It should be seen more as add on.
- PEMF ([[Grounding#Grounding mattresses|Grounding]])
- Red Light ([[Red Light Therapy|Light]])
- Hypermax ([[Breathwork|Breathing]])
# Topics that're coming soon: 
Here are topics that are being added or updated. 
### New topics:
#### In the near future:
- Posture (general posture, sitting, sleep, mewing)
- What blood work markers to look for
- Training and how muscles grow
- What muscles need to grow in terms of nutrition
- How to bulk on the changed diet
- Mobility and Stretching
#### Later on:
- Fish and fish oil
- Saturated fat
- Our ancestors and their health
- Eye health
- Sleep
- Hair growth
### Updates to existing note:
#### In the near future:
- Honey
- Vegetables yes/no
- Hydration and minerals
- Cold exposure
- Is dairy really save
- Homogenized dairy
- Protein
#### Later on:
- Trans fats (conjugated linoleic acid)
- Dairy and IGF 
- Utilizing old notes for resource 

# DISCLAIMER
I'm not a licensed physician nor do I have any educational background in health, biology or medicine. I'm only a curious person that dedicates some of his time to looking into more healthy alternatives of living. 

**ALWAYS DO YOUR OWN RESEARCH AND FORM YOUR OWN OPINION ON THE TOPICS.**