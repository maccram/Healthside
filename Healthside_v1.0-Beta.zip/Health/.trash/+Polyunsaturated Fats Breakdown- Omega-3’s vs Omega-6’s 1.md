---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Polyunsaturated Fats Breakdown- Omega-3’s vs Omega-6’s
"url:": https://m.youtube.com/watch?v=oH7BtQjAu1Q&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T20:05
updated: 2024-06-24T20:18
---
<iframe title="Polyunsaturated Fats Breakdown- Omega-3’s vs Omega-6’s" src="https://www.youtube.com/embed/oH7BtQjAu1Q?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:23](https://m.youtube.com/watch?v=oH7BtQjAu1Q&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=83)
- Both polyunsaturated fats that means they have more then one unsaturated bond
[2:09](https://m.youtube.com/watch?v=oH7BtQjAu1Q&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=129)
- Omega 3 the last bond is 3 carbon chains from the end and omega 6 it's 6
- This plays huge role on impact of there function in the body
[4:59](https://m.youtube.com/watch?v=oH7BtQjAu1Q&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=299)
- Both compete for same enzyme
- both need desaturated to be broken down
- Omega 6 even prevents conversion of omega 3
- Omega 6 is in mostly plant oil, soy, sesame
- Omega 6 drive inflammation
