---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": Phytic acid and anti-nutrients
"url:": https://m.youtube.com/watch?v=mCV9Fzlp_Fw&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
---
<iframe title="Phytic acid and anti-nutrients" src="https://www.youtube.com/embed/mCV9Fzlp_Fw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[6:05](https://m.youtube.com/watch?v=mCV9Fzlp_Fw&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=365)
- We are made to even life on suboptimal food for survival
- Book smarter not harder
- Phytic acid is not good for the bones
- Animals can eat it cause of 3 stomaches, they can make phase to break down phytic acid
- Phytic acid steals you minerals
- Is in oatmeal
- Vegan diet isn't healthy nor is it environment friendly (creates nutrient deficiency)
- Also defense chemicals can inhibit you being able to take up nutrients from other meals too
