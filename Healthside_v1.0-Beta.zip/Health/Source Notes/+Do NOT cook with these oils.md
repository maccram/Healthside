---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Do NOT cook with these oils
"url:": https://m.youtube.com/watch?v=J0RUDo_3YFA&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-19T10:34
updated: 2024-06-19T10:36
---
https://m.youtube.com/watch?v=J0RUDo_3YFA&t
___
[1:00](https://m.youtube.com/watch?v=J0RUDo_3YFA&t=60)
- Don't want to heat olive and avocado oil
- Periodization index gives info when oil is damaged
- He would cook with coconut oil
- Tallow
- Butter
- Ghee
