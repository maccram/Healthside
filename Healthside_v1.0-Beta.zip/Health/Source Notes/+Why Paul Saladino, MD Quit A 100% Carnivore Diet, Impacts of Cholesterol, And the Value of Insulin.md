---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why Paul Saladino, MD Quit A 100% Carnivore Diet, Impacts of Cholesterol, And the Value of Insulin
"url:": https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:50
updated: 2024-06-24T19:52
---
<iframe title="Why Paul Saladino, MD Quit A 100% Carnivore Diet, Impacts of Cholesterol, And the Value of Insulin" src="https://www.youtube.com/embed/CamFyBFTbmg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[11:27](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=687)
- Garry is a fan of Paul Saladino
- There is no tribe that not eat meat
- A lot of illnesses are related to the auto immun system
- Gut is ground zero where Immunsystem is programmed
- Jordan peterson is also anivore and fixed his health
- Inulin signals kidney to hold on to electrolytes, so if don't get a signal we waste sodium
- He thought he didn't have the whole truth when he got problems
[13:18](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=798)
- We all share pieces of the truth
- Seeds/nuts/grains/beans all have defense chemicals (have more then food)
- Fruit contains defense chemicals but they decline when the food ripens
- Some people are more sensitive to defense chemicals then others thus vegetables
- If thrive why change anything
[19:02](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1142)
- Lies they tell you:
	- Meat is bad
    - For everybody vegetables are good (if have illness you eat to less fiber)
- He looked at tribes
- Of course put out Ultra processed food of the equation
- Singapore has one of longest life expectancies in the world and they have one of the highest meat consumptions
- Gary said there was no death of clinically elevated levels of LDL cholesterol
- Also Paul mentioned that usually people that live long have elevated levels of cholesterol
- For people that have issues like fatigue, metal health, anxiety, sleep disturbance, low libido, auto immun conditions, problem of weight loss (for lot of those cutting out vegetable and plant food to test it might be good)
- Gary mentioned that he had a guest that treats people with very bad mental issues that are even drug resistant with keto diet
[20:29](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1229)
- Hydrogen water feeds a lot of bacteria in gut
- Gary has his own brand
[26:58](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1618)
- Rootcause of mental issues is neural inflammation
- There are a lot of pararells with brain and body
- Ultra processed food leads to inflammation
- Table sugar is molecule of sucrus, humans would never had that in nature
- We always had that molecule combined with fiber and thousands of other things
- Probably 5000 components in fruits
- High fructose corn syrup now sneaks into things under natural fruit flavour (actually no fruit most fruit yoghurts)
- High fructose corn syrup also contains traces of mercury and other toxins (Studies about it)
[29:16](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1756)
- Paul thinks that Robert lustig talked a little confusing about fructose
- Problem is not fruit and fruit juice the problem is taking away all other information in the food
- Same with seed oils its more a industrial byproduct of a seed
- Canola oil is canadian oil low acid is actually rape seed (they genetically modified a rape seat so its low arsuc acid which is actually banned, still has significant amount of arusc acid)
[38:27](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2307)
- Cholesterol is one of main construction material
- It is a necessary thing
- When eat less seed oil and more animal fat then cholesterol goes up
- The western medicine things that there is a direct correlation between amount of apob and the more plaque in ateries (but that's not true)
- When we don't have metabolic disfunction then there is no such relationship
- In native human biology we don't get atherosclerosis in veins we only get it in atteries
- When apob is the problem why are there so much instances where this isn't true
- When you have damage to the endothelium apob is involved
- Damage of endothelium is caused by toxins like heavy metals
- Problem with seed oil studies is that the control group got something with translates which is not good and was banned afterwards
[41:27](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2487)
- But there are 3 studies that are good that's the Minnesota corn oil study
	- These studies all found that seed oils where bad
    - It also was suppressed
- Problem with seed oils also fat linoleic acid
- We would never gotten that amount of linoleic acid in our diet cause the seed itself doesn't contain that much
- Cumulative toxicity is in many things also like fluoride
- The more linoleic acid in fat cells the higher cardiovascular disease
[49:56](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2996)
- It's also in nuts but if tolerate nuts you could eat it
- It's actually in most things but not as highly concentrated as in seed oils
- Both not fan of peanut butter (worst micro toxin)
- Seems that its when oils oxidize
- Flax seed oil also not good
- fish oil also not good cause its easily oxidized
- Also if you really want to narrow it down then also eat grass fed meat
- It's really in pigs, eggs, chicken where the poly saturated fats accumulate, so more linoleic acid when grain fed
- The American heart association got a 1.7 million dollars funded before there where lower cardiovascular disease cause people eat just animal fat
	- Also advertisments from 1960s about poly saturated fats being good
- Thinks over long term seed oils and linoleic acid create insulin resisstance
[52:12](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=3132)
- Gary said that mortality is going backwards which makes no sense cause we have technology advancement
- "The amount required to undo bullshit is 10 times greater then to make up the bullshit"
	- Brandolinis law
- What we learn first in our brain stays
- Also for medical students hard to undo shit they been told, also you get discredited if you are against a common belive
[58:11](https://m.youtube.com/watch?v=CamFyBFTbmg&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=3491)
- Steps to take to get going:
	- Don't let perfect be the enemy of good
    - First step:
	    - cut out ultra procest food
    - If you give organ meats to kids they will easily get used to it
- Paul has meat stick with organ meat in it
