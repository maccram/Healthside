---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Dr. Mike Israetel - Build Muscle Faster than 99% of people by doing this
"url:": https://m.youtube.com/watch?v=sChIij1cFDg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T19:53
updated: 2024-06-24T19:54
---
<iframe title="Dr. Mike Israetel - Build Muscle Faster than 99% of people by doing this" src="https://www.youtube.com/embed/sChIij1cFDg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[11:25](https://m.youtube.com/watch?v=sChIij1cFDg&t=685)
- Overtraining is a real thing
- Calls it mrv (maximum recovery volume)
- But there is MEV (minimum effective volume) 
	- Minimum needed to grow muscle
- If genetically good, good technique and enormous then can get enough stimulus with little reps
- On average MRV is 20 sets per muscle per week but exception to that
	- You can only train whole body so much, but local limit of each muscle is quite high relatively to that
    - So its the systemic fatigue that stops you from going higher not the muscle
    - If would lower upper body training volume and do more legs instead then you could get the volume up to 30-50 sets per week
	    - Benefitial for growing a specific muscle
        - Could do with 1-2 muscles at same time
- Also listen to your body and the need of it for recovery
[18:44](https://m.youtube.com/watch?v=sChIij1cFDg&t=1124)
- Overall life Stress also leads to fatigue
- You won't loss muscle if you reduce training to a third when needed
- A body is a physical Maschine with limits
	- Push them forsure but not overdo it
- You can do two things with training
	- One is getting results
    - The other is training though ness
    - You don't want the second to interfere with the first
