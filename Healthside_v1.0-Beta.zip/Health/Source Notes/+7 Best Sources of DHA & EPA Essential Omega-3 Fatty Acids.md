---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "7 Best Sources of DHA/EPA: Essential Omega-3 Fatty Acids"
"url:": https://m.youtube.com/watch?v=9JQBczWa6aU&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@KenDBerryMD]]"
created: 2024-06-19T10:33
updated: 2024-06-19T10:34
---
<iframe title="7 Best Sources of DHA/EPA: Essential Omega-3 Fatty Acids" src="https://www.youtube.com/embed/9JQBczWa6aU?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[4:39](https://m.youtube.com/watch?v=9JQBczWa6aU&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=279)
- Benefits of DHA and EPA:
    - Epa reduces cellular inflammation, also improved Neuro inflammation (dementia caused from it), good for cardiovascular system, also helps burn excess fat
    - Dha decreases blood triglyceride, increase in hdl, also helps with inflammation , helps muscle recovery, lower blood pressure, decreases mortality, protects telomeres (the longer they are the longer you live)
- They are essential omega 3, so body can't produce them
[6:35](https://m.youtube.com/watch?v=9JQBczWa6aU&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=395)
- Get at least 500-3000mg of omega 3 daily
- Ala converts into dha and EPA but that's not sufficient enough
    - Only coverts 6% in epa, 4% in dha
[8:40](https://m.youtube.com/watch?v=9JQBczWa6aU&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=520)
- There is no overdose of omega 3
- Some people say you can get a vitamin a or d toxicity but there is no reported case that someone got one from natural foods
[13:59](https://m.youtube.com/watch?v=9JQBczWa6aU&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=839)
- Foods:
    - Mackerel
    - Salmon
    - Fish roe
    - Cod liver
    - Herring
    - Oysters
    - Sardines (in water)
    - Anchovies
