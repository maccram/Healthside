---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why You Should Drink Carbonated Water
"url:": https://m.youtube.com/watch?v=XspP7Cbw4fA&pp=ygUJdGFwIHdhdGVy&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T10:31
updated: 2024-06-19T10:32
---
<iframe title="Why You Should Drink Carbonated Water" src="https://www.youtube.com/embed/XspP7Cbw4fA?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:35](https://m.youtube.com/watch?v=XspP7Cbw4fA&pp=ygUJdGFwIHdhdGVy&t=155)
- Bohr effect:
    - For oxygen to get absorbed by tissues it takes co2
- Also when hyperventilating then you get paper bag and thus co2
- Carbonated pools also good
[6:43](https://m.youtube.com/watch?v=XspP7Cbw4fA&pp=ygUJdGFwIHdhdGVy&t=403)
- Increase in activation of parasympathetic nervous system
- Cancer cell more alkaline, normal one more acidic
- Co2 anti tumor
- After thunderstorm typically can breath better, that's due to co2 in air
- Also more co2 in hot springs
- Co2 also anti inflammatory
