---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The Best Protein Sources for Longevity - Dr. Paul Saladino Ranks Best to Worst
"url:": https://m.youtube.com/watch?v=nHFdSLOScXI&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T19:57
updated: 2024-06-24T19:58
---
<iframe title="The Best Protein Sources for Longevity - Dr. Paul Saladino Ranks Best to Worst" src="https://www.youtube.com/embed/nHFdSLOScXI?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:55](https://m.youtube.com/watch?v=nHFdSLOScXI&t=115)
- He prefers to eat meat instead of protein powder
- But he thinks protein powder is good it has some purpose to it like if you workout
[12:07](https://m.youtube.com/watch?v=nHFdSLOScXI&t=727)
- He thinks animal proteins have better digestibility and utilization over plant ones
- Also lack or smaller amount of amino acids in vegetables
- Plant based ones also have bigger amounts of heavy metals
	- 70% of it had it
    - Organic even higher levels
- Animals could have heavy metals too if they eat not high quality food
- Worst protein is soy protein
	- Lower androgen receptor density and testosteron needs those to bind
    - Also tofu
- Fermentation often detoxifies plants
	- With cabbage (before is harmful for thoride cause it inhibits a nutrient)
- Animal protein:
	- 3 types (beef, whey, egg)
	    - Same bioavailability
        - Whey higher in amino acid cysteine (increases glutathione)
        - Beef protein higher in glycine (also in creating glutathione involved but also collagen)
        - He thinks whey and beef is more beneficial
    - Paul has his own powder
    - Raw food always have risk of contamination (raw fish/spinach)
    - Milk would also have raw whey that would probably be beneficial (but hard to get)
    - If you use a protein powder the look for the COA (look if the company tests for heavy metals and PPA)
	    - PPA is androgen disrupting compound
[16:00](https://m.youtube.com/watch?v=nHFdSLOScXI&t=960)
- Whey protein vs. whey isolate:
	- In a concentrate there is lactose
    - Hard to get colostrum (there is powder but doesn't is as effective as the real one directly of the cow)
    - isolate just protein
    - Thomas gets 200g protein and he ways 185 pounds
[20:43](https://m.youtube.com/watch?v=nHFdSLOScXI&t=1243)
- Ground beef is good
- If only eat lean meat there are potential benefits to include collagen in the diet
	- Bone broth has collagen in it
- Marine collagen is worst one
	- Heavy metals cause out of fish
- Lots of collagen in general has high heavy Metall amounts
- Pauls also has supplements for organ foods
[22:53](https://m.youtube.com/watch?v=nHFdSLOScXI&t=1373)
- Beef proteins are spiked with aminos
