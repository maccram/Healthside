---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": Wearing Blue Blocking Glasses is NOT a Dumb Idea - Here’s Why
"url:": https://m.youtube.com/watch?v=jWKpGgLHIdA&pp=ygUTYmx1ZSBsaWdodCBibG9ja2Vycw%3D%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
---
<iframe title="Wearing Blue Blocking Glasses is NOT a Dumb Idea - Here’s Why" src="https://www.youtube.com/embed/jWKpGgLHIdA?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[5:35](https://m.youtube.com/watch?v=jWKpGgLHIdA&pp=ygUTYmx1ZSBsaWdodCBibG9ja2Vycw%3D%3D&t=335)
- Melanopsin receives blue light
- Pineal gland shuts of melatonin
- Study where they tested the blue light effecting sleep (with blue light 16 min less sleep and woke up 6.7-7.6 times usually baseline is 4-4.5, also cycadian rhythm shifted by 3 hours)
- Yellow amber glasses block out excess blue light and let in natural one, red ones block out blue and green light and they are there for night time to promote melatonin production.
[6:02](https://m.youtube.com/watch?v=jWKpGgLHIdA&pp=ygUTYmx1ZSBsaWdodCBibG9ja2Vycw%3D%3D&t=362)
- Has also effect on metabolization
- At night lower blue light exposure
