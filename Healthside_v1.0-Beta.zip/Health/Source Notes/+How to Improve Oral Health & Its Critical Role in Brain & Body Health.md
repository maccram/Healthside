---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How to Improve Oral Health & Its Critical Role in Brain & Body Health
"url:": https://m.youtube.com/watch?v=zVCaYyUWWSw&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-24T20:02
updated: 2024-06-24T20:03
---
<iframe title="How to Improve Oral Health &amp; Its Critical Role in Brain &amp; Body Health" src="https://www.youtube.com/embed/zVCaYyUWWSw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:12](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=132)
- Add 7th pillar of mental/physical health and performance which is oral health and mictobiom (Oral and gut health)
- 6 pillars are:
	- Sleep
    - Sunlight & Light exposure
    - Nutriment
    - Exercise & movement
    - Stress management
    - Relationships & Social Engagement (including relationship to self)
[3:12](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=192)
- Saliva is important and benefitial
[3:50](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=230)
- Mateina brand that makes lose leave yerba mate
- Helix sleep makes mattresses/pillows
[12:48](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=768)
- Oral health is linked to brain and body health
- Also if think you to your teeth good and brush teeth twice flush them and go to the dentist often then there is a chance that if you don't look at the mictobiom you don't do that much good
- People that so less often have overall healthier microbiom doesn't mean its always the case but there is a possibility
- He talked to a few dentists
[20:10](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=1210)
- Mouth anatomy:
	- Teeth
	    - are layered structures different layers
        - Outer layer is enamel which is translucent, under it there is the dentin
        - cavities forms from outside to inside, cavites puts in holes where the bacteria goes down the enamel and if unlucky go to dentin, goal is to avoid cavities and fill in the cavities
    - Based on mouth being acidic or basic is either demineralization (de min) and remineralization (re min)
    - Remineralisation is good cause it is the process by within the enamel and some extend in deeper dentin layer there can be the addition of new minerals that form robust chains of crystals, so you'll fill back in holes from cavities
    - If cavities on two teeth then chances that they are at the same level
[26:21](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=1581)
- Teeth are always in state of eighter de min or re min
- Largely dependend of the pH of mouth which largely depends on how much saliva you produce and how mineralized it is
- Gums (gingiva) also important role in keeping the teeth stable, its like a seal around the teeth (the pockets should low)
- Typical all holes are protected in some way, but we have a huge hole (mouth) that's filled with bacteria
- Mouth breathing also not good for teeth health
- If pH is right in mouth we kill off bad stuff and the good stuff can be there
- Oral cavity also can take cuts and with rare exceptions heals up with nearly zero scar
- By supporting tooth health you also support gum health
- If gum not good then it could cause periodontal disease which can lead to alzheimers
[34:54](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=2094)
- How cavity forms:
	- When goes down dentin layer need to be filled
    - Goal is to keep teeth in re min
    - No specific food causes it, not even sugar
    - It forms by bacteria that feeds on sugar, they create acid that goes down and demineralizes the teeth in area of carvity
    - The bacteria (major one is streptococcus mutants) that causes it, is not what you are born with (you give it to one another)
	    - It's hungry for sugar
    - If already more de min then much faster cavities
    - Carbonated drinks (also acid)
    - He mentioned he is a omnivore (he eats starches, vegetables, fruits)
    - Strep mutants will feed on other stuff if you eat no carbs
    - So you want to keep your mouth as alkaline as possible
    - Key point is degree to which mouth is in de min or re min state and degree to which cavities has the opportunity to form is dependend on the amount of time the mouth is net acidic/alkaline (no one can avoid mouth being acidic once in a while)
[42:54](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=2574)
- Tooth mineralization:
	- The crystals form in specific type of bond (these are very strong)
    - They are though to tear apart
    - A bond is as strong as many points its held by
    - The minerals form in specific angles and specific ways to ensure more points
    - The mineral that is there to do that job is hydroxy apetite, not indestructible cause acid can break that bonds (that's de min process)
- Floride is not a vitamin, mineral nor a essential nutrient, but it can replace some of hydroxy apetite bonds in teeth and make those bonds hyper strong (super strong)
- But it can disrupt brain and thoride health, it can be a poison
- He has links to toothpaste in description
- If against fluoride then should care more about remineralization of teeth
- Also some data that fluoride is not that good for oral microbiom
[53:45](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=3225)
- Tool (don'ts for oral health):
	- Don'ts:
	    - Alcohol (disturbing of microbiom, also de min)
        - Stimulants (methantamin, aderal, vivance, any drug that increases epinephrine and norepinephrin, chemical reason is they change pH of mouth, mechanical reason is that they mouthbreath more)
        - Mouthbreathing
        - smoking
        - Sugar (if eat then rinse or best brush teeth after eating it)
        - Mouth washes
        - Also other food particles in mouth are not good
        - acidic food (limit time mouth is acidic)
[57:27](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=3447)
- Tool (fasting, remineralization):
	- Certain times in day where mouth makes maximum amount of salavia thus have optimal opportunity to have rights pH
	    - During day time middle time
        - Eating can disrupt that
        - Best to have time like 2-3 to even 6 hours where you don't eat anything can be very benefitial
    - So intermittent fasting can be benefitial (he does it eats 11am and last food by 8pm)
    - In morning and day have that opportunity to create lots of saliva
    - In middle of night saliva production is very reduced, that's why you wouldn't want to have any food particles in mouth cause salvia can't do its job as effecient
    - Night is critical time so brush your teeth there
    - Brushing two times good (or even 3 times)
[1:08:31](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=4111)
- How to brush:
	- Most dentists say need to brush and floss (twice a day)
    - Use a soft toothbrush
    - Medium/hard brushes disrupt the gum
    - Moving brush in circular motion without much pressure
    - With electric toothbrush also not to much pressure
    - Also adviced to brush the gum (increase blood flow thus better taking of nutrients, especially if sensitive teeth)
[1:09:03](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=4143)
- Main goal with brushing is to break up the biofilm layer
- So when the strep mutants get there the form a layer which isn't good (plaque)
- When plaque gets hard its Tara which needs to be scrubbed off by the dentist
- When already yellowish then probably tardy and brushing won't remove that
- When dentist polish teeth they make the teeth smooth and that's cause then the bacteria can't hold on to the teeth that easily
[1:11:26](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=4286)
- Flossing:
	- You need to glide down the teeth
    - Use circular motion
    - Floss twice a day (at least once a day)
    - Water pick could be good idea
    - Children who have spaces between teeth which they typically do, don't have to floss
[1:19:53](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=4793)
- Changing chemistry of mouth:
	- Xylitol (low calorie sweetener)
	    - Gets eaten by the bacteria but it can't create the acid and also it kills the bacteria
        - Some evidence that it supports gut microbiom
    - If that is there in min and hours after the meal then it will feed on it
    - Also reduces inflammation of the gum tissues and other inflammation in the mouth
    - So there are xylitol gums (1-2 after meal)
	    - Also increases production of saliva
        - He has a link in describtion
[1:23:47](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5027)
- Toothpaste:
	- Xylitol in it good thing
    - Flouride or avoid it?
    - Hydroxyapatite
	    - Mineral that naturally form the bonds
        - If without flouride then use one with that
    - He also has some links in bio
[1:26:37](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5197)
- Mouthwash:
	- Most especially the ones containing alcohol are terrible
    - The deplete certain things of the mucosal lining of the mouth and disrupt the healthy components of the oral microbiom
    - Also there are anti septic ones (probably prescribed by dentist, should ask them if they are bad)
    - If you really want one then it shouldn't be a antiseptic
[1:33:19](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5599)
- Cost saving alternatives:
	- Baking soda would brush of biofilm (save for enamel of teeth)
    - Mouthwash with baking soda, hydrogen peroxide not good idea, cause hydrogen peroxide is something you don't want to get into oral cavity
    - High salt water solution (where won't fully dissolve cause of high sodium), that as dental rinse is good for production of healthy mouth bacteria (don't swallow it)
[1:33:29](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5609)
- Alcohol based mouthwashes also reduce nitric oxide produced in oral cavity
- Nitric oxide is important cause it promotes vasuldilation (when nasal breath, oral microbiom is healthy we improve it)
	- It's good for aterial and capillary health
- So we don't want to reduce it
[1:37:16](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5836)
- Canker sore
	- We can prevent it or improve healing
    - There's link between gut biom with oral one
    - To support the gut biom you should consume at least 1-4 servings of low sugar fermented food per day
	    - Has own video on it
    - Also consuming enough fiber (vegetables, don't things you should get the supplements all the times)
    - Mentions doctor mark burhenne
	    - He also pointed out that sleep is important
        - Fewer sleep affects the gut and oral biom
[1:39:48](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=5988)
- Tongue Brushing:
	- Different locations in mouth have different microbiom with good and bad bacteria
    - Tongue scraping (brushing) can be a good idea
    - Lightly brushing the tongue might be better (but seperaten toothbrush)
	    - Cause don't crossover the bacteria
    - But if use scrub then with low force
- Toothbrush care:
	- After use rinse off and dry it
    - One has to decide how much bacteria they are willing to keep on toothbrush
[1:47:42](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=6462)
- Fillings:
	- If there is cavity ask the dentist
    - Metal fillings (lead ones bad, many metal fillings contain mecury)
	    - To not disrupt those mercury ones avoid mastic gum (thick gum) or hard candy
    - if to deep it needs to be filled
[1:51:43](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=6703)
- Dentist visits:
	- Twice a year is recommendation
    - Routine cleanings only get rid of plaque
    - It's like a checkup to look how the practicing doing
[1:53:57](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=6837)
- Oral health promotes cardiovascular/gut health
[1:56:13](https://m.youtube.com/watch?v=zVCaYyUWWSw&t=6973)
- Oil Pulling:
	- Some evidence
    - But not enough evidence
- Vitamin d with teeth
