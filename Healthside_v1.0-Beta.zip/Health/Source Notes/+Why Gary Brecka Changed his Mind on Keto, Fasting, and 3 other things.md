---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why Gary Brecka Changed his Mind on Keto, Fasting, and 3 other things
"url:": https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T20:09
updated: 2024-06-24T20:10
---
<iframe title="Why Gary Brecka Changed his Mind on Keto, Fasting, and 3 other things" src="https://www.youtube.com/embed/_qed0D6RDdk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:22](https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=82)
- Garry thinks things that are Positiv in the biohacking industry often get taken to the extremes
[11:30](https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=690)
- Intermittent fasting:
	- Dr Volter Longos
    - Huge believer 12h not feeding, with bigger feeding window
    - He does 3 day water fasts sometimes over the year
    - For some its good to fast more
    - We should get data
    - Look at glycemic profile (glucose, hemoglobin A1, insulin)
	    - When more insulin resistant a narrow feeding window can be beneficial
        - If hypoglycemic then not good
    - So 12h on 12h off is the average
	    - Also Thomas also says same
    - When have data then could tighten the window
    - Testosteron and Hormons
    - Often its not hypo production of a hormone its rather the hypo signaling
[14:56](https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=896)
- Micro dosing with poisons:
	- Often its the accumulative dosage that determines the poison
    - Some poisons (glyphosate, fluoride, chlorine in water, cyanocobalamin, cyanide)
    - It's okay to have small amounts
    - GMO foods bad
	    - Get resistant to antibiotic, thinks this will become a pandemic
    - Organic not clean always (Gary has podcast on it)
	    - Even making more food of it
    - Sitting is new smoking
[40:38](https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2438)
- Keto:
	- Mitochondria makes water (100 gallons a day), in ketosis you make light water (deuterium depleted water
    - If high triglyceride levels then on high fat diet (12 week keto reset)
[51:22](https://m.youtube.com/watch?v=_qed0D6RDdk&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=3082)
- Cold therapy:
	- Not after workout
    - 3-6min, 40-50 degrees
