---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "Dairy: good or bad for humans?"
"url:": https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:58
updated: 2024-06-24T19:59
---
<iframe title="Dairy: good or bad for humans?" src="https://www.youtube.com/embed/dExBTIIT0l8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:20](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=80)
- Dairy from animals better then plant based one
- Grass fed tallow on wound
[10:27](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=627)
- Ancestors and dairy:
	- Grains at same time then dairy
	    - Don't likes grains cause they have defense chemicals
    - He had multiple stress fractures which he thinks came from oats
    - Milk was favorable in the human evolution
    - Lots of tribes that had milk in there diet
    - Lot of tribes combine blood with milk
    - Often African tribes
[20:11](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=1211)
- Nutrients in milk:
	- Often even when you have a lot of one nutrient you won't absorb a lot of it due to anti nutrients
    - Half a liter of raw full fat milk
	    - 336 calories
        - 17g protein
        - 30g carbs
        - 17g fat
        - 52% Calcium
        - 28% vitamin a
        - 125% vitamin B12
        - 17% folate (especially good for pregnant women)
        - 20% Potassium
        - Trans fats (conjugated linoleic acid has positiv effects on body instead of linoleic acid)
        - Also has vitamin b2 (which usually get eighter through dairy or organ meat)
        - A lot of b vitamins
    - Meat, eggs and milk are good sources of nutrients
[21:11](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=1271)
- Good nutrients in milk
	- Tgf alpha and beta
    - Colostrinin which is good for Alzheimer's
[24:24](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=1464)
- Also Egyptian hieroglyphs show they drank milk
- Also in Bronze and iron ages there are findings of clay "bottles" they used to store milk
[24:27](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=1467)
- Study about lactase persistence (found out that humans probably developed persistence due to drinking milk)
- Raw milk helps people to get ability to metabolized that milk
- There are several disaccharides like sucrose (which is glucose and fructose), other is lactose (which is galactose and glucose)
[25:17](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=1517)
- Talks about his grass fed colostrum which is also benefitial, boosts immun system and improves recovery
[36:33](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=2193)
- Dairy in general is benefitial (that's not even raw dairy)
- Study about coronary atherosclerosis in postmenopausal women
	- More saturated fat helped against cardiovascular disease even when increased LDL cholesteral
- Studies show that butter and dairy help against heart attack
- Dairy also good from metabolic, obesity perspective
- Also milk intake correlated with lower cancer
- Reduced risk in diabetics type 2
[39:29](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=2369)
- Was study that showed almond milk was related to kidney stone, painful urination and recurring bladder inffections
- Thinks igf1 concerns about milk are not really needed
- Motor and igf1 are actually good for humans
- Loss of muscle mass is correlated to early death and injury
- To retain muscle mass get lots of protein (triggers mtor in healthy way, also diary gives you protein)
[48:13](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=2893)
- He thinks there is lot of evidence for raw milk and cheese made of raw dairy or kefir
- Benefits of raw milk on children (Gabriella study)
	- Less allergic conditions, Asthma, eczema
- In 19 hundreds the hygiene was not good and that's why pasteurization came up
- Grain fed cow may also effect quality of milk
- If don't want to drink raw milk you can eat raw cheese
[57:59](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=3479)
- A1 vs. A2:
	- When sensitiv to milk then get A2
    - Next best thing if not raw milk is low pasteurized milk
    - A1 more inflammentory
    - Also A1 could be associated type 1 diabetes (better not feed kids with it)
- Bones can also be benefitial for humans (to much not good)
- Meat has good amount of calcium, but milk and dairy products helps to get the daily amount in
[1:01:05](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=3665)
- First milk produced is colostrum
- By drinking it you don't take it away from the baby cow cause the female tends to overproduces it
- Study about it
	- Only source of two growth factors
    - Also good for wound healing
- study where compared with flu vaccination
	- colostrum and vaccination did better then just vaccination
- So there is evidence that colostrum is benefitial against flu
- There is a colostrum supplement at his company
[1:10:15](https://m.youtube.com/watch?v=dExBTIIT0l8&pp=ygUJcmF3IGRhaXJ5&t=4215)
- He prefers kefir over joghurt
- Lot of joghurt is made of pasteurtized milk

