---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Vitamin Deficiencies that cause dry or oily hair - Dr. Berg
"url:": https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-12T13:25
updated: 2024-06-12T13:27
---
<iframe title="Vitamin Deficiencies That Causes Dry or Oily Hair – Dr. Berg" src="https://www.youtube.com/embed/aZqhHKB-mKc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:28](https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=28)
- Sebaceous gland responsible for releasing oil (sebum, there to lubricate and protect surface of body)
- If dry:
	- deficiency in fat suable vitamins
	- specific vitamin a (helps regulate the gland)
	- vitamin D and E
	- Not able to absorb it
	- To get the vitamins could use cod liver oil
	- vitamin e from leavy greens, nuts
[3:07](https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=187)
- If oily:
	- Can be low zinc (helps to decrease androgens and is DHT)
	- DHT is powerful type of testosterone, makes gland bigger and then makes it produce more oil
	- Other cause is high levels of insulin
[4:31](https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=271)
- So go on healthy keto and intermittent fasting
- What leads to zinc deficiency (too many grains, history of antibiotics, or eating lot of refined carbs, digestive problem, alcohol, diarrhea, low hydrochlorothiazide-HCL can't absorb zinc and other minerals with it)
[4:44](https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=284)
- Symptom of HCL deficiency is acid reflux
- [5:00](https://m.youtube.com/watch?v=aZqhHKB-mKc&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=300)
- By taking apple cider vinegar and potein-100 chloride can increase trace mineral
- Seafood like oysters, red meat, liver, beef liver are high in zinc
