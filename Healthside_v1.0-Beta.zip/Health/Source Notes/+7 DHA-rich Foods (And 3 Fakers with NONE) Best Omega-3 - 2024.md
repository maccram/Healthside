---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": 7 DHA-rich Foods (And 3 Fakers with NONE) Best Omega-3 - 2024
"url:": https://m.youtube.com/watch?v=Lgxot4NL_bo&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@KenDBerryMD]]"
created: 2024-06-18T19:03
updated: 2024-06-19T06:56
---
<iframe title="7 DHA-rich Foods (And 3 Fakers with NONE) Best Omega-3 - 2024" src="https://www.youtube.com/embed/Lgxot4NL_bo?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:24](https://m.youtube.com/watch?v=Lgxot4NL_bo&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=84)
- DHA is healthy for eye, Heart health, brain function, function of ear, also needed for pregnant women, needed for toddlers
[4:48](https://m.youtube.com/watch?v=Lgxot4NL_bo&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=288)
- 7 DHA rich foods:
    - ​Egg yolk (29mg)
    - Cod liver (421mg/can), not oil or oil capsules
    - Oysters (620mg/can)
    - Sardines (758mg/can)
    - Anchovies (774mg/3oz)
    - Tuna (1940mg/6oz)
    - Salmon (2477mg/6oz)
[5:22](https://m.youtube.com/watch?v=Lgxot4NL_bo&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=322)
- Plants don't contain DHA, they contain ala
- Some can convert ala to DHA good but some not
[5:47](https://m.youtube.com/watch?v=Lgxot4NL_bo&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=347)
- List of top 200 DHA rich foods https://tools.myfooddata.com/nutrient-ranking-tool/DHA/All/Highest
