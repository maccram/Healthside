---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Here’s What Eating Dairy EVERY DAY Does to Your Stomach Fat, Brain, and Gut
"url:": https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T19:41
updated: 2024-06-24T19:42
---
<iframe title="Here’s What Eating Dairy EVERY DAY Does to Your Stomach Fat, Brain, and Gut" src="https://www.youtube.com/embed/ragPQeYRB8c?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:00](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=0)
- Raw creme, raw kefir is alternative
[1:04](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=64)
- Raw milk can improve stiffness in the joints (wulzen factor)
- High heat in milk production denatures proteins, breaks down antibody effects, kills good bacteria)
[2:56](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=176)
- Wulzen factor:
	- Anti stiffness
    - Called after Rosalind wulzen
    - Anti inflammatory
    - Paper on it
[5:17](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=317)
- Gut microbiom:
	- Handle fuel better
    - More energy
    - Also in yoghurt also often pasteurized also kefir
    - But study showed that raw kefir changes the microbiom positively
    - Also helps handle foods better
    - A lot of processed food has lactose in it even if you wouldn't think so
    - Raw milk has lactese and other compounds in it that help you digest lactose
    - Maybe lactose intolerance is just lack of the ight enzyme and bacteria to break it down
    - Also can help to add probiotic with raw milk together to help gut to restabilize
[8:45](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=525)
- immune system:
	- 1-2 weeks in
    - Immune system feels better
    - Recover better
    - Anti bodies and some Enzyms that are connected to immune system would also effect the human (study)
	    - Raw milk consuming ones had 30% less illness
[10:40](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=640)
- Essential fatty acids:
	- After 2-3 weeks
    - Tore mental acuity and better mood
    - We kill or harm over 350 fatty acids by pasteurization
    - Also talks about omega 3
    - You'll be also less hungry
[13:13](https://m.youtube.com/watch?v=ragPQeYRB8c&pp=ygUJcmF3IGRhaXJ5&t=793)
- More pathogens (actually what pasteurization is for to kill off)
- Study about it
- 20-40% occurrence
- Also 9-10% of pasteurtized milk had it
