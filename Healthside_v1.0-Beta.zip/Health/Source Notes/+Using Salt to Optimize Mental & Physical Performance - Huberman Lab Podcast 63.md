---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Using Salt to Optimize Mental & Physical Performance - Huberman Lab Podcast 63
"url:": https://m.youtube.com/watch?v=azb3Ih68awQ&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-12T16:38
updated: 2024-06-13T20:53
---
<iframe title="Using Salt to Optimize Mental &amp; Physical Performance | Huberman Lab Podcast #63" src="https://www.youtube.com/embed/azb3Ih68awQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:48](https://m.youtube.com/watch?v=azb3Ih68awQ&t=108)
- For some people more salt is good and for some less
[8:54](https://m.youtube.com/watch?v=azb3Ih68awQ&t=534)
- Neuropod cells (some sense sugar)
- They respond to sugar and lead to Dopamin release
- Also combined with tasting something sweet
- So that's what leads to craving through hidden sugars
- Artificial sweeteners can have insulin response under certain conditions
- We also have a drive for carbonation
[16:21](https://m.youtube.com/watch?v=azb3Ih68awQ&t=981)
- Salt has many important functions in the body (for example fluid balance, also desire for salt itself)
- You crave salt when salt storage is low
- Salt also regulates appetite for sugar
- Technically salt is a mineral
- He will be referring to sodium when talking of salt
- 1g table salt has 388mg sodium
[24:12](https://m.youtube.com/watch?v=azb3Ih68awQ&t=1452)
- we have little clusters of neurons that senses the level of salt in our brain and body
- There are certain brain regions that do this ( those don't have the blood brain barrier)
- Most substances don't have access to the brain (that's due to the fact that the brain can't really heal from injury)
- Overies and testis also have a barrier around them (assumption is thats cause they contain the genetic material)
- Small and critical substances can access the blood brain barrier
- Some regions of brain have a weaker/stronger fence around then
- The areas that monitor salt balance and other functions related to Concentration of salt in body (osmolarity)
- Most important neuron in that region is ovlt (these has neurons that can sense contents of blood and to some extend the Sevierville spinal fluid)
- It basically controls if there is enough/to less salt and communicates with other brain regions if there isn't
- It's an important process without it you are in big trouble and probably dead soon
[24:48](https://m.youtube.com/watch?v=azb3Ih68awQ&t=1488)
- Thirst is there cause the neurons in ovlt are detecting changes in bloodstream which detect global changes in body, and in response it sets of certain events that make you eighter want to drink more or stop drinking
[32:09](https://m.youtube.com/watch?v=azb3Ih68awQ&t=1929)
- Two types of thirst:
- Osmotic thirst (has to do with concentration of salt in bloodstream, when salt concentration of blood is high then sends signals to other areas which lead to some other events, )
- Signals to supraoptic nucleus, paraventricular nucleus
- The pituitary gets signaled and from there there is a hormonal signal released called vasopressin (antidiuretic hormone), this either restricts the amount of Urin we put out or increase it
- Hypovolemic thirst (occurs when drop in blood pressure , ovlt also has neurons that can detect that, that are baroreceptor/mechanoreceptor types)
- Baroreceptor response to changes in blood pressure
- Things that can decrease blood pressure is loose lot of blood, or some cases vomiting, or diarrhea
- Classic case is loosing blood
- In both variants you'll desire thirst
- Not only about seeking water also about seeking salt (sodium)
- Sodium can help retain water (not always)
[38:31](https://m.youtube.com/watch?v=azb3Ih68awQ&t=2311)
- Kidney is there for release and retaining of substances of the body (like glucose, amino acids, uria, uric acid, salt potassium, magnesium)
- Basically a very knowledgeable filter
- Blood enters kidney there is the loop (loop makes that keep some substances and some not)
- It response to a voraity of hormonal signals (eg vasopressin)
- Urin is basically filtered blood
- 90% of fluid absorbed in the tubes, and rest when go into distal kidney
- Proximal (close), distal (far away)
- If thirsty for a while kidney gets told by the vasopressin to not release fluid, vise versa when have lot of fluid
[45:25](https://m.youtube.com/watch?v=azb3Ih68awQ&t=2725)
- Vasopressin:
    - Anti diaretic means prevents peeing
    - Also mentioned in a other episode about desire love and attachment
    - Is made at multiple locations of nervous system (mainly supraoptic nucleus)
    - It's also involved in sexual behavior
    - Works at distal part of the liver
    - It prevents the fluid going to the bladder
    - Kidney uses sodium to conserve water (cause sodium can hold water)
    - If estrogen is high there is water retention in the body
    - But estrogen also acts as diaretic but it's all a complicated balance between hormones, salt and fluid
[49:32](https://m.youtube.com/watch?v=azb3Ih68awQ&t=2972)
- How much salt do we need
- There are lot of people out there with prehypertension or hypertension (you should know that, meaning blood pressure)
- Blood pressure tells you lot about your health
- There are a lot of studies that show that high salt diet can be bad for tissue and various organs (also brain)
- If salt concentration in brain too high neurons suffer
- But also if to less salt then cells will shrink (cause water taken from them, also there brain function can suffer)
- But also the problem with the studies is that the high salt level is also coupled with other bad nutrition like high carbs
- There are not many studies that looked into high/low and moderate salt intake
[54:29](https://m.youtube.com/watch?v=azb3Ih68awQ&t=3269)
- Lower salt in diet can reduce hazardous events (risk of cardiovascular events)
- Paper on it (looked at excretion)
- Sodium and potassium work in concert in the body
- Hazard ratio low is lowish at sodium excretion of 2g per day and continues to go down to about 4.5-5g
- Hazard ratio increases dramatically about 7-8 and towards 12g
- Processed foods tend to have more salt in them
[1:01:07](https://m.youtube.com/watch?v=azb3Ih68awQ&t=3667)
- If high blood pressure should be cautious
- People with low blood pressure can benefit from increase salt intake
- Blood pressure in a part is regulated by sodium intake
- Also paper on it
[1:12:48](https://m.youtube.com/watch?v=azb3Ih68awQ&t=4368)
- Determining intake:
	- For most if drink water then you'll excrete the sodium that's to much and vise versa
	- But eating much more sodium then needed is bad cause some organs store sodium
	- If salt levels are low you'll crave salt (follow it if you eat healthy)
	- Should decrease intake of processed foods
	- Also depends on if it's hot or cold (dry)
	- Rule of thumb for workout is galpin equation
	- Normally you are thirsty after taking in salt but if it's mixed with sugar and other things then after a time feel tired (that's you being dehydrated, cause you didn't recognize you need to to drink)
	- The appetite isn't that accurate cause the body will adapt to a certain salt intake after time
	- It also regulates the water release not the only sodium
	- The system basically adapted to availability of sodium in the environment
	- History of salt (was expensive)
[1:16:53](https://m.youtube.com/watch?v=azb3Ih68awQ&t=4613)
- Talked about relationships between salt and iodine in other episode (which salt better iodine or not, some people maybe need more or less iodine)
- Iodine has direct effect on thyoride hormone and it's function (relates to metabolism)
- In most causes common table salt is fine
- Sea salt often contains other minerals that can be useful
- You won't get much if any minerals from table salt
[1:24:06](https://m.youtube.com/watch?v=azb3Ih68awQ&t=5046)
- Salt and stress:
	- Adrenal glands on top of kidneys
	- Make glucocorticoids like aldosterone these impact fluid balance and partly they do that by regulating craving and tolerence of salt we have
	- Study where they remove the adrenals (adrenalectomy)
	- Normally we prefer mild to moderate salty things but when no adrenals then prefer much higher sodium concentration
	- Shows the relationships between the stress system (glucocorticoid system) and the salt craving system
	- Low sodium levels can cause stress and anxiety
	- Makes sense cause stress system is designed to deal with various challenges of the body
	- Stress activates the immune system, long is different
	- So to counteract stressors could take sodium in
	- If sodium to low then ability to meet stressful situations is not that good
[1:28:01](https://m.youtube.com/watch?v=azb3Ih68awQ&t=5281)
- Other electrolytes:
    - Most people get there magnesium from their food intake
    - There is some evidence that you can remove muscle soreness by ingestion of magnesium malate
    - Magnesium thryonade for promotion of transition into sleep and perhaps can support cognitive function and longevity (typically taken 30-60 min before bedtime, has other episode on sleep where they talked about it)
    - Also other forms of magnesium
    - Sodium and potassium work closely together (lot of ratio recommendations out there, 2:1 ratio of potassium to sodium)
    - It depends on context
[1:32:29](https://m.youtube.com/watch?v=azb3Ih68awQ&t=5549)
- For low carb diets you'll excrete more water and also lose sodium and potassium
- Also with intermittent fasting
- Also caffeine cause it's a diaretic it causes excretion of the fluid in body
- If he drinks caffeine in fasting then he looks that he gets enough salt (like see salt)
- For every oz of coffee or tea consume 1.5 times amount of water and put tiny bit of sodium in
- If exercise while fasting also take in some electrolytes
[1:35:18](https://m.youtube.com/watch?v=azb3Ih68awQ&t=5718)
- General recommendations:
	- Book the salt fix
	- The authors recommendation was 8-12g salt per day (which is 3.2-4.8g of sodium)
	- 1.5-2 teaspoons of salt
	- Others (4g potassium, 400mg magnesium)
[1:43:27](https://m.youtube.com/watch?v=azb3Ih68awQ&t=6207)
- Relationships between salt and sugar:
	- Salt as taste (have salt receptors, neurons that fire when salty taste is there, same as sweet and bitter detectors)
	- They looked at parallel pathways salty taste in mouth and gut
	- Parallel pathways are a essential feature of every sensory system
	- So cause we have more red then greenness then we perceive it as more red then green (visual sensory system)
	- In many processed foods there is a business of putting in hidden sugars (it's a way of bypassing the body's system for sweet, neutralize the taste, to overindulge you in eating, through hidden sugars will crave food)
	- Also concept in cooking where you neutralize taste
	- A lot of food out there has a salt sweet combination (that can lead to you consuming more of it, if it have been just one of the two)
[1:45:56](https://m.youtube.com/watch?v=azb3Ih68awQ&t=6356)
- The closer the foods are to it's basic for and you only eat that the more accurate the salt craving becomes
- Sugar cravings can also be reduced
[1:52:53](https://m.youtube.com/watch?v=azb3Ih68awQ&t=6773)
- Sodium and neural function:
    - Action potential is the firing of electrical activity by neurons (neurons communicate with that)
    - Neurons have inside (their genetic material, things floating around to keep it function, wire extending outwards called axon, at end of axon release Pakets of chemicals that either let the next neuron fire or not) and outside
    - Neurons need to change there electrical activity (has negative charge usually, cause inside has floating around potassium/chloride and little sodium)
    - If the stuff in it is negative charged
    - Outside is positive charged (main factor of positive charge is sodium)
    - When neuron is stimulated by other neuron and the stimulation is high enough then little gaps open up in membrane of cell, that usually separates inside from outside
    - Cause a lot of positive charge outside the sodium rushes into the cell and the charge from the cell goes from negative to positive
    - If certain level of positive charge then it fires an action potential and puts out its own set of chemicals on the next neuron (so becomes a chain reaction)
    - So sodium is the way that neurons communicate with one another
    - The way the cells restore there charge is by pushing the sodium out of the cell, mechanisms for it (sodium potassium pump)
    - So having enough salt in body let's the brain function at all
[1:54:59](https://m.youtube.com/watch?v=azb3Ih68awQ&t=6899)
- Dehydration:
    - If drink to much water in short time you can actually kill yourself
    - That's called hyponotrimia
    - The problem is you excrete to much sodium quickly and ability to regulate kidney function is disrupted, and also brain actually could stop functioning
    - If the water doesn't have sufficient electrolytes
    - It's also this why dehydration leads to confusion and lack of coordination
[1:58:57](https://m.youtube.com/watch?v=azb3Ih68awQ&t=7137)
- What salt intake best for you?
	- In context of fluid intake, diet, amount of caffeine, of electrolytes more generally
