---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": The problem with eating plants
"url:": https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
---
<iframe title="The problem with eating plants" src="https://www.youtube.com/embed/HEET13WvR5I?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[11:30](https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=690)
- When using a part of a plant for medicine in western medicine we are always aware of the side effects
- In food sphere you don't consider that certain compounds of plants can have side effects
- We should weigh the benefits and the side effects
- He thinks there is nothing net beneficial in the plants
- As a plant it created defence chemicals to survive
- Plants want to spread their seeds
- What we typically think of as a vegetable are leaves/steams/seeds, nuts, grains, peas/roots
- Thinks plants want you to eat fruit (cause colorful, sweet)
- He thinks we are omnivorous humans
[12:00](https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=720)
- If thrive why change anything
- Shows studies
	- Shows warfare between plants and animals
    - Few defence chemicals of plants have been tested
[28:01](https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=1681)
- Tribes don't care about vegetables
- Hot spices influence leakiness of gut
	- So with pepper, paprika
    - Open tight junctions of intestine
[43:30](https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=2610)
- Meta-analysis looking if vegetables have a Positiv effect
- There are also no studies that show that vegetables are bad
- Oxidates are a defence chemical that can cause problems
[58:05](https://m.youtube.com/watch?v=HEET13WvR5I&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=3485)
- High oxalate plant foods
	- Tumeric is very high
    - spinache
    - No benefit in them
- Black pepper inhibits detoxification within the same meal
- Also phytic acid is a big defence chemical
	- Isn't better cooked (was thought that it is)
- Soy food decreases sperm count
- Psoralens in foods will effect our sensitivity to uv light
