---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How to Read Ingredient Labels & What To Avoid | Ultimate Human Short with Gary Brecka
"url:": https://m.youtube.com/watch?v=YFc2cD99dro&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:44
updated: 2024-06-24T19:45
---
<iframe title="How to Read Ingredient Labels &amp; What To Avoid | Ultimate Human Short with Gary Brecka" src="https://www.youtube.com/embed/YFc2cD99dro?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[9:45](https://m.youtube.com/watch?v=YFc2cD99dro&t=585)
- The food industry got creative with labeling categories instead of one ingredient
- Top 4 no no ingredients:
	- High fructose corn sirup (labeled as all natural sugars, hfcs, or entire name, also labeled as corn syrup/corn sugar/natural fructose flavoring/natural flavoring)
	    - Can lead to overeating and weight gaining
    - Sodium nitrate (a lot think its just salt, its not salt, not same thing, is not save says cancer institute)
	    - Good is (labels like grass fed/uncured/free range/nitrate free)
    - Aspartame (study on it, has effects on behaviorale and cognitive function, also second study, used as artificial sweetener)
    - Partially hydrogenated oils (as long as half a gram of trans fat in a thing it doesn't needs to be labeled (look for hydrogenated or partially hydrogenated in the label, hydrogenated in front of oil name)
