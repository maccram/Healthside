---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Gary Brecka’s 8 Methods to Increase Longevity on a Budget
"url:": https://m.youtube.com/watch?v=nI2n16DbVT0&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T19:39
updated: 2024-06-24T19:41
---
<iframe title="Gary Brecka’s 8 Methods to Increase Longevity on a Budget" src="https://www.youtube.com/embed/nI2n16DbVT0?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[37:25](https://m.youtube.com/watch?v=nI2n16DbVT0&t=2245)
- For defining Biological age you can use bio markers, telemere lengths, glygen age test
- 3 things to improve your longevity:
	- Get data (bloodwork)
    - Keep small promises to yourself (for example go to bed at ...)
    - Develop a morning routine (sunlight, grounding, cold showers, breathwork takes him 8 min)
- Middle category (under 1000):
	- Get genetic methylation test
    - Photobiomodulation (red light, some spas/gyms do have it)
    - PEMF matt (could be good after workout)
    - Targeted supplementation (vitamin d3, k3, methylated multivitamin)
	    - Beef is like a multivitamin
- High category:
	- Red light therapy bed
    - Hypermax
