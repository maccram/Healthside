---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Which Fermented Foods Can You Eat on Ketogenic Diet? – Dr. Berg
"url:": https://m.youtube.com/watch?v=MDlN_Qkzikg&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T10:27
updated: 2024-06-19T10:28
---
<iframe title="Which Fermented Foods Can You Eat on Ketogenic Diet? – Dr. Berg" src="https://www.youtube.com/embed/MDlN_Qkzikg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:29](https://m.youtube.com/watch?v=MDlN_Qkzikg&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=149)
- Problem with yoghurt is it's high in sugar (mostly 9-12g of sugar per serving)
- Kefir also quite same
- Kimchi/sauerkraut/pickles is good, don't need much of them few servings per week is fine
- Miso soup/Tempe (make sure it's organic)
- In keto you want the vegetables to be high to provide the fiber
