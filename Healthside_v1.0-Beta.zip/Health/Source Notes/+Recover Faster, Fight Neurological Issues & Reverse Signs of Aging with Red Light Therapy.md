---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Recover Faster, Fight Neurological Issues & Reverse Signs of Aging with Red Light Therapy
"url:": https://m.youtube.com/watch?v=aMLso7-yRUc&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:49
updated: 2024-06-24T19:50
---
<iframe title="Recover Faster, Fight Neurological Issues &amp; Reverse Signs of Aging with Red Light Therapy" src="https://www.youtube.com/embed/aMLso7-yRUc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[6:58](https://m.youtube.com/watch?v=aMLso7-yRUc&t=418)
- Red light had a lot of articles about it
- Red light therapy was comparable to anti depressants
- Benefitial for the immune system (so if you take medication that suppresses it that's not good)
- Red light therapy for exercise recovery (study about it, better recovery when done before workout)
- Most benefits you can get from red light you actually also get by sunlight
- When buying a red light panel it should have following wavelengths (680-720 nanometers, specifically has 810 one and 940)
- Also for post surgical repair
- Also studies showed reduction in reactive nitrogen species, reduction in prostaglandins
- Reduction in inflammation in brain, reduction in abdominal fat
- Good for wounds, lungs, spinal chord
[7:54](https://m.youtube.com/watch?v=aMLso7-yRUc&t=474)
- We have organell called mitrochondrial in cells (we have 110 trillion of these in body, actually 10% of body weight is actually mitrochondria)
- Inside mitrochondria there's a little motor its called the Kreb cycle (its what generates ATP)
- ADP is the actual life force as humans
	- The more adp the more energy our system has at a cellular level
[10:54](https://m.youtube.com/watch?v=aMLso7-yRUc&t=654)
- When light passes through skin it reduces inflammation, increases microvascular circulation
- Also at certain wavelength go to mitrochondria and kick out mitrochondrial nitric oxide and instead oxygen now can bind to the cell which leads to more efficiently (16 times more energy)
[14:53](https://m.youtube.com/watch?v=aMLso7-yRUc&t=893)
- Red light on scalp can regenerate hair follicles and thicken them, and increase the nutrients to the roots
