---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": Gastroenterologist Destroys Vegetable Concerns | Lectins, Phytic Acid, Anti Nutrients
"url:": https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
---
<iframe title="Gastroenterologist Destroys Vegetable Concerns | Lectins, Phytic Acid, Anti Nutrients" src="https://www.youtube.com/embed/r6HRgMr7_ns?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:42](https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=102)
- Anti nutrients
- Oxelates all plants have it
	- Even mammals have it
    - Sun exposure leads to them
    - Perhaps to stop insects
- Lectins, Phytates are other ones
- When eating them in modertation then they can be beneficial
[6:32](https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=392)
- Phytic acid
	- Typically found in grains, nuts and seeds
    - Concern is it can bind up minerals
    - He hasn't seen anyone with a balanced diet and high amount of phytic acid he didn't see some evidence of it happening
    - Also its a difference to only look at phytic acid and it being combined with other things in vegetables
    - People actually life longer consuming it
    - It seems to be anti inflammentory, anti oxidant
    - There are ways to reduce the phytic acid content one is fermenting (sour dough actually reduces in phytic acid and gluten when fermented), other way is soaking
[15:33](https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=933)
- Thomas carbs in his diet basically contain of lentils, legumes, fruits, vegetables. Kefir and cottage cheese
- Lectins:
	- All living beings produce lectins these are like signaling molecules
    - Evidence that it causes problems for humans comes in two forms test tubes studies, when people consume undercooked food (in the studies they got food poisons cause it wasn't cooked but they then didn't get any problems after it).
    - Undercooked food is higher in lectins
    - By cooking you remove the lectins to a point that they aren't even that noticable
    - Micro dosing stuff with lectins doesn't do you harm it is actually more beneficial (even studies on it lowers the risk of cancer)
    - Also not even that high consumption of things with it in America
- Anti frigal concept (giving little stress, to build some resistance to it)
[17:00](https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=1020)
- Blue zones healthiest populations
	- What they all eat is legumes so they consume there lectins
    - Also people that eat legumes life longer and it also has lots of health benefits
[19:00](https://m.youtube.com/watch?v=r6HRgMr7_ns&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=1140)
- He sees them as using them as additive
