---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "Fasting for Detoxification and Longevity: Ancient Wisdom Meets Modern Science | Ultimate Human Short"
"url:": https://m.youtube.com/watch?v=5V0I0U_YxQs&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T20:12
updated: 2024-06-24T20:13
---
<iframe title="Fasting for Detoxification and Longevity: Ancient Wisdom Meets Modern Science | Ultimate Human Short" src="https://www.youtube.com/embed/5V0I0U_YxQs?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:37](https://m.youtube.com/watch?v=5V0I0U_YxQs&t=157)
- He wrote ultimate guide to water fasting
- In ancient time fasting was used by a lot of civilication (Romans, greeks, egyptens), it was used to cleanse the body
- Also religion has fasting in it
- There are a lot of animals that use fasting
- Fasting and time restricted feeding improves metabolic health and logevity
[5:52](https://m.youtube.com/watch?v=5V0I0U_YxQs&t=352)
- Study showed that it effects health and longevity
- Body eats waste components in body if fasting (authpagy)
- It improves waste elimination, repair, detoxification and regeneration of cells (both fasting and caloric restriction have an effect
[12:42](https://m.youtube.com/watch?v=5V0I0U_YxQs&t=762)
- 3 day water fast:
	- 0-12h after last meal still digest some food and insulin still little high
	    - We want to be sensitive to insulin cause the less insulin it takes to regulate our blood sugar the longer we life
    - 12-18h 5s when fat burning begins
	    - Body in ketosis
    - 18-24h glucagon rises
	    - It counter acts the effect of insulin by stimulating the liver to turn stored glucose into sugars (gluconeogenesis)
    - 24-48h is when real magic happens
	    - waste elimination, repair, detoxification, cellular decision
        - Is called the cleansing part (more clearity in mind)
    - 48-54h tore magic happens
	    - Growth hormon is more
        - HGH is released to repair things
    - 54-72h is where insulin increases its sensitivity
	    - Authpaegy is highest there
        - Stem cells get released in bloodstream and hunt around for damaged/inflamed tissue
- Intermittent and water fasting has lots of benefits

