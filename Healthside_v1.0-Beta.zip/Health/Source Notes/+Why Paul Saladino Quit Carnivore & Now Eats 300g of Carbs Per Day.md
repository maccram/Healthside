---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why Paul Saladino Quit Carnivore & Now Eats 300g of Carbs Per Day
"url:": https://m.youtube.com/watch?v=Iz5PymNgnSY&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-19T10:44
updated: 2024-06-19T10:45
---
<iframe title="Why Paul Saladino Quit Carnivore &amp; Now Eats 300g of Carbs Per Day" src="https://www.youtube.com/embed/Iz5PymNgnSY?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[5:03](https://m.youtube.com/watch?v=Iz5PymNgnSY&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=303)
- You need insulin signal to kidney to hold on electrolytes
- We shouldn't fear glucose spikes in a metabolicly healthy human
- Carbs also improve performance with exercise, testosterone, recovery, sleep
[8:51](https://m.youtube.com/watch?v=Iz5PymNgnSY&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=531)
- Nomadic tribes favorite food:
    - Meat
    - Berries
    - Baobab
    - Tubers
    - Honey
