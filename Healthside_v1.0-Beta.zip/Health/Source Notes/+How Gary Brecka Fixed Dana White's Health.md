---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How Gary Brecka Fixed Dana White's Health
"url:": https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Joe Rogen]]"
created: 2024-06-19T10:36
updated: 2024-06-19T10:39
---
<iframe title="How Gary Brecka Fixed Dana White's Health" src="https://www.youtube.com/embed/D0EEC891CM8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="width: 545px; height: 301px; aspect-ratio: 16 / 9;"></iframe>
___
[3:25](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=205)
- Methylation (same as your car needs refined crude oil)
- There is no nutrient that enters body and is used in same version everything needs to be refined
- If you can't do that conversion you have a deficiency
- That process is called methylation (several genes that govern it)
- Really a disease is passed from a family member
[3:35](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=215)
- What we pass from generation to generation is the inability to refine raw material which causes a deficiency
[5:02](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=302)
- If you can't break the amino acid Homocysteine down to methionine, it will rise and it'll irritate the aterie
- That's irritation makes it shrink smaller thus higher blood pressure
[7:11](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=431)
- 120 over 70 is good
- High is 130/140/150/160
- 140/150 is dangerous
- It's a silent killer
- The gene mutation that is effecting it is mtrr
[9:22](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=562)
- Physicians really look outside the heart
[14:06](https://m.youtube.com/watch?v=D0EEC891CM8&pp=ygULZ2FyeSBicmVja2E%3D&t=846)
- For people with hypertension the amino acid Trimethyl glycine
- It helps to metabolis
- Diets high in high folate so leafy greens, grass fed meat, eggs, dairy ( these people will have lower cases of cancer)
- He thinks most of the diseases are due to nutrient deficiencies
