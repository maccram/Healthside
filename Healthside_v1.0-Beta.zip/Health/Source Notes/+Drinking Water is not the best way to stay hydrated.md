---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Drinking Water is not the best way to stay hydrated
"url:": https://m.youtube.com/watch?v=JAhvCuJNu3I&pp=ygUJdGFwIHdhdGVy&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-12T13:43
updated: 2024-06-13T06:40
---
<iframe title="Drinking Water Is NOT the Best Way to Stay Hydrated" src="https://www.youtube.com/embed/JAhvCuJNu3I?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[5:35](https://m.youtube.com/watch?v=JAhvCuJNu3I&pp=ygUJdGFwIHdhdGVy&t=335)
- Can create dehydration by drinking to much water too
- Condition called hyponotrimia (low sodium in the blood), deleted sodium with drinking to much water without salt
- If drink when not thirsty then can end up with low sodium
- Also other liquids can have diaretic effect
- The more sugar in blood the more the body is going to get rid of water in body and the more dehydrated you are going to be
- So glucose dehydrates
- Study on sport drink and soda (people with the sport drinks gained more weight)
[7:36](https://m.youtube.com/watch?v=JAhvCuJNu3I&pp=ygUJdGFwIHdhdGVy&t=456)
- To be truly hydrated you need all electrolytes (sodium, potassium, chloride, calcium, magnesium)
- Book water log
[9:35](https://m.youtube.com/watch?v=JAhvCuJNu3I&pp=ygUJdGFwIHdhdGVy&t=575)
- You can use Urin strips to measure if you are hydrated
- You measure specific gravity there (basically measures how concentrated the Urin is compared to water)
- Water has density of 1 and Urin should have one from 1.002-1.03
- Less then 1.010 then that's mild hydration
[10:14](https://m.youtube.com/watch?v=JAhvCuJNu3I&pp=ygUJdGFwIHdhdGVy&t=614)
- A lot of electrolytes are coming from food
- But there are also things that will deplete the electrolytes (coffee, tea, alcohol, fruit juice, soda, sugar drinks)
