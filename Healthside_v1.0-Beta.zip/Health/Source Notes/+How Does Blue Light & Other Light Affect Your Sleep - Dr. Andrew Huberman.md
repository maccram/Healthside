---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": How Does Blue Light & Other Light Affect Your Sleep? | Dr. Andrew Huberman
"url:": https://m.youtube.com/watch?v=ZrywkDJ8W9k&pp=ygUcYmx1ZSBsaWdodCBibG9ja2VycyBodWJlcm1hbg%3D%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
---
<iframe title="How Does Blue Light &amp; Other Light Affect Your Sleep? | Dr. Andrew Huberman" src="https://www.youtube.com/embed/ZrywkDJ8W9k?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:44](https://m.youtube.com/watch?v=ZrywkDJ8W9k&pp=ygUcYmx1ZSBsaWdodCBibG9ja2VycyBodWJlcm1hbg%3D%3D&t=104)
- Dim the lights at night
- Blue light blockers aren't necessary
[4:13](https://m.youtube.com/watch?v=ZrywkDJ8W9k&pp=ygUcYmx1ZSBsaWdodCBibG9ja2VycyBodWJlcm1hbg%3D%3D&t=253)
- Place the light lower (desk lamps, lamps on floor)
- At night use as little light as possible
- Ideally candle light/moon light (both very low light intensity, candle only 3-5 lux)
- Worst lights are overhead floristic lights
- The bright light will destroy melatonin
- Between 10 pm and 4 am avoid the bright light
[5:32](https://m.youtube.com/watch?v=ZrywkDJ8W9k&pp=ygUcYmx1ZSBsaWdodCBibG9ja2VycyBodWJlcm1hbg%3D%3D&t=332)
- Actually lower part of retina is there to get the overhead light in eye

