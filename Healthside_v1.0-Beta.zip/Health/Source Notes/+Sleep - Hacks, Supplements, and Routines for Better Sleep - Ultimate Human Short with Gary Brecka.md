---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Sleep - Hacks, Supplements, and Routines for Better Sleep | Ultimate Human Short with Gary Brecka
"url:": https://m.youtube.com/watch?v=yz0gpMB3z4I&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:43
updated: 2024-06-24T19:44
---
<iframe title="Sleep - Hacks, Supplements, and Routines for Better Sleep | Ultimate Human Short with Gary Brecka" src="https://www.youtube.com/embed/yz0gpMB3z4I?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:13](https://m.youtube.com/watch?v=yz0gpMB3z4I&t=73)
- People who sleep 6 1/2 to 7 1/2 tend to live the longest
- Average person needs 10-15min to fall asleep (if just in under 5min then probably sleep deprived)
- Average person wakes up 2-6 times a night this is normal
- We spend 25 years of our life sleeping
[1:58](https://m.youtube.com/watch?v=yz0gpMB3z4I&t=118)
- Blue light reduces the production of melatonin
	- Also reduces the amount of time in rem phase, which is needed for cognitive function
- Make bedroom a sanctuary
- Before bed dim light
- Good habits for night routines are:
	- Bed time tea
    - Warm baths
    - Stretching
    - Breathing
    - journaling
    - Trick is to be consistent
- Box breathing (4sec inhale..., have been shown to put people in relaxed state)
- Routine is good for sleep
[3:32](https://m.youtube.com/watch?v=yz0gpMB3z4I&t=212)
- He is fan of magnesium theine and melatonin
- Magnesium decreases cortisol levels (wakening hormone) and increases melatonin
- Interesting sleep rule
	- Rule: 10 3 2 1 0
    - 10h before bed no caffeine
    - 3h before bed no food or alcohol
	    - Sleep medication is not good
    - 2h before sleep no more work
	    - Do work somewhere else not in bedroom
    - 1h before sleep no screen time
    - 0 times hit snooze button
	    - That extra minutes don't help you
- Best thing to do in bed is journal to get thoughts out
[13:20](https://m.youtube.com/watch?v=yz0gpMB3z4I&t=800)
- He likes to use box breathing when trying to fall asleep
