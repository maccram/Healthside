---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Using Caffeine to Optimize Mental & Physical Performance | Huberman Lab Podcast 101
"url:": https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-24T20:08
updated: 2024-06-24T20:09
---
<iframe title="Using Caffeine to Optimize Mental &amp; Physical Performance | Huberman Lab Podcast 101" src="https://www.youtube.com/embed/iw97uvIge7c?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:16](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=76)
- caffein acts as a strong reinforcer (we like foods and drinks more)
- 90% of people consuming caffeine
[7:03](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=423)
- Glp-1:
	- is a Molecule that's found in certain caffeinated drinks
    - Benefitial for weight loss, mental performance and controlling blood sugar levels
    - Acts on brain and body
    - Reduces hunger by
	    - activating certain neurons in the hypothalamus
        - And acts on certain receptors on the gut to make us feel full
    - There are animals that use that to not eat for a long time
    - Also drug that intimitates glp-1 (effective against obesity and diabetes, but those should only be used in extreme cases)
    - Promotes thermogenesis (is utilization of metabolic energy)
	    - Beige, brown fat cells are fat cells you want more off (they generate heat, have lot of mitrochondria)
        - Helps convert weight into brown/beige ones
	        - Cold shower has same effect
        - Also raises base energy burning
    - Other ways to release it is fasted exercise and certain formes of exercise
- Yerba mate:
	- Yerba mate stimulates the glp-1 release
    - Smoked variants are carcinogenic (pro cancer causing)
[20:38](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=1238)
- Caffeine Benefits for mental and physical performance:
	- Has certain neuroprotective effects (increases Neuro modulators like Dopamin/catecholamines/norepinephrine)
	    - Increase motivation, drive
    - Has antidepressant effects
    - Positiv effect on mood
    - Can improve mental and physical performance
	    - If not lot of food and blood sugar not high then we increase alertness within 5 minutes, peak in 30 min and holds on till 60 min
        - Caffeine improves reaction time of brain and body
        - Better to access circuits of learning and memory
[27:00](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=1620)
- Caffeine in nature:
	- It's acting as a reinforcer of experience
    - Reinforcer
	    - Can be applied to conscious reward (financial, recognition)
        - But also ways caffeine stimulates the release of chemicals in body that act as reinforcers thus they are subconscious
    - Study on that
	    - Lot of plants contain little of caffeine and we won't notice it, or other favours are stronger
        - The caffeine in flowers acts as reinforcer for the bees (they prefer those flowers)
[27:13](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=1633)
- Caffeine stimulates the reward pathway in different way then addiction/reward
[34:10](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=2050)
- Caffeine impacts adenosine which then offsets sleepiness
- Effects of caffeine are largely subconscious
- Reinforcing agents:
	- If feel bad then you also reinforce that you will less likely drink the beverage again
    - So strong can also cause vomitting
    - Caffeine exact opposite
- People will like bitter taste of things more due to coffein
[36:15](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=2175)
- Caffeine increases Dopamin receptors in the reward pathway (Positiv things have more potent effect)
- Reduces feeling of fatigue and sleepiness
[41:14](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=2474)
- Caffeine binds to two types of adenosine receptors (A1, A2 receptors)
- Adenosine makes us feel tired cause it taps into ATP pathway
- When caffeine binds to adenosine receptors it prevents adenosine from breaking down certain components of energy pathway and cyclic amp increases
- You only borrow energy don't really create new one
- You rather just change the timing of the sleepy signal
- When wake up in morning (provided you sleeper well) will be as low as they can get
- To really get adenosine low you should avoid caffeine in first 90 to 120 min of waking (cause there is a way to complete clear out adenosine in that time)
- Before we didn't use caffeine we where more or less bond to the light cycle
- Healthiest schedule is working on day and sleeping in the night
- Adenosine in direct proportion to how long you've been awake
- The only way to clear out adenosine is to sleep, or take a nap, or viewing morning sunlight, also intense exercise can decrease it
[47:07](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=2827)
- Tool:
	- Dose:
	    - Not everybody will respond same way
        - For most people 1-3mg caffeine per kg bodyweight is range where it will has Positiv effect
        - Start on lower amount if start out
        - Timing relative to tasks/sleep
        - Is one dose per sitting (not throughout day)
        - So if want more times of a day then can use the amount and then separate it to different times
    - Tolerance without feeling anxious:
	    - Preexisting Disposition (genetic, how much stress, etc.)
        - And how caffeine adapted you are (if alert and relaxed then probably not adapted)
    - Too much not really that good
[1:02:36](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=3756)
- Delayed caffeine intake:
	- 90-120min after waking up
    - People who drink the caffeine directly when waking up typically have a afternoon crash
    - If ingest caffeine within 8-10h even 12h before sleep that disrupts sleep
    - Some need short nap, or non sleep rest for 10-30min in the afternoon which is healthy
    - when delaying you offset the afternoon crash (due to adenosine being delayed and then caffeine effect go away)
    - Has own episodes on sleep and a toolkit on his website
    - To clear out adenosine completely is to spike the cortisol
	    - Chronic cortisol bad, normal one good, enhances the efficientcy of our body
        - Good when released to cycadian cycle so at right time with right amount
        - Late shifted cortisol peak is one marker of depression
        - Want early cortisol peak early in day, can achieve that by getting bright light in eyes (go outside 20-30min is good)
	        - Increased peak when sunlight until 1h of waking
[1:05:54](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=3954)
- Also has toolkit for fitness (he follows that program)
- When exercise in morning then can take caffein
	- It will increase afternoon fatigue though
[1:14:00](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=4440)
- Coffee has quarter life of 12h, so 25% of caffeine effect is still there after 12h
- Caffeine on empty stomache more intense effect
- To offset jitteriness you can take theanin
- He its his first meal at 11am and last mealn at 8pm (not set in stone though)
- If use caffeine 2-4 times a week then not regular user (regular is everyday for last 2 weeks)
- If really want the best effects then either take some days off it or use it on empty stomache
- Caffeine is a diaretic so we lose fluid thus sodium, so make sure to consume at least equal amount of water (and add little salt to water, this will offset jitteriness)
[1:14:04](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=4444)
- Theanin not that good before bed if vivid dreams/night terrors/sleep walking
	- Is in green tea
- Tends to stimulate glutamate and Glutamin pathway
- general effect is to compete for the receptors of certain neurotransmitters (all excitetory ones)
- Theanin does decrease alertness a little bit
- 200-400mg of it are effective to offset the jitteriness
- Also data on reduction do depression and anxiety when taking it, also increase in Funktion of blood vessels
- Pro sleep effect when taken before sleep
- Peak of theanin is after a 1h
[1:26:22](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=5182)
- One myth about caffeine is that it can increase osteoporosis (if enough calcium in diet no problem)
- Other myth is that reduce/increase testosterone/estrogen (no real consistent changes, but increases sexhormone bonding globulin which effects free testosteron/estrogen)
- Testosteron/estrogen control a lot of sexual function that's why we need it
- Caffeine has positiv effect on depression
[1:28:32](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=5312)
- Sleep:
	- Foundation of health (most important thing you can have)
    - Avoid caffeine intake 12h before sleep
    - Author of the book why we sleep also talks about that
[1:44:18](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=6258)
- Caffeine and performance:
	- Improves reaction time/ coordination/memory/focus/mood
    - In physical performance improves power output/insurance/feeling good while exercising
    - A lot of studies show that these metrics are improved
    - The way in which caffeine is taken is important (used abstinence of users in most studies)
    - Book by Michael Pollan all about caffeine
	    - Most people don't even know there basic ability cause they always drink caffeine
    - Could abstine from caffeine for improving physical performance (higher effect then just taking caffeine)
	    - If want max effect then abstine for 20 days (ingest then 30min before performance)
        - Could also do 5 days (also some study that 2 days already has benefits)
    - People best perform with mental tasks when on same state that they learned
    - If not accustomed to caffeine then shouldn't take caffeine at the day of performance
[1:46:22](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=6382)
- Caffeine effects on menstrual cycle
[1:52:44](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=6764)
- Memory:
	- 30min before mental task is benefitial
    - But also case that after learning can increase memory (cause spike of adrenalin)
	    - Effect I learned in [[{Fluent forever]], cause its effect when under adrenalin and have to remember it is helping memory
        - Would do that by cold exposure, or could be to take caffeine after
    - Maybe could use that for affirmation/visualisations that the brain thinks the statements (thoughts) are more important
    - We eighter can have Dopamin spike (positiv surprise), adrenalin (can be both Positiv and negativ)
    - Increase in catacolamins lock in memory for things that leaded to their increase
    - Could even combine that with cold shower
    - 10-50min intense exercise also increases the memory of the things we wanted to learn prior
[1:56:16](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=6976)
- Nap and caffeine (Napa chino):
	- Not really good cause take caffein in afternoon
    - 90min naps or NSDR all increase dopamine and also improve mood alertness on its own
    - Also caffeine probably reduces the effects of the nap
[1:59:52](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=7192)
- Study run treadmill and eighter caffeine or not
- Looked at neurotransmitters (dopamine and others), also looked on hormones
- Workout on its own increases cortisol, dopamin and catacolamins and neurotranmitters
- Ingesting caffeine prior to exercise also increases Dopamin release with exercise
	- Has long lasting effect of increase in alertness, focus and motivation even after exercise
    - Dopamine and caffeine act as reinforcer
- So to enjoy exercise more and also the activities that follow exercise
[2:06:04](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=7564)
- Dopamine stacking:
	- If difficulty with motivation then should avoid dopamine stacking (like caffeine, loud music, intense workout)
    - Good when some times
    - Also when stack more then peak will be higher thus also bigger drop
    - If you try to come increase to baseline won't work cause you'll drive the baseline lower and lower
    - Don't want to get in the habit of doing it every time
    - Be aware on how you feel after the dopamine goes away
    - Also don't stack to many stimuli
[2:08:37](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=7717)
- So using caffeine every other day is also good
- 3-4 days a week
[2:11:54](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=7914)
- It might be that caffeine reduces some of the probability of getting parkinson's and Alzheimer's
- Caffeine has neuroprotective effect
- Also evidence when taken with aspirin it reduces headache
- Helps with asthma
- Improves attention in ADHD patients
[2:20:21](https://m.youtube.com/watch?v=iw97uvIge7c&feature=youtu.be&t=8421)
- Caffeine can be placed in every beverage to make us like it
- You can use caffeine as tool for reinforcement
- If sugar craving maybe have something with both caffeine and sugar
