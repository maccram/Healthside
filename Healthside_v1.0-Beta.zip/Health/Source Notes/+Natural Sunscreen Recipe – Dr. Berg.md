---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Natural Sunscreen Recipe – Dr. Berg
"url:": https://m.youtube.com/watch?v=P6S7Turdha8&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-24T19:52
updated: 2024-06-24T19:52
---
<iframe title="Natural Sunscreen Recipe – Dr. Berg" src="https://www.youtube.com/embed/P6S7Turdha8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:42](https://m.youtube.com/watch?v=P6S7Turdha8&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=42)
- Recipe:
	- 1/2 cup coconut oil
    - 1/4 cup olive oil
    - 1/4 cup aloe vera
	- Just slightly heat it that it can melt
    - Then add 2tbs zinc oxide (non-nano)
