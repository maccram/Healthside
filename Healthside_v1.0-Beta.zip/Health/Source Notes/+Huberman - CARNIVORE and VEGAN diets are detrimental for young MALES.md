---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Huberman - CARNIVORE and VEGAN diets are detrimental for young MALES
"url:": https://m.youtube.com/watch?v=-dmCQPwawVo&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-19T06:55
updated: 2024-06-19T06:57
---
<iframe title="Huberman - CARNIVORE and VEGAN diets are detrimental for young MALES" src="https://www.youtube.com/embed/-dmCQPwawVo?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[3:57](https://m.youtube.com/watch?v=-dmCQPwawVo&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=237)
- Diary good for lgf1 (helps grow, long bone growth, skin and hair growth)
- Vitamin d (helps with testosterone production, bone mineralization)
- After 25 (optimizing growth hormone and igf1 helps with bone density and bone growth)
- You want to have enough free estrogen from dietary point
- Huberman said he always had been a omnivore
- With that diets have less free estrogen
- Fiber good (helps with brain development)