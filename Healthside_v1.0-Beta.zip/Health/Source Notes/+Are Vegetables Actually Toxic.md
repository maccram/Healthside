---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": Are Vegetables Actually Toxic..?
"url:": https://m.youtube.com/watch?v=NdxNGwDMQ7o&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Radical Health Radio]]"
---
<iframe title="Are Vegetables Actually Toxic..?" src="https://www.youtube.com/embed/NdxNGwDMQ7o?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[3:34](https://m.youtube.com/watch?v=NdxNGwDMQ7o&t=214)
- Not all anti nutrients are created equal, they also don't come in equal amounts in different food
- Want to be aware of high amounts of phytic acid, oxalic, acid or oxalates, lectins (not all lectins are equal), goitrogenic compounds
- Mostly are in grains nuts and seeds
	- Have most chemical defense cause they are the reproduction of the plants
- Methods to get rid of some are soaking, sprouting and fermenting
- When coming to vegetables it really comes down to the concentration
- Leaves of plants tend to have more anti nutrients compared to the root
- Cooking leaves is good way to lower anti nutrients
- We also want to have it not as main part of diet and have them in moderate amount
- Although in some cases polyphenols and fibers can be helpful in some cases
- Often times people say that certain vegetables have lot of nutrients but they don't consider the anti nutrients
- Root vegetables have least amount of anti nutrients (cause they are already underground)
- Skin typically has more defense then the inside
[4:21](https://m.youtube.com/watch?v=NdxNGwDMQ7o&t=261)
- Bloating, gas, slow motility, irretation, stomache aches are all sign that we have probably a already imbalanced gut microbiom
- In such a situation we want to be more careful and even decrease fiber consumption and being careful of which carbs to use
- We not want to cut out carbs all together but change to ones that are easier to digest like honey, ripe fruit, fruit juice even.
