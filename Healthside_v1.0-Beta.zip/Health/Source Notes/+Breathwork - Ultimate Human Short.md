---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Breathwork | Ultimate Human Short
"url:": https://m.youtube.com/watch?v=gLHemX0IE3I&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T20:11
updated: 2024-06-24T20:12
---
<iframe title="Breathwork | Ultimate Human Short" src="https://www.youtube.com/embed/gLHemX0IE3I?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[8:49](https://m.youtube.com/watch?v=gLHemX0IE3I&t=529)
- Could go down the rabbit hole there's shamanic/vivation/pranayama/transformational/holotropic breath work
- Good for longevity/depression/mood/digestion/even increasing bodies ability to absorb certain nutrients and helping mictobiom
- His favourite for beginners is wim Hof type:
	- After 30min of waking he does it
    - He suggest starting with 3 rounds of 5 breaths and then every day add one breath, end goal is 3 rounds of 30 breaths
    - Breath holding in between
    - It's like exercise you need to train it to get better
    - Normal to get light headed and have tingly hands
    - Breath as deep as possible (diaphragm moving, use entire lung)
    - He raises shoulder and also pull belly out
    - After the rounds hold breath and focus on noise around, get out of head (tongue at top of mouth)
    - The longer you hold breath the better
    - After can't hold breath and then get deep breath and hold again
    - Should be the one thing that you never miss
