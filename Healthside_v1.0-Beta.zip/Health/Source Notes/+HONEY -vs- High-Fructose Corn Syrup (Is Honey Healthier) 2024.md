---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": HONEY -vs- High-Fructose Corn Syrup (Is Honey Healthier?) 2024
"url:": https://m.youtube.com/watch?v=QdmuFyKJEuQ&pp=ygUcV2h5IGhvbmV5IGlzIG5vdCBnb29kIGhlYXRlZA%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@KenDBerryMD]]"
created: 2024-06-24T20:01
updated: 2024-06-24T20:02
---
<iframe title="HONEY -vs- High-Fructose Corn Syrup (Is Honey Healthier?) 2024" src="https://www.youtube.com/embed/QdmuFyKJEuQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[6:01](https://m.youtube.com/watch?v=QdmuFyKJEuQ&pp=ygUcV2h5IGhvbmV5IGlzIG5vdCBnb29kIGhlYXRlZA%3D%3D&t=361)
- Study about response to honey, sugar, high fructose sirup
	- Blood sugar was checked after 20, 60, 90, 120 minutes after ingestion (if want to check then use that)
    - Also checked insulin levels
    - Glucose response was same in all 3 the same (with people with normal glucose Toleranz)
    - Also pretty similar with people with a impaired glucose Toleranz
    - Insulin spike after all 3 also
    - Also triglyceride levels also go up afterwards
    - Also checked hsCRP (inflammation marker) only increased in people with impaired glucose tolerance
