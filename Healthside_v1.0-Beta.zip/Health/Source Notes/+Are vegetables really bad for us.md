---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Are vegetables really bad for us?
"url:": https://m.youtube.com/watch?v=zXPEiHROisY&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:52
updated: 2024-06-24T19:53
---
<iframe title="Are vegetables really bad for us?" src="https://www.youtube.com/embed/zXPEiHROisY?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[3:22](https://m.youtube.com/watch?v=zXPEiHROisY&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=202)
- The most important thing he wants the audience to get is that following things aren't good
	- Seed oils
    - High fructose sirup
    - Artificial sweeteners
    - Vegetables (if thrive then don't worry, consider it mostly when gut issues or autoimmune disease)
- He thinks there is no nutrient that you can't get in better and higher amount from meat/organ/fruits/raw dairy
