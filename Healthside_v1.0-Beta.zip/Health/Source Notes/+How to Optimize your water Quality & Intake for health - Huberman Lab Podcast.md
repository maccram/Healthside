---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How to Optimize your water Quality & Intake for health
"url:": https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-12T14:11
updated: 2024-06-12T14:16
---
<iframe title="How to Optimize Your Water Quality &amp; Intake for Health | Huberman Lab Podcast" src="https://www.youtube.com/embed/at37Y8rKDlA?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[3:07](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=187)
- pH of water has impact on how you can absorb and utilities that water
- And also have impact on certain bio systems
[3:19](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=199)
- Temperature affects rate of absorption and impact on cells/tissues/organs
[3:27](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=207)
- Zero to low cost tools to get most out of water
[3:33](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=213)
- When and how to hydrate your body best
[4:22](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=262)
- Cold exposure has benefit on fat loss, reduce inflammation, increase metabolism, increase in mood and focus
- 6h after strength training no cold plunge and cold showers don't effect that
- Look at cold exposure episode for more
[10:48](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=648)
- They had 3 degrees cold water for 2 min, once a week
- In addition they did minimum of 5 cold showers per week (10 degrees, just for 30 seconds)
- Subjects should warm up naturally after exposure (not from cold to warm, 10 min period)
[12:20](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=740)
- A lot of benefits found
- Better mood, sexual satisfaction improved (could be to testosterone increase)
- Improvement in anxiety regulation
- Fat loss after 8 weeks
- Study in description
[14:29](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=869)
- If do cold shower you want it to hit head, back of neck and back
- Triggers adaptation of brown fat especially when those areas are hit
[18:22](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=1102)
- He is not on a keto diet
[24:42](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=1482)
- H2O is polirized
- Positiv + negativ connect
- The molecules can arrange themselves in different ways
- Temperature determines the arrangement strongly
- 3-4 forms of water (liquid, gas, etc.)
- Other then other things water is less dense in it's solid state
- That's also why ice floats
- If that wasn't life wouldn't probably even exist
[28:06](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=1686)
- The surface level of water let's certain things float there
- It's cause there is a very thin layer on the water surface that is more dense
[31:19](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=1879)
- 4th phase of water is structured water
- In presence of certain solids/liquids the water molecules can change
- It's when in an environment the Positiv molecules allow to attract one another
- These bond's are stronger then
- Some people believe that structured water also is in our body
- Example would be water on glass that forms something like a bubble
- Water can also bind to certain surfaces
[34:34](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=2074)
- pH and temperature important on how body uses water
- There are own biological mechanism that are there to get water in our cells at different rates and use it in different ways
[36:25](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=2185)
- Water is the one molecule that has a big impact on our bodies
[40:29](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=2429)
- Water can change the confirmation of other things (dissolve something)
- They dissolve cause they are hydrophilic
- Water is a better dissolvent then acid
- Lipids (oils) won't easily dissolve in water (they are hydropholic)
- Bind vs not bind
- pH and temperature will have impact on if eighter of those has a greater or worse tendency to interact with water
[54:15](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=3255)
- Every cell needs water
- Water can access body through drinking and also through inhaling of humid air
- Water needs to move from stomage to bloodstream to cells
- Two ways water can access cells:
	- First way is diffusion: outside of most cells is out of lipid, water and that lipid alter just so that they can connect and the water can be dissolved, this takes much longer then the second way
    - Second way is by aquaporin channels: this are portables through the membrane where the molecules can pass through (1 million per second), the inside of those channels is very hydrophobic
- The reason of two ways is that there are certain tissues that need water often very quickly or release it (tear glands, also in gut)
- There are really no cell that doesn't have the aquaporin channels besides bones and ligaments to some extend
- Pasha tissue might be interesting
- Aquaporin channels can be used in when we move from low to high mobility states
- The movement through that channels is heavily dependent on water temperature and ph
- The pH of the body (pH of cells at different locations) is strongly homeostaticly regulated meaning it doesn't change that much (bio mechanical processes that ensure it stays the same)
- True that different cells different ph ( between 7,2-7,4, gut pathway very different ph)
- Thus pH of water doesn't affect the pH of body but it's still important
- If pH is to low it will not move as quickly from gut into the cell
- True that more alcalin water (pH>7,4) can move more easily
- Absorbed more quickly (if not to high pH)
- Don't need high pH water to hydrate body well
[55:13](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=3313)
- Can by temperature or filtering water to affect the rate of absorption of water in the gut
- That will reduce inflammation and also makes sure you get proper hydration of different cell types in the body
- Also rapid hydration of brain cells that can enhance cognitive function
[59:09](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=3549)
- If water is in the cells it's going to be incorporated through different proteins, organelles
- Many of the processes involve the bonding or lack of bonding with water molecules and proteins
- Reactive oxygen species (or free radicals, anti oxidants, all that really describes the presents or absents of charges that are bound or unbound)
- Free radicals can damage cells because they are free electrons (cause they are free they can bind to cells and change them causing the damage)
- Cells deal with those free radicals through anti oxidants (they are molecules that can be in different forms, sometimes vitamins, they bind up free radicals or repair bonds between cells so that the cells don't have the bad influence anymore)
- There is no disease that doesn't have Ros
- Also no benefit into antioxidant interference getting in the way of the oxidative process
- All learned so far is organic chemistry
[1:00:50](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=3650)
- Water can act as antioxidant if it bonds to things in proper way which requires it to go into cells in the right amount and rate therefore the temperature and ph must be correct
- Also there needs to be enough water and it shouldn't contain things that are damaging
- Potentially carring good things in it potassium, sodium
- When water is inside cells then it can interact and change conformation of different proteins and exelerate or slow down different cellular reactions
- Water can effect disease, health, repair of different cells
[1:14:10](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=4450)
- Baseline hydration:
- How much?
- Independed of body weight
    - For every hour awake in the first 10h of the day you should consume on average 8oz (240ml) of fluid
        - So that's 2,4l of water in first 10h
        - 10h cause in night requirement not that high
        - If exercise then more fluid needed (there is galpin equation, bodyweight in pound/30 = number of oz fluid to ingest every 15-20min on average while exercise, in metric 2ml per kg every 15-20min)
        - For performance it is recommended to consume it consistently in workout otherwise it's just on average
        - If exercise for 1h then can replace 8oz of baseline by galpin Formular
        - Sweeting is adapting (can sweat more)
        - Exercise in hot environment 50-100% increase the galpin
        - In sauna more like 8oz or even 16oz
        - If feel hydrated then drink more (then fluid with no diaretics)
    - Can't we just follow natural thirst?
    - Can Urin color indicate if we are hydrated or not?
    - There are many studies that show that when we are dehydrated our body and brain doesn't function as well (even 2% has impact)
    - It effects physical performance, cognitive performance (memory, focus, creative thinking, flexible thinking)
[1:23:29](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=5009)
- Double fluid intake for hot environment exercise or sauna
- If feel dehydrated then can drink more like 16oz per hour while feel dehydrated
- Thirst reasonable guide for when we are dehydrated but it doesn't really keep up with our bodys level of dehydration
- If feel dehydrated then ideally drink something without caffeine or other diaretics (cause release of urination out of body)
- If use caffeine put I'm some sodium and potassium, magnesium
- If caffeine then increase non caffeine intake to a 2:1 for every volume caffeine
- Dehydration can show up in brain fog
- Fluid intake elevates alertness it's due to the sympathetic arm of the autonomic nervous system (aspect that makes you more alert)
- When we have fluid in gut, cells are well hydrated and our bladder contains fluid there is a elevated activation of the sympathetic nervous system by two pathways
- Mechanical: stretch receptors (bladder and gut, like trp/peaso), these cells and channels sense temperature/mechanical pressure or expansion of tissue (mechano sensetion)
    - Chemical level (sends info to areas of brain associated with sympathetic arousal which makes us more alert, that's what wakes us up in sleep if we need to pee)
- Alertness translates to enhanced cognitive/physicsl function
[1:28:25](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=5305)
- Filtration of fluids by body by kidneys and by way of bladder and through urination is cycadian depend
- Cells of especially kidney, gut (actually all) all that is under strong control of the cycadian clock genes (influence level of activation of organ)
- Thus for first 10h kidney most active
- Filtering of kidney not only depends on volume but also on rate of ingestion
- So drinking fast, so faster put it out
[1:36:00](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=5760)
- Tap water:
	- It's not a good outlook if you look on what's contained in it
	- Much if not all tap water contains bad things
	- Hard water contains magnesium and calcium which is good (that in general effects the pH, the higher concentration the higher pH)
	- DBP (disinfection byproducts) concentration (water treatment facilities treat water with that products and that products create byproducts, that can strongly impact pH of water by changing concentration of magnesium and calcium)
	- DBPs can cause endogene disruption that are not good for reproduktiv health (has video on fertility and vitality)
	- Google zip code and ask for water analysis of the tap water
	- You should look if there are high low or moderate levels of fluoride in it
	- Concentration of Fluoride is a concern for the thyroid hormone system
	- Thyroid has lot of roles in brain and body
	- It is very important
	- Study on impact of fluoride (effects t3 hormones, even in standard concentration 0.5mg per l)
[1:41:39](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=6099)
- How best filter drinking water:
	- Range from carbon type filters (Brita type filters) can work if change filter often enough, but not Filter out Fluoride
	- Search for at home water filters that filter out Fluoride
	- Link in the description
	- Could also get whole house water filter (cost more)
	- Intermediate ones are ones like birckey
[1:54:04](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=6844)
- Higher magnesium in water can lower cardiovascular mortality
- Magnesium 8,3-19,4 mg per liter had decreased likely hood of cardiovascular mortality by 25% compared to 2,5-8,2 mg per liter
- Numbers from study
- So turns out that harder water is better
- The major effect by which magnesium and calcium effect the cardiovascular health, is that the waters pH is higher (7,9-9/9,2) therefore better absorbed and that benefits the cardiovascular system
[1:55:35](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=6935)
- Boiling water will not help with the containment cause some are made even worse through it
- He mentioned he is carnivore
- Cold water will be slower to absorb
[2:02:26](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=7346)
- Water types:
	- Distilled, double distilled (magnesium and calcium removed), better not drink it
    - reverse osmosis ( it ideally let's magnesium and other minerals in it, but lower amounts of it)
    - Deuterium depleted water (water extracted near sea levels have more deuterium in them, is the enrichment or lack of hydrogen in the water)
    - Electrolyte reduced water also as hydrogen rich water, or hydrogen enriched water or deuterium depleted water all having the property of having higher pH then other forms of water
[2:10:21](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=7821)
- Hydrogen enriched water:
	- You can create it when putting magnesium tablets in water
    - You should drink it 5-15 minutes
    - There is a review on it
    - So basically that all comes down cause the hydrogen also increases the pH which is the real factor
    - Also study on it
    - Reduced inflammation
    - He also drinks it
    - If tap water already has high magnesium then he thinks you don't need to hydrogen enrich the water (although analyze the water and filter out byproducts)
[2:12:00](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=7920)
- To create hydrogen water is to purchase molecular hydrogen tablets which are basically magnesium tablets that resolve in water and create free hydrogen
- Study that explains how it works
- Other magnesium tablets won't work
[2:13:52](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=8032)
- Want to do it once or twice a day
- Don't need to do it in all water you drink
- Also don't want to put them into carbonated water, also not hot water
[2:17:41](https://m.youtube.com/watch?v=at37Y8rKDlA&pp=ygUadGFwIHdhdGVyIGFuZHJldyBodWJlcm1hbiA%3D&t=8261)
- Not only the water source is important also the pipes and the faucet mash (filter)