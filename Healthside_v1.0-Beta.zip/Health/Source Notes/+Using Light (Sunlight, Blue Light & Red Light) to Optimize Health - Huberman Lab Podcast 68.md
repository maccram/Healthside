---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "Using Light (Sunlight, Blue Light & Red Light) to Optimize Health | Huberman Lab Podcast #68"
"url:": https://m.youtube.com/watch?v=UF0nqolsNZc&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-19T10:42
updated: 2024-06-19T10:43
---
<iframe title="Using Light (Sunlight, Blue Light &amp; Red Light) to Optimize Health | Huberman Lab Podcast #68" src="https://www.youtube.com/embed/UF0nqolsNZc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:56](https://m.youtube.com/watch?v=UF0nqolsNZc&t=56)
- So powerful health impact cause light can be translated into electrical signals/hormone signals in brain and body
- Also can change genes that the cells of body express
[4:10](https://m.youtube.com/watch?v=UF0nqolsNZc&t=250)
- Niels finson won Nobel price for use of phototherapy for treatment of lupes
- Red light therapy for age related vision loss (red light exposer needs to be early in the day)
[15:49](https://m.youtube.com/watch?v=UF0nqolsNZc&t=949)
- Physics and biology of light
    - Biological means how converted into signals for body
    - Light is electromagnetic energy
    - Energy can cause reaction in cells of body, plants
    - Light has many different wavelengths (white light has all wavelengths)
    - We can't see every wave length (infrared, ultraviolet)
    - Different wavelengths can penetrate tissue in different depths
[19:38](https://m.youtube.com/watch?v=UF0nqolsNZc&t=1178)
- How light penetrates tissue
    - Red and infrared are longer wavelength
    - Blue/green/ultraviolet light doesn't penetrate tissue very easily cause it has a short wavelength
    - Long wavelengths can penetrate through skin, maybe it goes even down to the bone
    - So different wavelengths impact different levels
    - Different wavelengths of light are also best absorbed by different organelles within the cells
    - Organelles are different compartments and functions in cells
    - So these functions can be stimulated by light
[27:41](https://m.youtube.com/watch?v=UF0nqolsNZc&t=1661)
- Light and body (direct vs indirect signal):
    - Certain pigments/colors in the receiver of light energy absorb different wavelengths of light (like reflection/absorption)
    - Eighter absorption/reflection or passing through of light
    - 3 examples how take light and convert into biological events
        - Photoreceptors on back of eyes (two types rods and cones, have photo pigments in them, rods absorb any wavelength, rods also used in low light conditions, cons 3 types: red/Green/blue, so they absorb either long/mid/short wavelength, they do it with different photo pigments)
        - Other place is skin (it's pigment is called melanin, on top layer of skin we have keratinocytes and melanocytes, melanocytes create pigmentation of skin, way they do it is by absorption of uv light)
        - Every cell of body (if light can access the cells it can change way they function, positive or negative, some cells don't really get the light directly they get it indirect through eyes and skin)
    - Always starts with absorbtion of particular pigments of the surfaces the light lands on
[33:40](https://m.youtube.com/watch?v=UF0nqolsNZc&t=2020)
- Light can affect our biology in fast/moderately fast and slow ways
- If from dark to very light environment then release adrenalin (fast effect)
- Slow integrating effects (average light information and not the accure one)
- Example is circadian rhythm (amounts of hormones that a released called know at which time we are in year)
- You'll get more or less light each day on average cause earth traveling around the sun
- Light in eye is absorbed by a particular cell type called intrinsically photosensitive ganglion cells, that communicate to specific stations in brain which connect to the pineal gland
- The light then shuts down the production of melatonin in the pineal gland
- In short days cause little light on average landing on the cells so duration of melatonin release will be much longer
- In summer more light on average hits the cells so duration of melatonin release much shorter
- The environment around thus changes the internal environment (melatonin signals it)
[38:24](https://m.youtube.com/watch?v=UF0nqolsNZc&t=2304)
- Content of melatonin supplement has to much melatonin in it
- Our own produced melatonin has two effects:
    - Regulatory effects:
        - Positiv impact on bonemass
        - Maturation of gonads during puberty, overview/testes (lowers amount of sperm, that's why you young kids have high melatonin to not get into puberty)
        - Also involved in placental evolvement
        - Powerful impact on central nervous system
        - Effects on waking up and feeling sleepy
    - Protective effects:
        - Can activate the immune system (one most potent anti oxidants, anti cancer properties)
- It's the rise and fall of melatonin and duration of melatonin signal that gives this effects
- Melatonin has slow moderate effects on body
[43:52](https://m.youtube.com/watch?v=UF0nqolsNZc&t=2632)
- Optimizing melatonin levels:
    - One of best thing to do is to get proper amount of sunlight each day (proper in context of time of year)
    - Summer month more sunlight in eyes
    - In winter makes more sense to spend more time indoors
    - Changes in melatonin release through year is normal
    - Shouldn't destroy melatonin by getting bright light when going for a pee at night
    - There are function that are specifically there for summer and for winter
    - To bypass it can dim lights or use long wavelengths light (the preceptors that react to bright light to impact melatonin respond to short wavelength light)
    - Amber colored light and red light (unless very bright)
    - Any light that's bright enough will shut down melatonin production
    - Also the melatonin supplement makes it static while normally levels are dynamically changing
[57:52](https://m.youtube.com/watch?v=UF0nqolsNZc&t=3472)
- More mating behavior in long days of spring/summer (human and animal)
- 2 mechanism that help with that
    - One is due to melatonin which inhibits testosterone and estrogen output from testes and ovaries
    - Second pathway (parallel pathway), more like an exelerator, exposure to light especially uvb (uv blue light), can trigger increase in testosterone and estrogen and desire to mate (exposure to skin not eyes)
- Skin actually hormone producing/influencing organ
- Mentioned study with mice 48:48
    - When exposed to uvb, if enough increases of that light increase of testosterone/estrogen, teste and ovaries size changed, also better female fertility
    - exposed with light similar to 20-30 min mid day sun exposure, they did it 2-3 times a week
    - It's between night at 10pm to 4am where uvb exposure from artificial source is not good
    - People with darker skin need more vitamin d3 (cause of darker skin you have more melanocytes so more light absorbed)
    - Seasonal changes in testosterone
[1:00:20](https://m.youtube.com/watch?v=UF0nqolsNZc&t=3620)
- Testosterone levels where lowest in winter and highest in June/July/August/September
- Sun exposure to eyes can increase mood
- Subjects of study had increase in romantic passion
[1:04:23](https://m.youtube.com/watch?v=UF0nqolsNZc&t=3863)
- Found in the mice that uvb light on skin increased the activity of p53 which is involved in maturation of cell and other functions
[1:11:33](https://m.youtube.com/watch?v=UF0nqolsNZc&t=4293)
- Uvb effects tolerance of pain
- Tolerance varies over the ear
- Mentioned two studies
- Nociception is the perception of pain
- Light landing on eyes captured and absorbed then send to areas of brain and then release of endogenous opioids (lead to less perception of pain)
[1:11:59](https://m.youtube.com/watch?v=UF0nqolsNZc&t=4319)
- If chronic pain sun light exposure could be beneficial
[1:16:54](https://m.youtube.com/watch?v=UF0nqolsNZc&t=4614)
- Even on cloudy day get more light then from indoor light
- Never look at any light that is so bright it's painful to look at
- Sunglasses will reflect the sun so it won't work also a windshield
- Don't wear blue blockers outside, and also not good to wear them in morning and daytime
- Can use in nighttime
- Also think about how much cloth put on
- If Depression in winter months (seasonal affective disorder) can be beneficial to get a sad lamp
- We all benefit from more uvb light throughout the year (if done safely)
[1:19:43](https://m.youtube.com/watch?v=UF0nqolsNZc&t=4783)
- He keeps light source on desk throughout the year and also goes outside (gets sunlight in early morning and throughout the year)
- If not that bright outside he will look at the light source more
- People who are pro skin cancer should be careful
[1:22:19](https://m.youtube.com/watch?v=UF0nqolsNZc&t=4939)
- Also improved immune function through uvb
- Uvb on eyes triggers activation of the neurons in the sympathetic nervous system (part of autonomic nervous system)
- When enough uvb a specific channel in sympathetic nervous system is activated and the splin deploys immune cells/molecules that combat infection (so part of getting less ill in summer)
[1:26:05](https://m.youtube.com/watch?v=UF0nqolsNZc&t=5165)
- In winter should be conscious about getting uvb to improve our splin function
- Also sound healing faster
- Hair also grows faster
- Also improve in skin health
[1:28:02](https://m.youtube.com/watch?v=UF0nqolsNZc&t=5282)
- If just local light and no involvement with the eyes then the treatment is not as potent
- Typically local skin treatment has high intensity light and if intensity is to high then you can damage the skin, cause you burn a layer off to trigger renewal of new skin cells
- Depends on case
[1:31:48](https://m.youtube.com/watch?v=UF0nqolsNZc&t=5508)
- Getting as much uvb to eyes and skin in early day and throughout the day (as safely as possible) be beneficial for mood
- There is one neural circuit that originates with cells in eye that bypasses the cycadian clock that's designed to release dopamine and other endogenous opioids
- Involves Peri perihabenular nucleus, it gets input from the cells in eye that respond to uvb (other bright light) if that pathway is activated at wrong time of day mood gets worse (so avoid uvb in the night, also artificial sources, 10pm - 4pm)
[1:36:43](https://m.youtube.com/watch?v=UF0nqolsNZc&t=5803)
- Study that is about light exposure during sleep effects cardio metabolic function (used 3 and 100 lux)
- App to measure lux
- Lux = light intensity
- Sleep deprivation can disrupt glucose regulation by insulin
- Melatonin levels where not disrupted
- Just 1 night of sleep in moderately light environment caused increase in night time heart rate, decrease in heart rate variability (on its own it's a good thing) and increase in next morning insulin resistance (so glucose management suffers)
[1:43:30](https://m.youtube.com/watch?v=UF0nqolsNZc&t=6210)
- Most low level light therapies involve red light
- LLL therapy has shown to be effective for a lot of things
- Treatment of agne, reduction in skin lesions, wound healing, reduction in scars from agne, sometimes resistance to that agne
- The red and infrared light can pass down to deeper layers of skin where it can change the metabolic function of different cells
- Shining red light on skin, provided it's not burning the skin, so just little damage of upper layer of skin and triggers certain biological pathways within the cells of sabacious gland and stem cells within hair cell niche, so skin gets burned and cells further in get out new cells
- So will work for wound healing, to get rid of scars and some form of pigmentation
[1:48:23](https://m.youtube.com/watch?v=UF0nqolsNZc&t=6503)
- Also through red light we can improve other cells like for seeing and think better
- Has reviews on LLL therapy
- Not really a review on whole body therapy for improving the skin
- Most Infrared sauna doesn't get hot enough to trigger effects on growth hormone and heat shock proteins and other benefits saunas are known for
[1:59:21](https://m.youtube.com/watch?v=UF0nqolsNZc&t=7161)
- Red and infrared light for restoration of neural function as we age
- In retina usually no new cells when age
- Nobody is as cognitive sharp as the used to be when they age
- Red light can increase adp, usually when adp increases energy in cells involving cytochrome c (oxidace, anytime there is ace in biology it's a enzyme so process in decorating and creating molecule)
- Great thing but you get byproduct like ROS (reactive oxigen species), and those change which genes are created in the a cell
- The goal of preventing age or get better with it is to increase adp and decrease ros
- In study People who where in 20s or 40 or older viewed red light about 670 nanometers at distance about foot away and low enough density, used for couple of weeks
    - In people 40 years or older saw improvement in visual function
- As we age we loss's some neurons in retina but not lose cones
- Cons and rods use most energy in body, therefore create lots of Ros as age
- Red light reduced ros
- Neuro retina is only piece of brain that's outside of it
- Reduction in drusen (little fatty deposits), accumulate as we age, the red light was reducing or even reversing the accumulation of drusen
[2:04:26](https://m.youtube.com/watch?v=UF0nqolsNZc&t=7466)
- Exposure of red light needed to happen early in the day
- Could also take bright light and put red filter over it (not to bright that you don't hurt the eye)
- It's 2-3min looking at red light every morning for two weeks or more
- Most panels to bright to look at, so use distance
[2:07:59](https://m.youtube.com/watch?v=UF0nqolsNZc&t=7679)
- Red light also beneficial in night
- If red light dim then won't effect melatonin production
[2:18:57](https://m.youtube.com/watch?v=UF0nqolsNZc&t=8337)
- So by drugs you change how neurons fire like anti depressions, opioids but that's all rather indirect
- There is also electrical stimulation but therefore a piece of skull needs to be removed
- Light would be a good way to effect neurons
- Recent studies showed that light on the eyes can change global patterns of brain
- Gamma activity (one wavelength) that can be restorative for certain aspects like learning
- By certain patterns of light flicker the brain will match those pattern
- Removed things that where there for Alzheimer's
