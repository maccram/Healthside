---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why I Quit The Carnivore Diet
"url:": https://m.youtube.com/watch?v=PzX_NS7EwF0&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-19T10:30
updated: 2024-06-19T10:31
---
<iframe title="Why I Quit The Carnivore Diet" src="https://www.youtube.com/embed/PzX_NS7EwF0?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:01](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=121)
- Has good benefits
- If feel good with it then keep doing it
- But some struggle with some things (sleep issues, muscle cramps, low libido)
- He had issues after a year
[3:39](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=219)
- He eats meat, fruit, honey and raw dairy
[7:20](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=440)
- Insulin has crucial role to signal the kidney to hold on electrolytes
- He thinks that insulin induced insulin resistance isn't the cause of obesity and diabetes
- Fructose in natural form looks different then with in processed form
- Mice do have a higher amount of turning fructose in triglyceride and fat
- And most studies use high fructose corn syrup
[10:01](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=601)
- He thinks that keto diets are not good cause there is evidence that keto diets lead to more stress
- Adding carbs to people improves cortisol and recovery with training
- And also improves thoride hormones (essential thermostat of body)
- Study on negative effected thoride hormone by keto diet
- Anyone in keto diet should check TSH, T4, T3, free T3, free T4, reverse T3
- When thoride doesn't work well that's a factor of cardiovascular disease
[12:17](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=737)
- Cortisol stays longer in body with keto diet so not that good
- Diets with 2% carbs in diet there was increased breakdown of protein and lowering of t3
[17:34](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=1054)
- Carbs increase free testosterone and decreases cortisol after training
- Stress hormone went up less
- For him fruit and honey are best carbs with lactose in raw milk
- Has video on honey and raw dairy as well
- Problem with oatmeal is phytic acid, grains are not good source of carbs for humans
- Grains have more defense chemicals, and you need a longer process to be detoxified
- Also beans have phyic acid, and poor source of nutrients
- For some people root vegetables can be better tolerated then grains/beans
[20:09](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=1209)
- There is no study that showed that fruit disrupts metabolic disfunction
- He is not huge fan of fiber (why)
- He also thinks fruit juice (without sugar) is good
- Honey raises testosterone levels in men
- Lower fasting glucose (study in diabetics)
- Protective effect of honey against metabolic Syndrom (review)
[22:05](https://m.youtube.com/watch?v=PzX_NS7EwF0&t=1325)
- Thinks Fruit and honey have any effect on deuterium
- Also no evidence that it improves glycation
- Also keto increases glycation

  