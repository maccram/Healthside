---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Seed Oils, The Dirty 8 That Are Destroying Your Health | Ultimate Human Short with Gary Brecka
"url:": https://m.youtube.com/watch?v=FBhbg11rd6g&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:45
updated: 2024-06-24T19:46
---
<iframe title="Seed Oils, The Dirty 8 That Are Destroying Your Health | Ultimate Human Short with Gary Brecka" src="https://www.youtube.com/embed/FBhbg11rd6g?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:24](https://m.youtube.com/watch?v=FBhbg11rd6g&t=144)
- To basic types of fatty acid in body
	- Saturated fat (typically solid at room temperature)
    - Unsaturated fat (liquid at room temperature)
	    - Mono unsaturated fats
        - Polyunsaturated fats
    - Most of tissues in body are made out of saturated fat and mono unsaturated fat (that's why we have increased intake need for those both)
    - We need to reduce the polyunsaturated fats cause they are not as highly required
    - Polyunsaturated fats are omega 3 and omega 6 but research shows that the high consumption of omega 6 and especially linoleic acid that's bad
[4:25](https://m.youtube.com/watch?v=FBhbg11rd6g&t=265)
- All dead oils are high in polyunsaturated fats and low in saturated fats
- The omega 6 fatty acids are easily oxidized which can cause free radicals damage to cell membrans and can damage mitrochondria
- Oxidized fats get trapped in cell membrane and can cause inflammation and poor cellular function
- In 18 hundreds machines where lubricated with synthetic seed oil, processed foods has a lot of that fats
- Glutathione main antioxidant in the body (polyunsaturated fats reduces its production), every cell has glutathion
- Seed oil oxidation is also linked to poor immune system, and increased insulin ressistance
[5:31](https://m.youtube.com/watch?v=FBhbg11rd6g&t=331)
- We blame increased cholesterol for heart disease
- Seed oils cause LDL cholesterol to oxidize which causes formation of a thome cell (so cholesterol itself is not the bad guy its oxidized one)
- Also study showed that with consuming seed oils there is increased uv radiation damage and also higher risk of skin cancer
[6:20](https://m.youtube.com/watch?v=FBhbg11rd6g&t=380)
- Seed oils also often contain bad chemicals like hexane
- It's also heated to high temperature which turns them rancid
- Also sometimes deodorized with sodium hydroxide, carcinogen hexane (known neurotoxin)
- Also often GMO
- They also become trans and hydrogenated fats when often heated (they then release oxidizing free radicals into our system)
[10:03](https://m.youtube.com/watch?v=FBhbg11rd6g&t=603)
- Dirty 8 seed oils:
	- Corn oil
    - Conola oil (rape seed)
    - Cotton seed oil
    - Soy oils
    - Sunflower oil
    - Safflower oil
    - Grape seed oil
    - Rice brand oil
[12:33](https://m.youtube.com/watch?v=FBhbg11rd6g&t=753)
- What oils to use:
	- Limit processed foods
    - Avoid dressings with these seed oils
	    - Will put some good ones on his website
    - For cooking:
	    - Grass fed butter
        - Ghee butter
        - tallow
        - Coconut oil
    - Benefits of them:
	    - Won't denature when heated
        - Less linoleic acid
        - Good ratio of omega 3 to 6
        - Not oxidize or get rancid when heated
    - At room temperature:
	    - Extra virgin olive oil
	        - Best is brand from Italy and cold pressed
            - Look at label and look if it is if used or diluted with other seed oils
    - He eats lot of nuts that are low in linoleic acid
	    - Macadamias
        - Cashew
        - Pistachios
        - hazelnuts
    - Wild caught vs farm raised fish:
	    - Go for wild one cause there is big difference between them
    - With meat eat grass fed (finished meat)
