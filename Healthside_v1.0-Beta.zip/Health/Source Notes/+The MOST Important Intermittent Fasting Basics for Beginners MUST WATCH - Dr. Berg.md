---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "The MOST Important Intermittent Fasting Basics for Beginners: MUST WATCH - Dr. Berg"
"url:": https://m.youtube.com/watch?v=1rfzjRoalWM&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T10:23
updated: 2024-06-19T10:25
---
<iframe title="The MOST Important Intermittent Fasting Basics for Beginners: MUST WATCH - Dr. Berg" src="https://www.youtube.com/embed/1rfzjRoalWM?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:25](https://m.youtube.com/watch?v=1rfzjRoalWM&t=145)
- we try to go from sugar to fat burning
- Appetite goes
[4:34](https://m.youtube.com/watch?v=1rfzjRoalWM&t=274)
- Skip or push breakfast further back
- Rule of thumb don't eat when not hungry
- If have carbs for lunch and dinner you'll be hungry next day
- Could do bulletproof coffee
- Can do tablespoon of mc2 oil
- Cortisol peaks at 8 in morning (could be hungry cause of that, but that's not really being hungry)
- If doesn't go away feel deezy tired and weak then eat
[7:04](https://m.youtube.com/watch?v=1rfzjRoalWM&t=424)
- With first meal add some fats to end of meal (olives, cheese, nut butter, fatty meat), helps to fast longer
- Also low carbs
- Same with dinner
- Healthy keto is not only going lower in carbs but also eating nutrients dense foods
- Don't snack
[10:56](https://m.youtube.com/watch?v=1rfzjRoalWM&t=656)
- When insulin resistance nutrients aren't absorbed that good
- Apple cider vinegar (has acidic acid)
- Acidic acid helps reduce blood sugars
- Lemon in water also good (vitamin c, also helps against kidney stones)
- Sometimes when fast uric acid goes up
[13:29](https://m.youtube.com/watch?v=1rfzjRoalWM&t=809)
- Other good thing are vegetables
- Maybe big salad
- Should be eaten in beginning of meal, cause if eat protein first then you are likely filled up already
- Fiber feeds microbiome
- Gives potassium and magnesium (helps insulin, gives energy, prevents cramps)
- For Salat need more but for vegetables less amount
[15:37](https://m.youtube.com/watch?v=1rfzjRoalWM&t=937)
- Usually cholesterol goes down but for some goes up
- If burn fat certain part of it is cholesterol, and triglycerides used for energy
- If liver is fatty or you don't have gal bladder then lack to get rid of cholesterol
- If these the lipids you find you'll have lots of LDL but not the bad one (small particle one) rather the good ones (big partial, only when do lots of carbs you find those)
- After 14 days 50% of fat in liver will be gone
[16:41](https://m.youtube.com/watch?v=1rfzjRoalWM&t=1001)
- Green tea is good cause helps insulin resistance
- Other good ones are cinnamon, Garcinia, ginger, ginseng
[17:01](https://m.youtube.com/watch?v=1rfzjRoalWM&t=1021)
- When exercise he doesn't recommend pre or post drink
[18:32](https://m.youtube.com/watch?v=1rfzjRoalWM&t=1112)
- There are symptoms of fasting like keto fatigue, keto flu, cramps, thyoride symptoms
- All that means you are sufficient in certain nutrients
- Make sure to take b vitamins (recommends nutritional yeast), and electrolytes (electrolyte powder with trace minerals, link in bio of one)
[25:27](https://m.youtube.com/watch?v=1rfzjRoalWM&t=1527)
- Mistakes:
    - Small snack (only two things that don't trigger insulin and that's fiber and fat, so either do MCT oil so pure fat, or something very fiberous like salarie)
    - Little bit of carb is also not beneficial
    - Thinking it will happen quick
    - Everything is in balance is not true
