---
tags:
  - 📥/📜/🟢
type: article
"general_subject:": "[[Health]]"
"specific_subject:": 
"url:": https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8504498/
---
- 100 years ago omega-6/3 ratio has been around 4:1 or less.
- The overconsumption of linoleic acid, mainly from industrial omega-6 seed oils pro-inflammatory, pro-allergic, pro-thrombotic state.
- Western diet has a 20:1 omega 6 to omega 3 ratio
- soybean, corn 60:1, and safflower oil 77:1,
- The increase in the omega-6/3 ratio has paralleled the rise in numerous autoimmune, inflammatory, and allergic diseases.
- Dietary Sources of Marine Omega-38,9
- ![[DietarySourcesOmega-3.png|300]]
- ![[DietarySourcesOmega-6.png|300]]
- Omega-3s in Pregnancy Reduce Allergic Disease in Offspring
- Studies of Omega-3s in pregnancy for reducing allergic disease in offspring
- Observational data of higher omega-3 intake and lower risk of asthma, eczema and atopic wheeze
- Clinical studies testing omega-3s in asthma