---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Is Honey a Better Substitute for Sugar?
"url:": https://m.youtube.com/watch?v=Ih8b8mFZjo4&pp=ygUFSG9uZXk%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-24T20:03
updated: 2024-06-24T20:04
---
<iframe title="Is Honey a Better Substitute for Sugar?" src="https://www.youtube.com/embed/Ih8b8mFZjo4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:12](https://m.youtube.com/watch?v=Ih8b8mFZjo4&pp=ygUFSG9uZXk%3D&t=12)
- 60% fructose, 40% glucose
- Benefits of honey is antioxidants and vitamins
