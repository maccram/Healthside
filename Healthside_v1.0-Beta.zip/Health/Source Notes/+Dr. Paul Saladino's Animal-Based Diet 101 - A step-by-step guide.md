---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": "Dr. Paul Saladino's Animal-Based Diet 101: A step-by-step guide"
"url:": https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
---
<iframe title="Dr. Paul Saladino's Animal-Based Diet 101: A step-by-step guide" src="https://www.youtube.com/embed/n6nVKf5ZZnk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:36](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=156)
- Tribes seek meat
- Also vegetables, seeds also have more toxins, pestiztides
- When fruit ripes it losses its defence chemical (Nonprotein Amino Acid)
[6:08](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=368)
- How much protein?
	- gram per pound body weight (or goal body weight)
    - Think about protein first
- To complement meat also drink bone broth
- So mix of aminos in most in bone broth
- also eat organs (liver and heart)
	- Half to oz of liver per day most days of the week
    - Heart few uncle's every day
    - Have unique micronutrients
    - Has supplement for it
[7:14](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=434)
- Chicken and pork not as clean cause often not feed with grass
- Picture
[11:09](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=669)
- Fish even when wild has lots of heavy Metal, ppfas, micro plastics
- Eggs great source but often feed corn and soy
- Carbs:
	- Fruits
    - Not fan of grains
    - Want at least 150g a day and if active more like 350g
    - Has a calculator on his website
    - You could try to use starches
    - Also uses avocado, cucumber, zucchini, squash
[12:23](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=743)
- Animal fats:
	- Raw cheese (parmesano regano)
    - Grass-fed butter
    - Fatty ground beef
    - Tallow
- Want 40% of calories from fat, 40% from carbs, 20% from protein​
[13:11](https://m.youtube.com/watch?v=n6nVKf5ZZnk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=791)
- Also uses raw dairy
