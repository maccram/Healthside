---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Cold Water Exposure for Fat Burning, Mood Boosts, and More | Ultimate Human Short with Gary Brecka
"url:": https://m.youtube.com/watch?v=X7GX5itGJc4&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T20:12
updated: 2024-06-24T20:12
---
<iframe title="Cold Water Exposure for Fat Burning, Mood Boosts, and More | Ultimate Human Short with Gary Brecka" src="https://www.youtube.com/embed/X7GX5itGJc4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[8:02](https://m.youtube.com/watch?v=X7GX5itGJc4&t=482)
- Start with 1min cold shower and work up to 3min gets all the benefits (colder is not equal to better)
- First can shower warm then can do called one
- Ateries will spasm down and going to clamp all blood
- It forces the blood into the core and the head
- It's basically exercising vascular system
- We have 3 types of muscle (cardiac muscle which is heart muscle, skeleton muscle, smooth muscle which is the muscle that lines our arteries)
- We can exercise that smooth muscle cause it can contract and losen
- The faster you adapt to cold water the faster you'll adapt to cold weather
- You'll feed extra blood to core and to brain
- Also dopamine hit that lasts several hours
- If cold enough liver releases cold shock proteins, when they hit the blood they get rid of free radicals oxidation
	- Free radicals cause cellular damage
    - Even increases rate of protein synthesis (muscle repair)
- Has protein supplement (probably weigh powder for working out)
- We should could plunge prior to exercise
- He has it in morning routine
- Cold plunge activates brown fat (there for Thermostate)
	- Best way to burn fat
- Can die in 72 degree water and not air (cause water is more thermal, 29 times more)
- Start at 48-50 degrees Fahrenheit
- 3min minimum 6min maximum
