---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Do we need vegetables for a healthy gut?
"url:": https://m.youtube.com/watch?v=ZGJi0xjTCEk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T20:00
updated: 2024-06-24T20:00
---
<iframe title="Do we need vegetables for a healthy gut?" src="https://www.youtube.com/embed/ZGJi0xjTCEk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:11](https://m.youtube.com/watch?v=ZGJi0xjTCEk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=71)
- He thinks that vegetable fiber isn't actually what's crucial for gut health
- Most say fiber from vegetables is good for alpha diversity in the gut
- He thinks that that is not true cause some studies show there is no change in alpha diversity
[5:13](https://m.youtube.com/watch?v=ZGJi0xjTCEk&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=313)
- Shows study
	- Fiber had no impact on diversity
    - High fermented foods had increased microbiota diversity and decreased inflammatory markers
- He does kefir every day
