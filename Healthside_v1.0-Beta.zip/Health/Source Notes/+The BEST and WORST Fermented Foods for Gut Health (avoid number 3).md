---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The BEST and WORST Fermented Foods for Gut Health (avoid number 3)
"url:": https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-19T07:02
updated: 2024-06-19T07:03
---
<iframe title="The BEST and WORST Fermented Foods for Gut Health (avoid number 3)" src="https://www.youtube.com/embed/7AKzXAPFuuk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:20](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=140)
- Two types of fermented food
    - Wild fermenting foods (naturally ferment on its own, like sauerkraut/kimchi)
    - Others influenced with starter cultures (kefir, kombucha, yoghurt)
- No real difference between the benefits
- Data shows dairy based food have the strongest impact
- Yoghurt seems to be best for microbial diversity
[4:39](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=279)
- Kefir similar to yoghurt but different culture
- Better for people with sensitive gut cause contains galactosidase producing bacteria
- Galactosidase hydrolysis lactose so helps it break down, thus 30% less lactose content
[5:43](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=343)
- Kombucha:
    - Not really much evidence
    - Only vitro studies
    - Also added sugar into it to just create the effect
[7:48](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=468)
- Sauerkraut:
    - There is a random e double blind study on it
    - It had effect on people with IBS but when looked at microbiom there wasn't big change
    - So it could be cause it has good prebiotic effects
    - If people drank sauerkraut juice there was anti oxidants effect called kaempferol and also increase in glutathione products
[9:06](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=546)
- Kimchi:
    - Change in microbiom even if also similar to sauerkraut
    - Diverse amount of bacteria when started the culture but after some days mainly have Leuconostoc bacteria
    - Increases in short chain fatty acid producing bacteria
[10:28](https://m.youtube.com/watch?v=7AKzXAPFuuk&pp=ygUVYmVzdCBmZXJtZW50ZWQgZm9vZHMg&t=628)
- Tempeh & Natto:
    - Fermented soy
    - Also benefitial
