---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": Why Blue Light Blockers Are A Scam
"url:": https://m.youtube.com/watch?v=YqGni6qSP2c&pp=ygUfYmx1ZSBsaWdodCBibG9ja2VycyBnYXJ5IGJyZWNrYQ%3D%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Radical Health Radio]]"
---
<iframe title="Why Blue Light Blockers Are A Scam" src="https://www.youtube.com/embed/YqGni6qSP2c?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:08](https://m.youtube.com/watch?v=YqGni6qSP2c&pp=ygUfYmx1ZSBsaWdodCBibG9ja2VycyBnYXJ5IGJyZWNrYQ%3D%3D&t=128)
- Clear blue light lenses are a scam says the founder of re optics
- He also showed it
