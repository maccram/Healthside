---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The Fascinating Benefits of RAW MILK Dairy
"url:": https://m.youtube.com/watch?v=PvWz5cNTmLE&pp=ygUJcmF3IGRhaXJ5&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-24T20:06
updated: 2024-06-24T20:07
---
<iframe title="The Fascinating Benefits of RAW MILK Dairy" src="https://www.youtube.com/embed/PvWz5cNTmLE?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[4:42](https://m.youtube.com/watch?v=PvWz5cNTmLE&pp=ygUJcmF3IGRhaXJ5&t=282)
- Most healthy thing for a infint is breast milk
- Raw vs pasteurized milk:
    - Heat kills bacteria but I'd doesn't get rid of them so you simple drink the dead bacteria
    - Also all Enzyms (proteins) are killed, which would be beneficial
	    - Has list of them on board in the video
        - Gets rid of lactase (breaks down lactose) which you need if you have lactose intolerance
        - So raw milk has lots of good bacteria
    - 2500 proteins in milk
    - Also 400 types of fatty acids that are destroyed with homogenize it
    - Homogenization is when break down fat in little parts
    - Has wulzen factor (good for stiffness)
    - He doesn't drink raw milk he uses raw milk products (raw milk cheese, kefir, sometimes joghurt)
    - With raw milk products more bioavailable calcium and fat soluble vitamins
    - Also alkaline phosphate enzyme (is anti inflammatory)
    - Realmilk.com
[5:33](https://m.youtube.com/watch?v=PvWz5cNTmLE&pp=ygUJcmF3IGRhaXJ5&t=333)
- A1 vs A2 milk:
	- Has to do with the protein
    - A2 is better
    - A2 has lot less bloating, less digestive inflammation
    - A1 is more inflammatory and G1 problems can occur
