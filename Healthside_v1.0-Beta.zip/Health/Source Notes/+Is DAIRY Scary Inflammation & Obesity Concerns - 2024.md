---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Is DAIRY Scary?? Inflammation & Obesity Concerns - 2024
"url:": https://m.youtube.com/watch?v=oZYtaiLznW8&pp=ygUJcmF3IGRhaXJ5&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@KenDBerryMD]]"
created: 2024-06-24T19:47
updated: 2024-06-24T19:48
---
<iframe title="Is DAIRY Scary?? Inflammation &amp; Obesity Concerns - 2024" src="https://www.youtube.com/embed/oZYtaiLznW8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[4:32](https://m.youtube.com/watch?v=oZYtaiLznW8&pp=ygUJcmF3IGRhaXJ5&t=272)
- The purpose of milk is actually to make a small child/animal grow and gain weight as fast as possible
- For gaining weight you should drink lots of milk
- After a certain age mammals can't digest milk as good (typically sugar in milk)
	- Half of population can't digest it fully without side effects
- All 3 macro nutrients in milk carb (mostly lactose, need species specific milk)/fat/protein in perfect ratio
- We have enzyme called lactese that helps breakdown lactose
- Some people have inflammation caused by dairy
[7:53](https://m.youtube.com/watch?v=oZYtaiLznW8&pp=ygUJcmF3IGRhaXJ5&t=473)
- Fat free and low fat milk worst choice
- 1% milk also not that good
- Heavy creme its ok
	- 36% or higher milk fat mostly ok for most people
- Yoghurt and kefir cause of added things are not that inflammatory
- Butter is also good (70-82% fat)
- Best is ghee (99% fat)
