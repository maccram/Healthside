---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Dr. Robert Lustig How Sugar & Processed Food Impacts your health - Huberman Lab Podcast
"url:": https://m.youtube.com/watch?v=n28W4AmvMDE&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Andrew Huberman]]"
created: 2024-06-12T14:35
updated: 2024-06-12T19:25
---
<iframe title="Dr. Robert Lustig: How Sugar &amp; Processed Foods Impact Your Health" src="https://www.youtube.com/embed/n28W4AmvMDE?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[7:44](https://m.youtube.com/watch?v=n28W4AmvMDE&t=464)
- [[@Dr. Robert Lustig|Dr. Robert Lustig]] has YouTube video on sugar (in description)
- Calorie basically unit of energy
[12:17](https://m.youtube.com/watch?v=n28W4AmvMDE&t=737)
- A calorie burned is a calorie burned
- But that doesn't mean a calorie eaten is a calorie eaten
- If you eat 160 calories in almonds, you absorb 130
- Turns out the fiber (soluble and insoluble one, fiber is more or less key) forms a jell on inside of intestent, the insoluble fiber or also cellulose forms a fishnet, the soluble plugs the holes in it, together they prevent the absorption from the 30 calories, they go further down the intestent to where the micro biome is
- If you feed your gut (microbiome) that's good cause then the gut will turn it into things like short chain fatty acids which are protective against chronic metabolic diseases
- So basically it comes down to what of the calories go to your gut and get absorbed
- That was problem number to
[15:14](https://m.youtube.com/watch?v=n28W4AmvMDE&t=914)
- Problem two is with protein
- If eat to much protein, if bodybuilder then it goes into other muscle, but if not then your liver has to take them and deamitates them turns them from amino acid to organic acid and that's uses to feed a process that creates atp (chemical energy body needs in order to power itself), so that's good
- It takes double amount of energy to prepare that protein to burn as it does to prepare a carb or fat
- 10% of everything you eat goes to just maintaining body temperature (thermic effective food)
- With protein actually create more heat (cause it takes double atp)
- Fat doesn't have any thermic effective food cause it doesn't go through the same process
[18:08](https://m.youtube.com/watch?v=n28W4AmvMDE&t=1088)
- Fats
- Omega 3 (heart healthy, anti inflammatory, anti Alzheimer's, save your life)
- Trans fats (the poison, can't basically break it down, it lines arteries, liver, causes chronic metabolic disease, insulin resistent)
- Omega 3s don't even get broken down for energy cause they are so important, cause brain/heart needs them
- Trans fats can't be broken down
[30:57](https://m.youtube.com/watch?v=n28W4AmvMDE&t=1857)
- Carbohydrates (Fructose and glucose):
- Galactose basically becomes glucose
- Glucose is the energy of life (every cell on the planet burns glucose for energy it's so important that if you don't consume it your body makes it (gluconeogenesis)
- You can use ketones but only when in a ketogenic state
- You need glucose for specific structural changes in proteins and hormons
- Fructose on other hand (which we seek, added sugars of food industry are by purpose cause Fructose is addictive)
- No life that needs it (although we have a limited capacity to process it)
- Berries are the lowest fructose of all food
- It's fine to eat fruit cause of the fiber in them (fiber is want mitigates the absorption so that means you feed your microbiom more)
- Fructose inhibits 3 necessary enzymes that are needed for normal mitochondrial function
- Metochondrial has to work at peak efficiency that's what metabolic health is
- The 3 Enzyms are: amp kinase (is the thing that tells liver to create more new mitochondria, Fructose basically locks that process without unlocking it), second one acadl (acyl coa dehydrogenase longchain) (there prepare fatty acid for metabolism), cpt 1(brings fatty acid from outer mitochondrial membrane to inner one so that there can be energy created out of it)
- Paracelsus 15:37
- It's what you do everyday not what you do once
[33:08](https://m.youtube.com/watch?v=n28W4AmvMDE&t=1988)
- Fructose is in that category
- What makes our life time shorter is primarily sugar, also omega 6, transfats (magarine)
- Magarine lined your liver cause couldn't break transfats down
- If olive oil is heated behond cooking point you create transfats
[35:07](https://m.youtube.com/watch?v=n28W4AmvMDE&t=2107)
- There is no study that shows cutting calories makes a difference
- Food industry calls fat is fat, sugar is sugar, calorie is a calorie on purpose (which all is not true)
- With sugar are you talking about dietary sugar or blood sugar
[42:36](https://m.youtube.com/watch?v=n28W4AmvMDE&t=2556)
- 65% of what is ingested is used for resting energy expenditure, 10% thermic effective food, 25% goes to activity
- When intake glucose you get big glucose rise in bloodstream and insulin makes it go down
- Insulin is the bad guy in the story
- The higher glucose the more insulin
- That glucose rise itself also leads to various health issues like with arteries and kidney disease (because of change in bloodpressure)
- But really the insulin response makes it all bad
- Insulin takes whatever you are not burning (blood glucose) and puts it into fat for storage (takes 90min)
- Insulin is the energy storage hormone
- If active your muscles will take the glucose irrespective of insulin (used as immediate fuel and glycogen storage)
- Muscles are insulin independent
- Insulin spike is especially one of biggest factors metabolic disease
[46:46](https://m.youtube.com/watch?v=n28W4AmvMDE&t=2806)
- Study of mice, everything looks healthy like normal blood glucose levels, normal glucose tolerant, not fat, normal insulin levels the only thing is that there kidney dies
- It's the Insulin that makes the kidney die
- Insulin drives growth
- Every cell in body wants to burn at one time and wants to grow at one
- 41 doublings of cells to turn the body into grown state of an adult (10 trillion cells)
[51:19](https://m.youtube.com/watch?v=n28W4AmvMDE&t=3079)
- 36 doubleings pre natali, 5 post
- The cell has to know when to grow and when to burn the signal for that is oxygen
- Oxygen also needed for the mitochondria to signal burning
- Absence of oxygen the cell only knows to grow
- Otto Warburg effect
- No cell needs oxygen to grow
- Tumore cells grow like wild cause they don't have oxygen
- There is hyperbaric oxygen therapy
- It's the insulin rise that drives the growth in the absence of oxigen
- If you have oxygen you don't need that much insulin cause you burn instead of store
[54:04](https://m.youtube.com/watch?v=n28W4AmvMDE&t=3244)
- Proccessing of glucose: The glucose is basically tuned in uric acid that is then in bloodstream and hopefully go out in the kidney
- That uric acid can inhibit midrochondrial function and also the enzyme that is there to lower your blood pressure (so higher blood pressure than normal)
- It's not necessary a bad thing to eat that beagle if it's in your cloric requirements, and depends on how much you clear and how high the insulin goes
[1:00:52](https://m.youtube.com/watch?v=n28W4AmvMDE&t=3652)
- 250 calories of fructose
- Beagle vs soda
- With soda only half of it is glucose so the glucose rise won't be as high
- The glycemic index is garbage
- There is no fructose alone in nature
- Ingestent will metabolism some of fructose (10% turned into fat right away, molecule fat that could be used as fat, triglyceride)
- Rest will be absorbed in Portale vein (goes to liver), but before some of it will be nitrating tight junction proteins
- Intestine is like sewer junk in middle and there job is to put the junk to the anus, absorbing the good stuff
- Intestine bound together with proteins which form a barrier (tight junction proteins)
- If you change the nitrate status of that tight junction it gets leaky, so some of the junk goes through to your bloodstream (leaky gut)
- Causes inflammation of level of liver
- CRP is high (marker for inflammatory immune response which shouldn't be high)
- 93% of Americans have leaky gut
[1:04:03](https://m.youtube.com/watch?v=n28W4AmvMDE&t=3843)
- What supports the tight junktions
- 3 barriers in intestine (one is physical mucin layer (if won't feed bacteria your bacteria will feed on you, that's why fiber is so important), didn't mention other two
- So on one hand fasting might be good on other hand you deplete your microbiom
- When you do eat enough fiber and high quality fermented food (so low sugar fermented), the gut. microbiom gets replenished even more then it was before
- Fermented food is good because of the short chain fatty acids
- Microbiom turns fiber into shortchain fatty acids
- Prebiotic (food for bacteria), probiotics (Bacteria itself), post biotic (what bacteria makes to heal you)
[1:10:25](https://m.youtube.com/watch?v=n28W4AmvMDE&t=4225)
- If you want something sweet for desert it's fine
- Price elasticity phenomenon (if price of a good goes up by 1% that should lead to reduction in purchaser consumption, price influences consumption)
- If something is price elasticity when price goes up consumption goes down (eggs have a high one, when egg price +1% then consumption goes down 0.68%, means price elasticity is 0.32)
- Most price inelastic (fast food, soft drinks, juice), they will pay more cause of the sugar
- Keynesian economics (based on concept of rational actor, who can determine value, utility over cost)
- In 1979 Daniel canaman and Amos Tversky described the irrational actor (irrational one can't determine value because he is risk averse, cost always to great)
- Jeffrey Sachs hedonic actor (also can't determine value cause it doesn't matter what it causes they need their fix,that's what's happening)
[1:14:17](https://m.youtube.com/watch?v=n28W4AmvMDE&t=4457)
- Bread in us has lot of fructose
- The better the bread the quicker it turns bad
- Bread added with sugar turns not bad as quick cause of the sugar
- So even brad has turned into something bad
[1:18:13](https://m.youtube.com/watch?v=n28W4AmvMDE&t=4693)
- Use sucrose for sugar cause sugar has more then one definition
- Sucrose is what put in coffee (cane sugar, beets sugar)
- It's out of one molecule of glucose one of fructose together
- Body separates them instantly and then glucose goes to entire body (insulin response), fructose straight to liver and generates fat
- High fructose corn syrup is 1 molecule of glucose one of fructose not bound together
- But does the same actually, only difference is economically (cause sucrose would be needed to imported, used with the food manufacturers)
- Because the molecules are free they don't crystalize
[1:29:24](https://m.youtube.com/watch?v=n28W4AmvMDE&t=5364)
- Every health crisis needs a public health response
- For personal responsibility there are 4 criteria (knowledge, access, affordability, externalities)
- Externalities (your choice can't hurt anybody else)
- Food science (what happens to food in between ground and mouth), nutrition (what happens to food between mouth and cell), metabolic health (is what happens to food Inside the cell)
- All the major disease are inside the cell cause they are al midrochondrial disfunction (there is no medicine that gets there)
[1:54:27](https://m.youtube.com/watch?v=n28W4AmvMDE&t=6867)
- Most of Europe and Skandinavien countries, also Australia, Thailand don't allow high fructose corn syrup
- But some of the countries still have the problems cause they have sucros
- Definition of food is substrate that contributes either to growth or burning of an organism
- Ultra processed food inhibits growth and hijackes growth of cancer
- 73% of food in grocery store is consumable poison
- Most starches nowadays have fructose in them
- If get insulin down you not get fat (fat will give up triglyceride in it as soon as insulin goes down)
- Two things that get insulin up is refined carbohydrates and sugar, also in corn feed beef/chicken and fish
- Nova system for categorizing the processed foods (4 classes, class 4 is the problem one)
- They created a online tool on perfect.co (recommendation engine based on metabolism)
- Dr lustig is not low carb he is low insulin
- To get to low insulin need to get rid of refined carbohydrate, of sugar, increase the fiber, get rid of branch chain amino acids (is in protein powder, if build muscle it's okay)
- Fish is good
- Gras feed steak
- American corn fed animal has metabolic Syndrom that's the marbling
- Nothing wrong with eggs (orange yoke egg has lot of omega 3 in it)
- Other sources of omega 3 (Marine life)
- 3 Omega 3 types (ala which is in vedgetables, epa which is only in marine life, dha which you get from Marin life or algea)
- Dr Lustig takes fish oil to increase his omega 3 (1g/day), vitamin c (1000mg/day, mainly for his skin issue), vitamin d
- Vitamin d deficiency is related to all the metabolic diseases but supplementation of it hasn't fixed any of them
- One reason of vitamin d deficiency is soft drinks
- Vitamin d is converted in the liver in a pro hormone means it's inactive, then it can be metabolised two ways one alpha in the kidney that's the active form (which does all activity, calcium absorption of gut, supression of Immunsystem which is s good thing), other form which turns it into inactive form and just gets it out again)
- You need to fix the inflammation first
- To reduce systemic inflammation you decrease fructose, reduce heavy metals like Cadmium (in chocolate)
- Good is fiber, short chain fatty acids
- Increased cortisol (normally antiflammentory) due to sleep deprivation leads to increased inflammation
- Cortisol is good if on right time of day and acutely (late shifted one bad, too much or to frequent bad, you actually need cortisol it's essentially)
[1:56:09](https://m.youtube.com/watch?v=n28W4AmvMDE&t=6969)
- when under short term stress cortisol helps you
- Chronic stress leads to metabolic and mental health disaster
[1:57:26](https://m.youtube.com/watch?v=n28W4AmvMDE&t=7046)
- There are 4 things that increase mitracondrial biogenesis (cold, altitude, ...) that's why Colorado was seen healthier
[2:05:59](https://m.youtube.com/watch?v=n28W4AmvMDE&t=7559)
- Mentioned something about pool might look into effects of chlor
- There is the data that the food industry has the politicians by money
- Alac organisation they are for whoever gives them money
- Statins only help in certain cases (seconary prevention) for just prevention it only increases life span by 4 days and increases the risk of diabetes by 20%
- Leo not real problem cause two Ldls
- You reduce it by reducing insulin (sugar)
[2:18:26](https://m.youtube.com/watch?v=n28W4AmvMDE&t=8306)
- Biggest fast food makers there is is the public schools
- IQ scores went down since the food industry came into the school food
- 3 studies showed that ultra processed food also correlates to depression
[2:26:53](https://m.youtube.com/watch?v=n28W4AmvMDE&t=8813)
- Body fat is not body fat
- 3 fat depos
- Subcutaneous fat (big butt fat, you have to gain 10kg of it to get metabolically ill)
- Fats are releasing cytokines they are pro inflammatory they do it at rest
- The fat cell itself is not the problem it's cause it can't handle it anymore
- Drains into systemic circulation
- Fat depos two is visceral (big belly fat, only need 5kg fat to get metabolically ill)
- Drains into portal vein (direct to liver)
- Comes not from calories comes from stress (cortisol)
- Third one is the liver (only quarter of a kilo, a healthy liver weighs 1500g)
- If have fat in liver it causes metabolic disfunction right away
- That fat in the liver comes from either alcohol or sugar
- If want to fix liver fat get rid of alcohol and sugar
- One of reasons intermittent fasting works is cause you give the liver time to offload some of it's fat
- Diet sweeteners don't really reduce the fat
[2:34:02](https://m.youtube.com/watch?v=n28W4AmvMDE&t=9242)
- Study where tested response to different drinks
- Milk didn't have much impact cause lactose is not a big insulin driver
- Diet soda with zero calories gained 2kg cause had still insulin response
- Insulin response cause still taste sweet
- Also study that showed when eating and also drinking diet soda it conditions the diet soda for a bigger release of insulin
- Also study where they didn't get a insulin response from the artificial sweeteners but when they ate afterwards they ate much more
[2:39:33](https://m.youtube.com/watch?v=n28W4AmvMDE&t=9573)
- Dr lustig helped restructure a food company to be healthier
- Company was kdd
- 3 principles to make every food metabolically healthy (protect the liver, feed the gut, support the brain)
- Emulsifiers create gut inflammation
[2:45:20](https://m.youtube.com/watch?v=n28W4AmvMDE&t=9920)
- Artificial sweeteners blocks leptin (the hormone that tells brain you had enough insulin blocks leptin
- that makes you hungrier, and blocks the rewards
- Chronic overstimulation of neurons leads to neuronal cell death but the exitetory neuron has a plan b, it down regulates the dopamin receptor (less chance of dopamin molecul will find receptor to bind to)
- You get hit, rush, receptors go down, next time bigger hit, until huge hit to get nothing that's tolerance, and when the neurons start to die that's addiction
- A neuron needs energy (most energy depend tissue in the body)
- Caffeine is addictive (not toxic)
[2:56:04](https://m.youtube.com/watch?v=n28W4AmvMDE&t=10564)
- Glp1 (acts on brain and gut, decreases rate of gastric emptying)
- Glp1 analogs (used for fat loss, is injected, loose same amount of muscle too so not good)
- These drug causes stomach literally to turn to stone
- Lack of muscle mass is a driver of mortality
- When reduce reward you also reduce desire to live
- Us government makes basically makes 56 billion a year from food
[3:02:48](https://m.youtube.com/watch?v=n28W4AmvMDE&t=10968)
- Brain after long time recaps to facilitate the image of the fat person
- If leptin sensitiv you are happy to burn, if resistent you think you are starving
- Have to break through leptin resistance (driver is insulin, cause blocks leptin receptors)
[3:06:26](https://m.youtube.com/watch?v=n28W4AmvMDE&t=11186)
- Fructose activates reward center
- Anything that stimulates the reward center in extreme is addictive
- With addiction this is where personal responsibility falls down
- The tabbaco industry invented personal responsibility cause they where being killed on the science and needed other way to keep you smoking
[3:18:43](https://m.youtube.com/watch?v=n28W4AmvMDE&t=11923)
- If rice then brown rice cause of fiber
- Best choice cornbread is highest fiber choice (good bread should have carb to fiber ratio of 3:1, 5:1)
- Meat is based on pasture raised, if organic, if injected with antibiotics
- fermented foods good (kimchi, careful of joghurt should be with live cultures)
- Intermittent fasting (good for right patient, right one is one with liver fat)
- Also he is in a fiber company (munch munch)
- You need inviable fiber
- Nova class 1 food is any food without a lable
- Problem with a label is it only tells you whats in the food and not what has been done with it
[3:21:25](https://m.youtube.com/watch?v=n28W4AmvMDE&t=12085)
- Number one recommendation get rid of sugar number two go from a walk
- Eatreal
[3:24:37](https://m.youtube.com/watch?v=n28W4AmvMDE&t=12277)
- Problem is there are 262 names for sugar
- You can't figure it out yourself until there is a line for added sugars
- No greater then 4g per serving
- Anything that has more then 4 ingredients is nova class 4
