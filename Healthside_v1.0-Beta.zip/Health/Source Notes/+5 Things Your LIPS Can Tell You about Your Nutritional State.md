---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": 5 Things Your LIPS Can Tell You about Your Nutritional State
"url:": https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T10:32
updated: 2024-06-19T10:33
---
<iframe title="5 Things Your LIPS Can Tell You about Your Nutritional State" src="https://www.youtube.com/embed/d_1fRLt1EW4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:48](https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=108)
- Pale/grey lips:
    - Anemia (iron deficiency or B12 deficiency, also deficiency of copper can effect ability to take up iron)
    - Get iron in red meat, liver, seafood but spinach not good source
    - Also grains with phythates which are anti nutrients
    - Gut inflammation
[2:55](https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=175)
- Blue lips:
    - Cold/shock
    - Cyanide poisoning
[3:17](https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=197)
- Darker lips:
    - Smoker (also vertical wrinkles)
[5:18](https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=318)
- Dry lips:
    - Lack of essential fatty acids (especially omega 3)
    - Eating fish, cod liver oil is good
    - Could be when consuming lots of omega 6 (most plant oils)
- Chapped lips:
    - Kind of a crossover with dry ones
    - If have dry lips crank up omega 3
    - Chapped lips can be combination of deficiency in omega 3 and vitamin d
    - Don't put anything on body that has mineral oil cause it can distract the fat ciable vitamins and draw out body
    - Also can be zinc deficiency
    - Or you get to much vitamin a (vitamin a toxicity, usually comes from supplement)
    - You get zinc in red meat and seafood
[6:49](https://m.youtube.com/watch?v=d_1fRLt1EW4&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=409)
- Cracks on corner of mouth:
    - B2 deficiency
    - Consume to many refined carbs
    - Vitamin b deficiency also comes from lack of microbiom
    - Good sources for vitamin b2 are egg yolks, quality cheese, leafy greens
