---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": GROUNDING | Ultimate Human Short
"url:": https://m.youtube.com/watch?v=FFio155APgU&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:57
updated: 2024-06-24T19:57
---
<iframe title="GROUNDING | Ultimate Human Short" src="https://www.youtube.com/embed/FFio155APgU?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:39](https://m.youtube.com/watch?v=FFio155APgU&t=99)
- Grounding good for body
- Lot of things we blame for ageing are not due to it are actually lack of raw material and also lack of natural things
- Disease doesn't thrive in alkaline environment
- Its not possible to change pH by drinking water
- pH = potential of Hydrogen (so a energy)
- Touch grass barefoot
- We discharge in the earth
[6:58](https://m.youtube.com/watch?v=FFio155APgU&t=418)
- We change the electrical field in the body when discharging
- Some benefits are that we repolarize the surface of your cells
- When cells repell by charge that's a good thing
- Want to get more oxygen in the cell especially into red blood cells and free up as much surface area for it
- It restores iron channels that are like bouncers at a club
- We are not powered by nutrients we eat or by oxygen we breath, we are powered by adp (made in mitochondria)
- 10% of body weight is mitochondria
- 110 trillion mitochondrial
[8:32](https://m.youtube.com/watch?v=FFio155APgU&t=512)
- As little to 3-5 min will change pH and polarization
[9:01](https://m.youtube.com/watch?v=FFio155APgU&t=541)
- Has links to PMF matts
