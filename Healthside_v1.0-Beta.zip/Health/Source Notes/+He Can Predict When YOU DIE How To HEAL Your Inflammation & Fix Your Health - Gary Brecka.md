---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "He Can Predict When YOU DIE: How To HEAL Your Inflammation & Fix Your Health | Gary Brecka"
"url:": https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": 
created: 2024-06-24T20:00
updated: 2024-06-24T20:01
---
<iframe title="How to Fix Your Diet For Health &amp; LONGEVITY; The Man Who Can Predict When You'll Die | Gary Brecka" src="https://www.youtube.com/embed/K4eRDUaHj-w?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[10:21](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=621)
- We got far away from basics like sunlight, grounding, breathing
- When you put a stress on a body it strengthens
- Re thinks aging is the aggressive persuit of comfort
- Disease isn't caused by lack of drugs
- Vitamin d also has effect on auto immunity
- Body only makes one vitamin on its own and that's vitamin d (make it from sunlight and cholesterol)
- It also acts more like a hormone non vitamin comparable to it
- The darker skin the worse you take up vitamin d3 (that's also why there skin looks better when older)
[21:04](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1264)
- Gary thinks majority of pathologic diagnosed especially neuropathic disorder comes from a viral created
[24:59](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1499)
- If on carnivore and not eating grass fed meat or raw dairy that's also not that good
- Pesticides, herbicides, insecticides is not good
- Glyphosate is terrible (banned in most Europe countries)
- When food is genetically modified the body often doesn't recognize it (get even less nutrients)
- The seed oil itself is not bad its bad that it gets heated and also chemically changed
- If make it simple you need only 5 oils in your life:
	- Four to use for cooking (extra virgin coconut oil, tallow, grass fed butter/ghee
    - 100% extra virgin olive oil
[26:37](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1597)
- Also the soil is worse nowadays
- We used to use potash, cow manure
[28:22](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1702)
- Difference grass fed vs grain fed cow:
	- Better omega 3 to omega 6 ratio
    - Linoleic acid
    - Caliber the saturated fat
    - Also they get light metals from the soil
    - Also healthy bacteria
    - Also the skull will look better of the natural raised cow
[31:20](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=1880)
- He didn't see a link between higher LDL cholesterol and cardiovascular disease
- Social isolation also cause of mortality
[35:19](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2119)
- Normally you should sleep like a bear, be horny, and feel healthy
[38:51](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2331)
- Libido effects relationship
[44:58](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=2698)
- 40% of people can't process folic acid which some things are sprayed with that then leads to your brain going nuts thus ADHD
- Folic acid can be like cocaine for a child
[53:29](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=3209)
- If can't break down homocysteine then can become one of most inflammatory compounds
- It irritates the artery
- Aerie get smaller so you get higher blood pressure
- Even if the heart isn't effected we still medicate it
- You could also get pholate from green leafy vegetables, grass fed meats/eggs
- All about MTHFR gene mutation
[1:02:10](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=3730)
- He thinks weight bearing exercise is good if not have lots of time
- Muscles are metabolic currency
- It's a sponge for sugar and glucose
- Increases metabolic rate
- Helps determine metabolism and body temperature
- Grip strength is important cause when you fall you try to grab stuff
- Grip strength actually directly correlated to longevity
	- There's a measure for how long you should be able to dead hang by age
- Also lean muscle mass directly correlated to longevity
- Resistant training is important
- The best thing in bad mood is to move our bodies
[1:12:26](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=4346)
- Ideal morning routine:
	- Thinks that little wins strengthen us
    - Best thing first is a cold shower (1-3min)
	    - Water can remove temperature of body 29 times the rate compared to air
	        - That's why you can die of temperature of water and not air (story with 3 NFL players on fishing trip)
        - Liver increases of cold shock proteins due to panic of body
        - Release a survival gene
        - Forcing oxygen
        - Activate brown fat (our thermostat), mitrochondrial has affinity for it
        - Also helps lower blood sugar and insulin sensitivity
        - Also increases mood
    - Drink 10oz of hydrogen water (if able to)
    - Then go outside and expose skin to the sun (first 45 min of Day best, only uva no uvb)
    - If can put feet on ground
    - Carbondioxid is the main vasodilator of body not nitric oxide
    - In that 8-10 min done a lot for the body
    - Our bodies crave consistancy
[1:13:39](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=4419)
- PMF, red light and that more "advanced" stuff are like supplements so a addon
[1:16:09](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=4569)
- Gary thinks hydrogen water is the healthiest water you can put into the body
- His next choice would be mountain valley water if traveling
- It's more hydrating
- Better for recovery after athletic performance
- Also thinks that hydrogen water is most studied water out there
[1:23:14](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=4994)
- Red light:
	- Nanometers in light matter
    - We are very photovoltaic beings
    - Effects on Parkinson, inflammation, improved collagen elastin/fibrin, hair follicle restauration, Inflammation microvascular circulation
    - He does minimum 10min (if able he does 20min)
    - Mitrochondrial nitric oxide is released and that 2 times adp (energy) production
	    - Basically kick the mitrochondrial oxide out and oxygen in instead
    - Get some benefit of it by sunlight
    - Gary tested it with nitric oxide test strips
    - Study where 15min of red light Therapie reduced blood glucose levels
- Ben Greenfield also biohacker
[1:26:54](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=5214)
- Presence of oxigen is the absence of disease
- We die of hypoxia (back of oxigen to the brain)
[1:27:51](https://m.youtube.com/watch?v=K4eRDUaHj-w&pp=ygUWZ2FyeSBicmVja2EgYWJvdXQgZGlldA%3D%3D&t=5271)
- He wrote a book called becoming the ultimate human
