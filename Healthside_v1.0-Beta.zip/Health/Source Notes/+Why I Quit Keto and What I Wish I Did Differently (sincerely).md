---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Why I Quit Keto and What I Wish I Did Differently (sincerely)
"url:": https://m.youtube.com/watch?v=VnSjz8Sl1oU&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T20:10
updated: 2024-06-24T20:11
---
<iframe title="Why I Quit Keto and What I Wish I Did Differently (sincerely)" src="https://www.youtube.com/embed/VnSjz8Sl1oU?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:33](https://m.youtube.com/watch?v=VnSjz8Sl1oU&t=153)
- He eats carbs but not a lot
- He eats fruit, honey, sweet potatoes, lentils
- He Phase in and out of keto
- He would have consumed more protein when eating keto
- he would look more on potassium (need 3-4 times more potassium, potassium to sodium)
- He wants to add multivitamin (or organ meat, liver, beef)
	- Has supplement in the description
- He would control his saturated fat intake cause saturated fat in abundance in over chloric state is also going to increase insulin resistance
	- So want to maybe eat leaner meat and then add oil with something else
[12:49](https://m.youtube.com/watch?v=VnSjz8Sl1oU&t=769)
- Be less carb phobic:
	- Carbs with workout
- It seems that nuts also have high omega 6
- He don't wanted to fear insulin:
	- Insulin isn't always bad
    - He would have measured the levels more
- He would have monitored his cortisol levels more
- He should have monitored his cortisol to DHEA ratio
- He should have followed more what he experienced rather then following the research exactly to the point
