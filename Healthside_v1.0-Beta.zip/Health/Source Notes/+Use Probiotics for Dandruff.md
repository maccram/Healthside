---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Use Probiotics fot Dandruff
"url:": https://m.youtube.com/watch?v=H9Uhj7muGmg&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-12T13:58
updated: 2024-06-12T13:59
---
<iframe title="Use Probiotics for Dandruff" src="https://www.youtube.com/embed/H9Uhj7muGmg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:59](https://m.youtube.com/watch?v=H9Uhj7muGmg&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=59)
- More in winter
- More when deficiency in vitamin d
- Increase of Steph bacteria on skin
- Antibiotic help for short but not long
[2:55](https://m.youtube.com/watch?v=H9Uhj7muGmg&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=175)
- Mycobiota
- Friendly fungus that grow inside our body
    - If not right balance between fungus and bacteria lot of issues can happen
    - Helps with with absorption of nutrients, ph, metabolism, Immunsystem
[3:05](https://m.youtube.com/watch?v=H9Uhj7muGmg&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=185)
- He thinks it's a imbalance of friendly fungus and bacteria
[3:51](https://m.youtube.com/watch?v=H9Uhj7muGmg&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=231)
- Thinks you should use natural antibiotic/antifungal
- Like garlic, oregano
- Add friendly fungus and yeast (link in description)
