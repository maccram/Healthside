---
tags:
  - 📥/📜/🟢
type: article
"general_subject:": "[[Health]]"
"specific_subject:": 
"url:": https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5071963/
---
- So the aim of this study is to assess the effect of cow ghee on memory and lipid profile
- Cow ghee and butter group showed no significant effect on memory in EPM and MWM model. There was reduction in weight of animals in Cow Ghee group and increase in weight with Butter
- The result of experiment suggests that no beneficial effect cow ghee and butter on cognition was seen. However, ghee is relatively safer when compared to Butter in considering lipid profile.
- However, there is a lack of scientific data regarding the effect of Cow Ghee on learning and memory.
- Amongst all edible fats it is found that nutrition composition of cow ghee and butter is comparatively similar. The total content of fat (saturated, monounsaturated, polyunsaturated and cholesterol) is nearly the same [10] hence, we decide to take butter as a comparator arm and compare the effect of cow ghee and butter on memory and lipid profile.
- There has been concern about the possibility of ghee contributing to an increased risk of cardiovascular disease due to its high percentage of saturated fatty acids, leading to increased synthesis of cholesterol. Some previous studies have shown no effect or decreased LDL and increased HDL cholesterol but increased in weight
- We cannot conclude beneficial effect of Cow Ghee and butter on cognition; and lipid profile from present study. Effect of cowghee on weight and serum lipid profile was better than butter