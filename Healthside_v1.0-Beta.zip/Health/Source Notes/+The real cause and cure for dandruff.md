---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The real cause and cure for dandruff
"url:": https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-12T10:53
updated: 2024-06-12T10:55
---
<iframe title="The REAL Cause and Cure for DANDRUFF" src="https://www.youtube.com/embed/x365pPLtNJo?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:26](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=86)
- Normally monthly cycle where the scalp resets
- Head and shoulders uses zpt (anti fungal, bacterial, toxic for reproduction organs)
[1:38](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=98)
- It's a overgrowth of malassezia fungus (normally we have it)
[3:45](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=225)
- In the root there is basically a imbalance of the microflora of the scalp
- This fungus eats fat (but it only likes saturated fat, likes to eat triglycerides doesn't like omega 6)
[4:15](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=255)
- The true cause is in the gut flora
[5:29](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=329)
- Antibiotic kills bacteria but the problem is you also kill bacteria that keep your fungus under control
[6:11](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=371)
- He gets lots of data of patents
[6:25](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=385)
- First thing to fix it is put back in microflora
- 1tb of kimchi + water and then put that on scalp wait 15min (so you put probiotic back)
- Other option is 2tb olive oil, 1/2tb coconut oil rub it in then leave over night
[8:10](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=490)
- Next recommendation is to fix the diet:
- Low carb, low omega 6 oils, probiotics (sauerkraut, kimchi, kiefer), no sugar
- This yeast or fungus loves sugar
[10:09](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=609)
- Change shampoo
- Shower filter (filters at least chlorine, maybe even fluoride)
[10:53](https://m.youtube.com/watch?v=x365pPLtNJo&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=653)
- Resources in description