---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Is it safe to use apple cider vinegar for hair - Dr. Berg
"url:": https://m.youtube.com/watch?v=dbxXJgnAaKw&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-12T13:08
updated: 2024-06-12T13:10
---
<iframe title="Is It Safe To Use Apple Cider Vinegar For Hair? – Dr. Berg" src="https://www.youtube.com/embed/dbxXJgnAaKw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:25](https://m.youtube.com/watch?v=dbxXJgnAaKw&pp=ygUYZHIgYmVyZyBmYXR0eSBkYW5kcnVmZiAg&t=85)
- 1tb with 16oz water
- Not keep long in hair
- Once or twice a week