---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Dr. Paul Saladino Claims Oatmeal is the Most Dangerous Food Humans can Eat (and Oat Milk)
"url:": https://m.youtube.com/watch?v=9dEYi1um--E&pp=ygUFSG9uZXk%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:55
updated: 2024-06-24T19:55
---
<iframe title="Dr. Paul Saladino Claims Oatmeal is the Most Dangerous Food Humans can Eat (and Oat Milk)" src="https://www.youtube.com/embed/9dEYi1um--E?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[7:31](https://m.youtube.com/watch?v=9dEYi1um--E&pp=ygUFSG9uZXk%3D&t=451)
- Paul thinks oats a worst thing to eat
- Oatmeal is a smashed oat seed
- All plants contain defence chemicals, also seeds
- Saponins is the defence chemical in oats
	- Also quinoa
    - Resilient to cooking
- Heavy mental in oats:
	- Gene that allows accumulation of cadmium (fertility, mental health issues)
- Pesticides:
	- Glyphosate
    - Chlormequat
    - 2,4-Dichlophenoxyacetic acid
    - Atrazine
- Gluten:
	- Distributive for human gut
- Mold toxins:
	- When store grains that comes
- Phytic acid:
	- inhibit absorbtion of minerals
    - Fermented overnight only gets rid of 40% of it
    - Corn and beans also have it
    - Steals minerals from gut
- He thinks a better option for breakfast is steak, hamburger, eggs, fruit, raw milk, joghurt with berry
[11:00](https://m.youtube.com/watch?v=9dEYi1um--E&pp=ygUFSG9uZXk%3D&t=660)
- Mold:
	- Accumulate in body
    - Headache, stomache ace
[13:24](https://m.youtube.com/watch?v=9dEYi1um--E&pp=ygUFSG9uZXk%3D&t=804)
- Instant oats:
	- Chemicals added
    - Becomes high glycemic
- Thomas says glucose spike isn't necessarily the problem
- Paul thinks insulin has valuable roles in the body (signals to kidney to hold on to minerals/electrolytes, electrolyte balance, also triggers some things with antioxidant balance, more glutathion function)
- Thinks when people are not metabolicly functioning well then you'll have the problem with the high spikes
- He thinks carbs are not a problem for people
[14:17](https://m.youtube.com/watch?v=9dEYi1um--E&pp=ygUFSG9uZXk%3D&t=857)
- Oat milk:
	- Has same problems as normal oats
    - Additionally has carrageenan, seed oils and stabilizers
