---
tags:
  - 📥/📜/🟢
type: article
"general_subject:": "[[Health]]"
"specific_subject:": 
"url:": https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9708346/
---
- Hyperlipidemia is a risk factor for cardiovascular diseases.
- We divided 23 C57BL/6NJ males (16-week-old) into 3 groups, and each group received either a control diet, a high-fat diet of coconut oil (coconut oil), or a high-fat diet of omega-3-rich pork lard (omega lard) for 28 days. Thereafter, fasting serum lipids and fecal microbiomes were analyzed.
- cholesterol, triglyceride, and LDL levels of the omega lard-treated group were significantly reduced compared to the coconut oil-treated group (P < 0.05)
- microbiome analysis revealed a significant increase in the abundance of Lachnospiraceae
- increased serum lipid content was positively correlated with the abundance of Bacteroidaceae (P < 0.05) and negatively correlated with the abundance of Lachnospiraceae (P < 0.05).
- The excellent protection offered by omega-3-rich pork lard against hyperlipidemia indicated that pork lard could be used as alternative cooking oil for health-conscious individuals
- Western diet, the prevalence of obesity and other metabolic diseases, including cardiovascular disease (CVDs) and nonalcoholic fatty liver disease (NAFLD), has increased significantly
- Several studies evaluated the health benefits of omega-3 supplements, including the improvement of metabolic parameters and cardioprotective effects in an animal model [4]
- omega-3 supplement has been reported to manipulate the gut microbiome, including an increase in the abundance of Bacteroidetes, Verrucomicrobia, Akkermansia, Lactobacillus, and Bifidobacteria and a decrease in the abundance of Firmicutes and Proteobacteria
- omega-3 fatty acids favored the growth of short-chain fatty acid- (SCFA-) producing bacteria
- This indicated that omega-3 can also alter the gut microbiome of mice.
- The present study revealed that including omega-3 fatty acids in the diet, not in the form of supplementation but through consumption of omega-3-rich pork lard, lowers serum lipid levels, including the levels of cholesterol, triglycerides, and LDL. Furthermore, this change in diet does not damage liver and kidney functions.
- However, a diet rich in omega-3 fatty acids significantly decreases liver weight relative to body weight, suggesting less fat accumulation in the live
