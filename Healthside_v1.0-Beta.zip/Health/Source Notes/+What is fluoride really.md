---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": What is fluoride really?
"url:": https://m.youtube.com/watch?v=sPGdfZtLYKk&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-19T10:25
updated: 2024-06-19T10:27
---
<iframe title="What is fluoride really?" src="https://www.youtube.com/embed/sPGdfZtLYKk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[8:05](https://m.youtube.com/watch?v=sPGdfZtLYKk&t=485)
- Fluoride is a byproduct of phosphate fertilizer, also comes from aluminum
- It can prevent tooth decay (but could get same by just brushing teeth)
- It's 4 times the level in water then what is on toothpaste warning for calling poison control
- Gary brecka believes the dosage determines the poison
- Accumulative toxicity is the problem
- So he thinks fluoride is what needs to be permanently out of our body
- There was a program that was suppressed first (national toxicicology program fluoride)
- Fluoride has effect on neurons
- If have the money for filtering system stage 4 one get one and add back minerals with baja gold sea salt salt or Celtic salt to remineralize the water
- It's hard to filter out fluoride without reverse osmosis
- Also with showering it's not good
