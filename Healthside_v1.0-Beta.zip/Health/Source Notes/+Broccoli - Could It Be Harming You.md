---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": "Broccoli: Could It Be Harming You"
"url:": https://m.youtube.com/watch?v=ZdowXuSdMKU&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
---
<iframe title="Broccoli: Could It Be Harming You?" src="https://www.youtube.com/embed/ZdowXuSdMKU?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:32](https://m.youtube.com/watch?v=ZdowXuSdMKU&t=92)
- Broccoli prevents iodine consumption
- Broccoli can cause thoride problems
	- Especially when get to less iodine
- Removing vegetables can be valuable, so its more individual cause not everyone will benefit from vegetables all the time
- Vegetables overall are better to have in the diet then high fructose corn sirup, seed oils, highly processed fruits
- If you thrive then keep going
[4:11](https://m.youtube.com/watch?v=ZdowXuSdMKU&t=251)
- Also kale
- Here there is lot of bio-individuality
- The content of goitrin blocks iodine consumption
- Also increased risk of thyroid cancer when low iodine
[6:36](https://m.youtube.com/watch?v=ZdowXuSdMKU&t=396)
- One type of defense chemicals are oxalates
- Most common in almonds, turmeric powder, spinach, white potatoes, rhubarb
- Is associated with kidney stones
