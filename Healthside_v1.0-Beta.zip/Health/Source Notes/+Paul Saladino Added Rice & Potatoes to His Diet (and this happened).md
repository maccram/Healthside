---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Paul Saladino Added Rice & Potatoes to His Diet (and this happened!?)
"url:": https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
created: 2024-06-24T19:48
updated: 2024-06-24T19:49
---
<iframe title="Paul Saladino Added Rice &amp; Potatoes to His Diet (and this happened!?)" src="https://www.youtube.com/embed/j-ibsSomRuI?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[3:35](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=215)
- 250-350 carbs a day
	- Comes from fruit, fruit juice, Marple syrup
- He experimented with rice nad potatos
- He doesn't want to be dogmatic about a thing he just wants to feel good
[12:06](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=726)
- Brown rice has more heavy Metal
- He started with organic white rice (he rinses it 7 times
- He didn't feel good with rice
- He would eat vegetables again but he doesn't feel good when eating them
- Also with white potato's he didn't feel good
- Some vegetables acummulate heavy metals when grown in soil that has heavy metals
- He eats raw milk with honey
- It seems lot of people in health space say only valid study is a randomized control trial (he thinks clinical and personal experience also has some value)
[15:56](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=956)
- There's not really a fruit that he has hard time digesting
- Dry fruits can have mold toxins
[20:34](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=1234)
- Sucrose drives up FGF21
- Signals brain more blood flow to certain region in brain
- Creates a protection effect where a healthy person won't overeat sugar
- Also increase in metabolic effect
- In people who are overweight that doesn't happen
- So they think you should look at a metabolically person different then a overweight one
- A healthy one shouldn't worry about carbs, Paul also eats more carbs based on activity level
- He doesn't think that good carbs cause insulin resistance
[25:34](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=1534)
- What causes metabolic disfunction is the Ultaproccessed carbs and seed oils
- Metabolically unhealthy people handle the fruit and carbs not that well, they should limit the things but he wouldn't eliminate them completely
- Often if just keto diet and fear carbs then often electrolyte/sleep issues and sex hormones decline
[29:59](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=1799)
- Paul thinks you won't get sick cause you have excess energy
- People get not obese cause they have excess energy they get obese cause they don't make energy out of fuel
- You need to move fuel through electro transport chain
- when metabolically healthy then you need to go high before you overdo it
- When you have the right nutrition thus energy you want automatically to move
- Food quality is the foundation
[32:21](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=1941)
- How thinks the key things that disrupt energy production are:
	- Access linoleic acid from seed oils
    - lipopolysachharide from a disordered gut
- Linoleic acid gets stuck in our membranes
- When messed up gut the energy metabolism will be also messed up
- Saturated fat is protective against lps
[42:18](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=2538)
- Paul thinks exercise is more for brain and mental wellbeing then only losing weight
- It's not only calories in calories out its also about the food quality that effects it
[44:36](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=2676)
- Energy flux:
	- If you eat more you want to move more
    - For that the energy you have to be able to make energy out of it (because of poor quality food)
[47:25](https://m.youtube.com/watch?v=j-ibsSomRuI&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=2845)
- If you burn hotter you life longer cause we are a selfregenerating organism
