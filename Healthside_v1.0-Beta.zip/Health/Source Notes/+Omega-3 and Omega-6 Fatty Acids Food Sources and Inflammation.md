---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "Omega-3 and Omega-6 Fatty Acids: Food Sources and Inflammation"
"url:": https://m.youtube.com/watch?v=iXXBwBMtGmQ&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T10:40
updated: 2024-06-19T10:41
---
<iframe title="Omega-3 and Omega-6 Fatty Acids: Food Sources and Inflammation" src="https://www.youtube.com/embed/iXXBwBMtGmQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:20](https://m.youtube.com/watch?v=iXXBwBMtGmQ&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=20)
- Omega 6 increases inflammation
- Omega 3 decrease it
- Ratio should be 1:1
[0:40](https://m.youtube.com/watch?v=iXXBwBMtGmQ&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=40)
- Goes through omega 6 fatty acids
- Basically plant oil
[1:09](https://m.youtube.com/watch?v=iXXBwBMtGmQ&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=69)
- Omega 3:
    - Fish oil
    - Cod liver oil
    - Sardines
    - Fish
    - Anchovies
    - Eggs
    - Grass fed meat
[3:54](https://m.youtube.com/watch?v=iXXBwBMtGmQ&pp=ygUSb21lZ2EgMyB2cyBvbWVnYSA2&t=234)
- It's harder for the body to convert plant oil into DHA and EPA
- Inexpensive fish oil is often very low quality so he wouldn't consume it
- Virgin cod liver oil is better
- Larger fish are higher in mercury
- The more selenium the less mercury effect in body
- Wheatgrass (kamut) juice has also a lot selenium (supports enzymes for detoxification in liver)
