---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The Best Natural Sources of Omega-3 Fatty Acids – Dr. Berg
"url:": https://m.youtube.com/watch?v=5YgWjxQW7LE&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T07:03
updated: 2024-06-19T07:04
---
<iframe title="The Best Natural Sources of Omega-3 Fatty Acids – Dr. Berg" src="https://www.youtube.com/embed/5YgWjxQW7LE?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:55](https://m.youtube.com/watch?v=5YgWjxQW7LE&pp=ygUUQmVzdCBvbWVnYSAzIHNvdXJjZXM%3D&t=115)
- Fish oil often gets bad fast
- Better source is krill oil (fish similar to shrimp, won't turn bad that fast)
- has EPA and DHA, also has phosphatidylcholine which protects the cell membrane, this is for cellular communication (sodium potassium pump)
- 44% of that cell is made from cholesterol and phosphor lipids
