---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Is Fluoride Lowering IQs? Why Tap Water Needs to Be Filtered From Your Life For Good | Gary Brecka
"url:": https://m.youtube.com/watch?v=JlfJEVWPJUQ&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Garry Brecka]]"
created: 2024-06-24T19:55
updated: 2024-06-24T19:57
---
<iframe title="Is Fluoride Lowering IQs? Why Tap Water Needs to Be Filtered From Your Life For Good | Gary Brecka" src="https://www.youtube.com/embed/JlfJEVWPJUQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:00](https://m.youtube.com/watch?v=JlfJEVWPJUQ&t=0)
- Studies on it
- 27 studies combined, conclusion of it is that fluoride has a bad affect
- There is impact on cognitive function (could impact children development, study)
- 52 of 55 studies decreases in child IQ with fluoride consumption
[3:05](https://m.youtube.com/watch?v=JlfJEVWPJUQ&t=185)
- Breathwork guide at the ultimatehuman.com/breathwork
- He thinks we want to limit neurotoxin fluoride
- Fluoride is in nature but in very low amounts
- A byproduct of phosphate fetilizer is fluoro-silicic acid (if keeps in the fertilizer it would kill the plant)
- We put it into water supply under the disguise that it prevents tooth decay
- Also use it also in medical sterilization, electroplating, Glas etching
[14:52](https://m.youtube.com/watch?v=JlfJEVWPJUQ&t=892)
- Single vs cumulative dose of toxicity:
	- If a toxin is save in low dose its often allowed and seen as save
    - In Europe often use cumulative dose
    - Most foods are gmo cause they spray them with glyphospate and otherwise it would kill the seed
	     - Glyphospahate is in roundup
- The information about the studies where held back until a court order
- Flouride crosses the blood brain barrier thus directly effect the brain
- It also generates free radicals, causes several toxic effects in the brain, also cause of several pathogenic conditions of the brain
- Also crosses placental barrier and reaches the fetal brain (so for pregnant women not good)
	- Also bad for teens
- Toothpaste with fluoride has warning lable that says if children under age 6 and they swallow it then you should call poison control
[16:37](https://m.youtube.com/watch?v=JlfJEVWPJUQ&t=997)
- Look for water filtration system best would be reverse osmosis
- At least get chlorine and fluoride out of water
- After its been under reverse osmosis add minerals back in water (Celtic salt)
- He does hydrogen water after the reverse osmosis
- There is all sorts of flouride free toothpaste
