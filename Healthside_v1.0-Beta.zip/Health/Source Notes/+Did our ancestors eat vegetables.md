---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Did our ancestors eat vegetables?
"url:": https://m.youtube.com/watch?v=qaM1kIKWQWE&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:46
updated: 2024-06-24T19:47
---
<iframe title="Did our ancestors eat vegetables?" src="https://www.youtube.com/embed/qaM1kIKWQWE?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:54](https://m.youtube.com/watch?v=qaM1kIKWQWE&pp=ygUYcGF1bCBzYWxhZGlubyB2ZWdldGFibGVz&t=174)
- The tribe (Hadza) he was at doesn't eat vegetables
- Research paper
- They only eat vegetables when they starve
- Honey was there favorite food
- They only eat beabob
- Tubers as fallback food
- He eats fruit, honey, meat and raw dairy
