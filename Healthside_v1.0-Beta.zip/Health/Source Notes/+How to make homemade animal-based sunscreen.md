---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How to make homemade animal-based sunscreen
"url:": https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:42
updated: 2024-06-24T19:43
---
<iframe title="How to make homemade animal-based sunscreen" src="https://www.youtube.com/embed/AsUmqF5A208?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:20](https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=80)
- Most normal sun screen contains seed oils
	- That extra linoleic acid in skin leads to more suceptible skin cells to sun and therefore damage thus higher risk of skin cancer
- He puts tallow, bees wax, coconut oil and zinc
[2:05](https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=125)
- It has such good ingredients that you actually could eat it
- The zinc powder is non nano
- Want a double boiler to melt the ingredients
[2:34](https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=154)
- In normal sunscreen there is oxybenzone/octorylene/avobenzone which is linked to cancer
[3:41](https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=221)
- Zink is what protects from uvb and uva
- The ingredients are not comedogenic (don't cause pores to clog)
[6:15](https://m.youtube.com/watch?v=AsUmqF5A208&pp=ygURbmF0dXJhbCBzdW5zY3JlZW4%3D&t=375)
- Shows how he makes it
	- 2tbs bee wax
    - 1/2 cup coconut oil
    - 1/2 cup of tallow
    - Melts those 3 then adds zinc (non nano one, this is the uvb/uva blocking part of sunscreen)
    - Then does it away from the heat and stirs it
    - You could make it more tinted by putting cacao in there
