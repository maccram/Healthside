---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "World No.1 Biohacking Expert: I Tested 100,000 People's DNA. This Diet Will Kill You - Gary Brecka"
"url:": https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@The Diary Of A CEO\r]]"
created: 2024-06-19T10:45
updated: 2024-06-19T10:46
---
<iframe title="World No.1 Biohacking Expert: I Tested 100,000 People's DNA. This Diet Will Kill You - Gary Brecka" src="https://www.youtube.com/embed/10enqcw2Qiw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[9:49](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=589)
- All comes from nutrient deficiencies (methylation)
- Disease rather happens in us then to us
- Don't supplement for sake of supplementing
- Problem is we don't have data (need to get at least some data)
- ADHD and ADD are actually attention overload disorders (so overactive mind)
- Believes everyone should do a genetic methylation test (will tell you what raw material the body can transform and what not)
[11:22](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=682)
- Basically humans are not working optimally
- While we can't fix the gene we can supplement for it its function
- Most common gene mutation is MTHFR (can't transform folic acid, inexpensive to supplement)
[21:19](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=1279)
- 3 biomarkers you need to understand
    - Glycemic profile (how good insulin and sugar metabolism is, 3 markers glucose/hemoglobin A1 is a 3 month average of blood sugar/insulin)
        - Blood sugar root of all evil
    - Hormons (DHEA and protein called shbg)
    - Basic nutrient deficiencies (vitamin D3, magnesium, potassium, vitamin B12)
    - And one that only need one time in life is methylation test (Look at 5 genes MTHFR, MTR, MTRR, AHCY, COMT)
- Anxiousness basically raise of catacolamins same class of neurotransmitters there for fight or flight response
    - Usually those people are deficient in b vitamins (especially b12)
    - Also these catacolabamines could be driven by trauma, the gene mutation, real fear
    - If catacolabamines aren't down regulated then our mind is awake and we are fearful
[22:46](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=1366)
- In 50% of people there is a deficiency in vitamin d3
- Every body has a receptor for it, you make it out of sunlight and cholesterol
- Vitamin B12 deficiency
- 40% would be hormon deficiencies (out of normal range, deficiency in shbg/dhea)
- By putting the raw material in the hormon levels will normalize again
- Glycemic levels very high in most so pre diabetic (is when we overload our body with lots of refined carbs, not only sugar)
[44:16](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=2656)
- Life insurance companies are very accurate
- In 2008 crisis no insurance company failed
- They know day, time and cause of death
[45:06](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=2706)
- Study where looked at sodium and migrane correlation
- Lots of people have to low sodium (People that go to in a sauna, exercise and don't remineralize)
- If you are deficient then you can supplement with Baja sea salt or Celtic one
[54:53](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=3293)
- 5 things to do regularly
    - When wake up drink mineralized water
        - water with Baja gold sea salt, it has a lot of trace minerals
        - Himalayan sea salt not good cause has lots of heavy Metal
        - Celtic sea salt also good
        - He wouldn't use table salt at all
    - Would take DHA/EPA fish oil supplement, omega 3 supplement
    - Then morning routine with sunlight/grounding/breath work/cold shower
[59:49](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=3589)
- We get 3 things from nature its magnetism from earth, oxygen from air and light from the sun
- The further we distance ourself from that things the sicker we become
- We are meant to spend 87% of time outside
- Seed oils are oxidizing in our skin our cancer rates are exploding cause of our diet not the sun
- When we touch the earth we discharge into the earth and you actually change the polarity in the body
- Also see difference in blood after grounding
- The grounding mattresses use the ground wire for grounding
- He has PMF matt, it also gets out electro smog out of body
- To change the pH of blood you need grounding
- The more acidic we become the more sick we become
[1:03:33](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=3813)
- He uses hypermax its based otto warburgs work
- Exercising the diathrem
- Posture also has effect on that
- Presence of oxygen is the absence of disease
- He does wim Hof Style breathwork (does 3 rounds of 30 breaths)
- He thinks if we don't do what we promise ourselves then we lose self confirdence
[1:11:54](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=4314)
- Benefits of red light therapy
    - In Literatur called photobiomodulation
    - Different nano meters of light have different effects of body
    - Reduce inflammation, increase microvascular circulation
    - Red light goes through wall of midrochondrial and kicks out gas called mitrochondrial nitric oxide and forces oxygen to dock
    - Instead of normal energy you give the cell through that 16 times more
    - 20 min of redlight
    - Also should expose yourself to sunlight especially the first 45 min of Day (there is no uva/uvb)
    - Also mentioned cycadian circle with relation to sun
    - You can ground/breathwork and get sunlight
[1:13:36](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=4416)
- He thinks hydrogen water is best water to put into the body
- Theres a website called hydrogenstudies.com where there are studies about hydrogen water
- Hydrogen ic gas is also used in therapy against inflammation, improving absorbtion of supplements, improving athletic performance, helps neural inflammation
[1:17:27](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=4647)
- Ozempic
    - Is a peptide
    - Good for type two diabetics or significant obesity
    - Not really good though
    - Most weight you use is lean body mass
[1:25:03](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=5103)
- If you want to put someones life expectancy in half put them into isolation
- It's seen a lot in old people when their wife/husband goes usually they too go
- When the mind surrenders the body does
- Also cells live in community too
[1:28:03](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=5283)
- Mortality exelerates post retirement
- Probably due to loss of purpouse
[1:30:49](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=5449)
- There is something called life insurance life annuity and you basically put both on one person and you can't lose
[1:38:16](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=5896)
- Genes are like blueprints
- When there are some genes that aren't like they should be they want to find ways around it
- Genes follow the methylation pathway
- Also if certain genes are not that high then higher likely hood of addiction (Cause depleted level of dopamin)
- He have seen cases with even mental diseases like bipolar solved
[1:40:57](https://m.youtube.com/watch?v=10enqcw2Qiw&pp=ygULZ2FyeSBicmVja2E%3D&t=6057)
- MTHFR gene mutation is the worst but easiest to fix
