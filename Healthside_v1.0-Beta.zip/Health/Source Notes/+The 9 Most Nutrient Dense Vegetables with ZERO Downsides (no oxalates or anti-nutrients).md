---
tags:
  - 📥/🎥/🔴
aliases: 
type: video
"title:": The 9 Most Nutrient Dense Vegetables with ZERO Downsides (no oxalates or anti-nutrients)
"url:": https://m.youtube.com/watch?v=Dy8o3biclO4&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t
"general_subject:": 
"specific_subject:": 
"channel/host:": "[[@Thomas DeLauer]]"
---
<iframe title="The 9 Most Nutrient Dense Vegetables with ZERO Downsides (no oxalates or anti-nutrients)" src="https://www.youtube.com/embed/Dy8o3biclO4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[10:07](https://m.youtube.com/watch?v=Dy8o3biclO4&pp=ygUjdmVnZXRhYmFsZXMgd2l0aCBsb3cgYW50aSBudXRyaWVudHM%3D&t=607)
- Vegetables with a lot anti nutrients aren't that good
- List of vegetables with low oxalates, phytic acid and low anti nutrients:
	- Mushrooms
	    - Vitamin D2
    - Onions
	    - Most potent source of inulin (good for microbiome)
        - Quercetin (helps anti oxidant production)
    - Avocado
	    - Technically is a fruit
        - High in potassium
    - Bean sprouts
	    - With sprouting you break down anti nutrients and also make new nutrients available
        - Vitamin C
    - Radishes
	    - Good source of fiber
- More in the oxalates category:
	- They blood mineral absorption
    - Cooking vegetables break them down
    - Brussel sprouts
	    - Rich in indole.3 carbinol which converts and helps to break down the toxic estrogen
    - Garlic
	    - Low in oxidates
        - Increase in natural killer cells and tells (immune system more active in good way)
        - Decrease of length and severity illnesses
    - Bok choy
	    - Cook it
    - Cucumber
	    - Not nutritional fiber
    - Recommends to get in garlic, brussel sprouts and onions
