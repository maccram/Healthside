---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": This SUPERFOOD is ILLEGAL?? All about RAW MILK
"url:": https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Paul Saladino MD]]"
created: 2024-06-24T19:50
updated: 2024-06-24T19:50
---
<iframe title="This SUPERFOOD is ILLEGAL?? All about RAW MILK" src="https://www.youtube.com/embed/Mi0WTAtmElg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:22](https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t=142)
- Safety:
	- Experiment where raw milk not develop fungus and pasteurized one did
    - Raw milk has lot of things in it that keep it from becoming a pathogenic breathing ground
    - There are lot of farms that do raw milk in big amounts and do testing that its save
    - Also when raw milk came up there were worse hygienic conditions
[6:06](https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t=366)
- Gut benefits:
	- Lot of studies
    - Children growing up with drinking raw milk have less risk of asthma, Enzyms and allergies
    - Also improves there immune system
    - Raw cow milk had same protective effect then breast milk for children
    - Also reports of women who struggle with breast feeding then drink raw milk and improve there ability
    - Also benefits human gut (changes microbacteria positively, also fix damaged gut)
[6:36](https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t=396)
- Joint benefit:
	- Single best source of msm (benefitial for joints)
[6:37](https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t=397)
- Where to find raw milk?
	- Not legal everywhere
    - realmilk.com
[9:49](https://m.youtube.com/watch?v=Mi0WTAtmElg&pp=ygUJcmF3IGRhaXJ5&t=589)
- Lactose intolerant:
	- Raw milk has bacteria that get rid of lactose
    - Also fermenting the milk results into lower lactose
    - Can make kefir yourself
    - Also could do raw cheese (Parmesan reggiano, raw butter)
	    - If want raw cheese don't want it to be heated over 102-103 fahrenheit
    - Raw butter is very valuable
