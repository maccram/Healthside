---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": How To Fix Your Chapped Lips? – Dr.Berg On Remedy For Chapped Lips
"url:": https://m.youtube.com/watch?v=xVG2K1zew4c&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-19T06:54
updated: 2024-06-19T06:57
---
<iframe title="How To Fix Your Chapped Lips? – Dr.Berg On  Remedy For Chapped Lips" src="https://www.youtube.com/embed/xVG2K1zew4c?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[1:10](https://m.youtube.com/watch?v=xVG2K1zew4c&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=70)
- Lip balm actually not good thing to do cause a lot of times it has alcohol/some solvent/mineral oil in it that actually pulls oil out of lips and you need more of it
- Same with hand cream
- Behind dry lips there's a vitamin B2 deficiency
    - Leads to dry lips
    - Eventually to cracked corners of mouth
    - Could become infected with fissures (Candida)
- Vitamin b2 is co enzyme has function of breaking down fats and ensuring that the skin is lubricated
[1:45](https://m.youtube.com/watch?v=xVG2K1zew4c&pp=ygUQZHJ5IGxpcHMgZHIgYmVyZw%3D%3D&t=105)
- Food that has vitamin b2:
    - Eggs
    - Leafy greens
    - Nuts
    - Dairy
    - Meats and fish
- Deficiency usually comes from birth control, vegan and refined foods
