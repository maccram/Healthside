---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": "Keto Diet: Water and Electrolytes are Essential | Andrew Huberman and Lex Fridman"
"url:": https://m.youtube.com/watch?v=vEjhBEyCbME&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Lex Fridman]]"
created: 2024-06-19T10:39
updated: 2024-06-19T10:40
---
<iframe title="Keto Diet: Water and Electrolytes are Essential | Andrew Huberman and Lex Fridman" src="https://www.youtube.com/embed/vEjhBEyCbME?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:42](https://m.youtube.com/watch?v=vEjhBEyCbME&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=162)
- Keto diet can be beneficial for some people if done right
- If over consume water and don't get enough electrolytes you die
- Huberman eats meat, vegetables, and fruit
