---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": The Health Benefits of Honey – Dr.Berg
"url:": https://m.youtube.com/watch?v=Byhaw2k9PtM&pp=ygUFSG9uZXk%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@Dr. Berg]]"
created: 2024-06-24T20:07
updated: 2024-06-24T20:08
---
<iframe title="The Health Benefits of Honey – Dr.Berg" src="https://www.youtube.com/embed/Byhaw2k9PtM?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[0:21](https://m.youtube.com/watch?v=Byhaw2k9PtM&pp=ygUFSG9uZXk%3D&t=21)
- In right form its anti microbial
- Anti inflammentory
- Anti allergy
- Lowers blood pressure
- B vitamins
- Calcium, potassium
- High fructose
- Make sure its raw and not pasteurized honey (cause if they cook it they also destroy good nutrients)
