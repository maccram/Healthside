---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": I Was WRONG About Veggies (Plant Problems) 2024
"url:": https://m.youtube.com/watch?v=xYRUCx7Bj08&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": "[[@KenDBerryMD]]"
created: 2024-06-19T06:57
updated: 2024-06-19T06:58
---
<iframe title="I Was WRONG About Veggies (Plant Problems) 2024" src="https://www.youtube.com/embed/xYRUCx7Bj08?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[4:30](https://m.youtube.com/watch?v=xYRUCx7Bj08&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=270)
- For some vegetables are not that beneficial
- Vegetables have lots of carbs
- There are anti nutrients that can inhibit the absorption of good nutrients
- For some it can cause inflammation
[5:30](https://m.youtube.com/watch?v=xYRUCx7Bj08&pp=ygUQa2V0byB2cyBvbW5pdm9yZQ%3D%3D&t=330)
- If it applies to you try beef butter bacon and eggs challenge
