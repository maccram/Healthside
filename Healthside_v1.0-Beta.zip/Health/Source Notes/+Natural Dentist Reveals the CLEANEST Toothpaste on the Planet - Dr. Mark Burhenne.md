---
tags:
  - 📥/🎥/🟢
aliases: 
type: video
"title:": Natural Dentist Reveals the CLEANEST Toothpaste on the Planet! | Dr. Mark Burhenne
"url:": https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t
"general_subject:": "[[Health]]"
"specific_subject:": 
"channel/host:": 
created: 2024-06-24T20:04
updated: 2024-06-24T20:05
---
<iframe title="Natural Dentist Reveals the CLEANEST Toothpaste on the Planet! | Dr. Mark Burhenne" src="https://www.youtube.com/embed/C8olnxNE6AQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>
___
[2:20](https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t=140)
- Best brand for him is boka
- The big companies only are valuing profit
[2:49](https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t=169)
- Risewell toothpaste
[6:49](https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t=409)
- Has own toothpaste called fygg
- Mouthwash is also very bad
- Dr mark burhenne is the dentist
[10:26](https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t=626)
- Slate flosser
[11:21](https://m.youtube.com/watch?v=C8olnxNE6AQ&pp=ygUSTmF0dXJhbCB0b290aHBhc3Rl&t=681)
- He doesn't rinse out mouth after brushing but when have flouride toothpaste you should spit it out right away
