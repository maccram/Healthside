---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Stimulated Neuron: ^x1cv7DhA

Axon ^RtUHPBBq

- ^VXCvWCuP

- ^1JYIJxOy

+ ^awUIMfqz

+ ^sT5iQnpv

+ ^gs3gG3sO

+ ^BeRqr2O9

Membran ^d7LnB3EV

+ ^i6ys19nw

+ ^h9Fm3hff

- When stimulated little gaps open in membran
- Sodium from outside rushes into the cell
- The neurons negativ charge turns into positiv ^9KEnRtIk

If enough positiv charge fires also Action Potential
 ^IsvUD0G0

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.17",
	"elements": [
		{
			"type": "text",
			"version": 109,
			"versionNonce": 118629533,
			"isDeleted": false,
			"id": "x1cv7DhA",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -357.6335901245658,
			"y": -233.57645908788265,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 183.1198272705078,
			"height": 25,
			"seed": 2139044637,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Stimulated Neuron:",
			"rawText": "Stimulated Neuron:",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Stimulated Neuron:",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "ellipse",
			"version": 413,
			"versionNonce": 1442679037,
			"isDeleted": false,
			"id": "GUgRSxqjfn8WZC1qSJzvZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -228.61606128088022,
			"y": -56.932975678152275,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 93.11279296875,
			"height": 83.984130859375,
			"seed": 495177597,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "nFMVjb0-ITMH4idW-WxvB",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 371,
			"versionNonce": 1721970109,
			"isDeleted": false,
			"id": "n5Ahf8seY3iM2kVbJF3LG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.9982634293178,
			"y": -96.18639364690227,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 178.009765625,
			"height": 157.9266357421875,
			"seed": 1253496797,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 469,
			"versionNonce": 1825599005,
			"isDeleted": false,
			"id": "Q994MC7p9HSLsAyOg1fEn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.06759936681772,
			"y": -24.982475189871025,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 213.6116943359375,
			"height": 61.162353515625,
			"seed": 19518525,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					81.2454833984375,
					-20.99603271484375
				],
				[
					124.150390625,
					-61.162353515625
				],
				[
					213.6116943359375,
					-54.772247314453125
				]
			]
		},
		{
			"type": "text",
			"version": 331,
			"versionNonce": 1345757821,
			"isDeleted": false,
			"id": "RtUHPBBq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.787168229717064,
			"x": -57.90927417150522,
			"y": -112.6180647894804,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 44.77996826171875,
			"height": 25,
			"seed": 2092844189,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Axon",
			"rawText": "Axon",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Axon",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 365,
			"versionNonce": 1704413917,
			"isDeleted": false,
			"id": "VXCvWCuP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.092549224846619,
			"x": -204.60129077306772,
			"y": -34.11115255803509,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 8.219985961914062,
			"height": 25,
			"seed": 19245309,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "-",
			"rawText": "-",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "-",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 414,
			"versionNonce": 1837360957,
			"isDeleted": false,
			"id": "1JYIJxOy",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.3512493616960928,
			"x": -172.38987262121225,
			"y": -46.97936239690239,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 8.219985961914062,
			"height": 25,
			"seed": 1608614237,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "5NnsIpV-impwrDEcI2ZNj",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "-",
			"rawText": "-",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "-",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 288,
			"versionNonce": 1448541181,
			"isDeleted": false,
			"id": "awUIMfqz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -243.85470874181772,
			"y": -67.88739767522259,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 1044598205,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 345,
			"versionNonce": 1232106589,
			"isDeleted": false,
			"id": "sT5iQnpv",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.4727829736763862,
			"x": -232.14944006755798,
			"y": 4.7741465136952,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 460099101,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 342,
			"versionNonce": 528212157,
			"isDeleted": false,
			"id": "gs3gG3sO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -205.59110973512122,
			"y": -3.244330207730968,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 374260349,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "v5-f9PRWJE8YTu4eXjWF6",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 320,
			"versionNonce": 236634397,
			"isDeleted": false,
			"id": "BeRqr2O9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.36361987463022,
			"y": -70.73967733830852,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 1940613853,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "freedraw",
			"version": 109,
			"versionNonce": 448697725,
			"isDeleted": false,
			"id": "cFEXxGVEqjzl9CCPOat0E",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -102.8816455907762,
			"y": 114.39371499567585,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0001,
			"height": 0.0001,
			"seed": 1679034173,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 109,
			"versionNonce": 547937757,
			"isDeleted": false,
			"id": "eO-42wl1PnAXT1KFZrnwS",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -373.0913623876512,
			"y": -123.86556234807415,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0001,
			"height": 0.0001,
			"seed": 166336413,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 109,
			"versionNonce": 384506429,
			"isDeleted": false,
			"id": "-vJ2qyKsbVZNDeWbJDMhh",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 18.530219643598798,
			"y": 110.74222573786335,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0001,
			"height": 0.0001,
			"seed": 1063197693,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "arrow",
			"version": 363,
			"versionNonce": 271196915,
			"isDeleted": false,
			"id": "nFMVjb0-ITMH4idW-WxvB",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -305.53899040889144,
			"y": -92.82796469182415,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 77.593994140625,
			"height": 66.63958740234375,
			"seed": 477402205,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1718305041924,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "d7LnB3EV",
				"focus": 0.28203271031999944,
				"gap": 6.711883544921875
			},
			"endBinding": {
				"elementId": "GUgRSxqjfn8WZC1qSJzvZ",
				"focus": -0.4856584626890113,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					77.593994140625,
					66.63958740234375
				]
			]
		},
		{
			"type": "text",
			"version": 158,
			"versionNonce": 533556989,
			"isDeleted": false,
			"id": "d7LnB3EV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -344.79240837764144,
			"y": -119.53984823674602,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 64.2879638671875,
			"height": 20,
			"seed": 1023148221,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "nFMVjb0-ITMH4idW-WxvB",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Membran",
			"rawText": "Membran",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Membran",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "freedraw",
			"version": 60,
			"versionNonce": 1043436477,
			"isDeleted": false,
			"id": "bx6zVPfheklc0xiWuGs54",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -107.61735038236975,
			"y": -209.63610778797818,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.4393317787223623,
			"height": 0.43934646619828754,
			"seed": 1184293149,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.4393317787223623,
					-0.43934646619828754
				],
				[
					0.4393317787223623,
					-0.43934646619828754
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 121,
			"versionNonce": 1369576477,
			"isDeleted": false,
			"id": "mkOAZie25NqW8ZoF5Sfgl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -159.62851992239746,
			"y": 17.495331523375114,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 4.393435287031139,
			"height": 4.832796440705295,
			"seed": 783725949,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.43933177872241913
				],
				[
					0,
					0.8786929323965751
				],
				[
					0,
					1.3180247111189942
				],
				[
					0,
					1.7573564898414133
				],
				[
					0.439331778722476,
					2.1967176435155693
				],
				[
					0.8786635574448383,
					2.1967176435155693
				],
				[
					1.3179953361672005,
					2.1967176435155693
				],
				[
					2.196717643515626,
					3.0754105759121444
				],
				[
					2.6360494222379884,
					3.0754105759121444
				],
				[
					2.6360494222379884,
					3.5147423546345635
				],
				[
					2.6360494222379884,
					3.9541035083087195
				],
				[
					2.6360494222379884,
					4.393435287031139
				],
				[
					3.514771729586414,
					4.393435287031139
				],
				[
					3.9541035083087763,
					4.832796440705295
				],
				[
					4.393435287031139,
					4.832796440705295
				],
				[
					4.393435287031139,
					4.832796440705295
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 176,
			"versionNonce": 937658493,
			"isDeleted": false,
			"id": "fT_ZRMU91aXVcDXqE-L6Z",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.9302209759495,
			"y": -58.950836095320255,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 9.226261102688227,
			"height": 10.983646967481377,
			"seed": 1084030429,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.4393317787223907
				],
				[
					0,
					0.8786929323965751
				],
				[
					0,
					1.7573858647931502
				],
				[
					0,
					2.63604942223796
				],
				[
					0,
					3.0754105759121444
				],
				[
					0,
					4.39343528703111
				],
				[
					0,
					5.71148937310187
				],
				[
					0,
					6.150821151824289
				],
				[
					0,
					7.029514084220864
				],
				[
					0,
					7.46887523789502
				],
				[
					0,
					7.908207016617439
				],
				[
					-0.8786635574448383,
					8.347568170291623
				],
				[
					-0.8786635574448383,
					8.786899949014014
				],
				[
					-0.8786635574448383,
					9.226261102688198
				],
				[
					-1.318054086070788,
					9.226261102688198
				],
				[
					-1.318054086070788,
					8.347568170291623
				],
				[
					-1.318054086070788,
					6.590182305498445
				],
				[
					-0.8786635574448383,
					5.71148937310187
				],
				[
					-0.439331778722476,
					4.39343528703111
				],
				[
					0,
					3.9541035083087195
				],
				[
					0.8786635574448383,
					2.63604942223796
				],
				[
					0.8786635574448383,
					1.7573858647931502
				],
				[
					1.3180540860706742,
					1.7573858647931502
				],
				[
					2.1967176435155125,
					0.8786929323965751
				],
				[
					2.1967176435155125,
					0.4393317787223907
				],
				[
					2.6360494222379884,
					0.4393317787223907
				],
				[
					3.5147717295863004,
					-0.4393611536741844
				],
				[
					3.5147717295863004,
					-0.8786929323966035
				],
				[
					3.5147717295863004,
					-1.3180540860707595
				],
				[
					4.393435287031139,
					-1.7573858647931786
				],
				[
					4.393435287031139,
					-1.3180540860707595
				],
				[
					4.393435287031139,
					0
				],
				[
					3.9541035083086626,
					0.4393317787223907
				],
				[
					3.9541035083086626,
					1.3180247111189658
				],
				[
					3.075439950863938,
					2.196717643515541
				],
				[
					2.1967176435155125,
					3.514742354634535
				],
				[
					2.1967176435155125,
					4.832796440705295
				],
				[
					2.1967176435155125,
					5.71148937310187
				],
				[
					1.3180540860706742,
					6.590182305498445
				],
				[
					1.3180540860706742,
					7.46887523789502
				],
				[
					1.3180540860706742,
					7.908207016617439
				],
				[
					1.3180540860706742,
					8.347568170291623
				],
				[
					1.7573858647931502,
					8.347568170291623
				],
				[
					2.6360494222379884,
					8.347568170291623
				],
				[
					3.075439950863938,
					8.347568170291623
				],
				[
					3.5147717295863004,
					7.908207016617439
				],
				[
					3.9541035083086626,
					7.029514084220864
				],
				[
					4.393435287031139,
					6.150821151824289
				],
				[
					4.393435287031139,
					5.272128219427685
				],
				[
					4.393435287031139,
					4.832796440705295
				],
				[
					5.2721575943794505,
					3.514742354634535
				],
				[
					5.711489373101813,
					2.196717643515541
				],
				[
					6.150821151824289,
					1.7573858647931502
				],
				[
					6.150821151824289,
					1.3180247111189658
				],
				[
					7.029543459172601,
					0.8786929323965751
				],
				[
					7.029543459172601,
					0
				],
				[
					7.908207016617439,
					-0.8786929323966035
				],
				[
					7.908207016617439,
					-1.3180540860707595
				],
				[
					7.908207016617439,
					-0.8786929323966035
				],
				[
					7.908207016617439,
					0.4393317787223907
				],
				[
					7.908207016617439,
					0.8786929323965751
				],
				[
					7.908207016617439,
					1.7573858647931502
				],
				[
					7.468875237895077,
					3.0754105759121444
				],
				[
					7.468875237895077,
					3.9541035083087195
				],
				[
					6.150821151824289,
					5.71148937310187
				],
				[
					5.711489373101813,
					6.590182305498445
				],
				[
					5.711489373101813,
					7.46887523789502
				],
				[
					5.2721575943794505,
					7.46887523789502
				],
				[
					5.2721575943794505,
					7.908207016617439
				],
				[
					5.2721575943794505,
					8.786899949014014
				],
				[
					5.2721575943794505,
					8.786899949014014
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 177,
			"versionNonce": 1387753693,
			"isDeleted": false,
			"id": "lw_p-_NiZnKFc43i0RXRE",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -214.54675475980423,
			"y": -52.36065378982187,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.498418697067677,
			"height": 19.77054691649539,
			"seed": 1666923069,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.43933177872241913
				],
				[
					0.8786635574448383,
					0.43933177872241913
				],
				[
					1.318054086070788,
					0.43933177872241913
				],
				[
					2.6360494222379884,
					1.3180247111189942
				],
				[
					3.075439950863938,
					2.1967176435155693
				],
				[
					3.9541035083086626,
					3.5147717295863288
				],
				[
					5.2721575943794505,
					4.393464661982904
				],
				[
					5.7114893731019265,
					6.150821151824289
				],
				[
					6.590152930546651,
					7.468875237895048
				],
				[
					6.590152930546651,
					8.347568170291623
				],
				[
					7.029543459172601,
					8.786899949014042
				],
				[
					7.468875237895077,
					9.226261102688227
				],
				[
					7.468875237895077,
					8.786899949014042
				],
				[
					7.468875237895077,
					7.908207016617467
				],
				[
					7.468875237895077,
					7.029514084220864
				],
				[
					7.468875237895077,
					6.150821151824289
				],
				[
					7.468875237895077,
					4.832796440705323
				],
				[
					7.029543459172601,
					4.832796440705323
				],
				[
					6.150821151824289,
					3.0754105759121444
				],
				[
					5.7114893731019265,
					1.7573858647931786
				],
				[
					5.2721575943794505,
					0.43933177872241913
				],
				[
					5.2721575943794505,
					-0.8786929323965751
				],
				[
					5.2721575943794505,
					-1.7573858647931502
				],
				[
					5.2721575943794505,
					-2.6360787971897253
				],
				[
					5.2721575943794505,
					-3.5147717295863004
				],
				[
					5.2721575943794505,
					-3.0754399508639096
				],
				[
					5.2721575943794505,
					-2.1967470184673346
				],
				[
					5.2721575943794505,
					-1.7573858647931502
				],
				[
					5.2721575943794505,
					-0.43936115367415596
				],
				[
					5.2721575943794505,
					0.43933177872241913
				],
				[
					5.7114893731019265,
					0.43933177872241913
				],
				[
					6.590152930546651,
					1.3180247111189942
				],
				[
					6.590152930546651,
					1.7573858647931786
				],
				[
					6.590152930546651,
					3.0754105759121444
				],
				[
					6.590152930546651,
					3.5147717295863288
				],
				[
					7.468875237895077,
					4.393464661982904
				],
				[
					7.468875237895077,
					5.272157594379479
				],
				[
					8.347538795339801,
					5.711489373101898
				],
				[
					8.347538795339801,
					7.029514084220864
				],
				[
					8.347538795339801,
					7.908207016617467
				],
				[
					9.226261102688227,
					8.786899949014042
				],
				[
					9.226261102688227,
					9.226261102688227
				],
				[
					9.226261102688227,
					8.786899949014042
				],
				[
					8.78692932396575,
					8.347568170291623
				],
				[
					7.029543459172601,
					7.908207016617467
				],
				[
					5.7114893731019265,
					7.468875237895048
				],
				[
					4.832767065753501,
					7.029514084220864
				],
				[
					2.6360494222379884,
					6.590182305498473
				],
				[
					1.7573858647931502,
					6.150821151824289
				],
				[
					0.4393317787223623,
					5.272157594379479
				],
				[
					-1.318054086070788,
					5.272157594379479
				],
				[
					-1.7573858647931502,
					4.393464661982904
				],
				[
					-2.636108172141576,
					4.393464661982904
				],
				[
					-3.5147717295863004,
					4.393464661982904
				],
				[
					-4.393494036934726,
					4.393464661982904
				],
				[
					-4.832825815657088,
					4.393464661982904
				],
				[
					-5.2721575943794505,
					4.393464661982904
				],
				[
					-3.9541035083087763,
					4.393464661982904
				],
				[
					-3.5147717295863004,
					4.393464661982904
				],
				[
					-2.636108172141576,
					4.832796440705323
				],
				[
					-1.7573858647931502,
					6.150821151824289
				],
				[
					-0.439331778722476,
					6.590182305498473
				],
				[
					1.318054086070788,
					8.786899949014042
				],
				[
					1.318054086070788,
					9.226261102688227
				],
				[
					2.6360494222379884,
					11.422978746203768
				],
				[
					3.9541035083086626,
					12.301671678600371
				],
				[
					4.393435287031139,
					13.180364610996946
				],
				[
					5.2721575943794505,
					14.498418697067706
				],
				[
					5.2721575943794505,
					14.937750475790097
				],
				[
					5.7114893731019265,
					15.377082254512516
				],
				[
					6.150821151824289,
					16.25577518690909
				],
				[
					6.150821151824289,
					16.25577518690909
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 188,
			"versionNonce": 1336888637,
			"isDeleted": false,
			"id": "aZXfcjVGE3AQagF12Omv2",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.43180227888183,
			"y": 15.298584504907808,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.301642303648578,
			"height": 16.255775186909034,
			"seed": 533916317,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.43933177872241913
				],
				[
					0.8786635574448383,
					-1.3180247111189942
				],
				[
					1.7573858647931502,
					-1.3180247111189942
				],
				[
					2.1967176435155125,
					-1.3180247111189942
				],
				[
					2.6360494222379884,
					-1.3180247111189942
				],
				[
					3.075439950863938,
					-1.3180247111189942
				],
				[
					3.5147717295863004,
					-0.8786929323966319
				],
				[
					3.9541035083086626,
					0
				],
				[
					4.393435287031139,
					0.8786929323965751
				],
				[
					4.832767065753501,
					1.7573858647931502
				],
				[
					5.2721575943794505,
					2.6360787971897253
				],
				[
					5.711489373101813,
					3.0754399508638812
				],
				[
					6.590152930546651,
					4.832796440705295
				],
				[
					7.029543459172601,
					5.71148937310187
				],
				[
					7.908207016617439,
					7.46887523789502
				],
				[
					8.347538795339801,
					7.46887523789502
				],
				[
					8.347538795339801,
					7.908236391569176
				],
				[
					8.347538795339801,
					8.347568170291595
				],
				[
					8.347538795339801,
					9.22626110268817
				],
				[
					8.347538795339801,
					9.665622256362383
				],
				[
					7.468875237894963,
					9.665622256362383
				],
				[
					6.590152930546651,
					9.665622256362383
				],
				[
					5.2721575943794505,
					9.665622256362383
				],
				[
					3.5147717295863004,
					8.78692932396575
				],
				[
					2.6360494222379884,
					8.78692932396575
				],
				[
					1.318054086070788,
					7.908236391569176
				],
				[
					1.318054086070788,
					7.46887523789502
				],
				[
					-0.4393317787223623,
					6.150850526776026
				],
				[
					-1.318054086070788,
					5.71148937310187
				],
				[
					-1.7573858647931502,
					4.832796440705295
				],
				[
					-2.196717643515626,
					3.9541035083087195
				],
				[
					-2.636108172141576,
					3.9541035083087195
				],
				[
					-3.5147717295863004,
					3.9541035083087195
				],
				[
					-3.9541035083087763,
					3.9541035083087195
				],
				[
					-3.9541035083087763,
					4.393464661982875
				],
				[
					-3.9541035083087763,
					4.832796440705295
				],
				[
					-3.9541035083087763,
					5.2721575943794505
				],
				[
					-3.9541035083087763,
					5.71148937310187
				],
				[
					-3.9541035083087763,
					6.150850526776026
				],
				[
					-3.9541035083087763,
					6.590182305498445
				],
				[
					-3.9541035083087763,
					7.908236391569176
				],
				[
					-3.5147717295863004,
					8.78692932396575
				],
				[
					-3.075439950863938,
					9.22626110268817
				],
				[
					-3.075439950863938,
					10.544315188758958
				],
				[
					-3.075439950863938,
					11.423008121155533
				],
				[
					-2.636108172141576,
					11.862339899877895
				],
				[
					-2.196717643515626,
					12.301701053552108
				],
				[
					-1.7573858647931502,
					12.741032832274527
				],
				[
					-1.318054086070788,
					12.741032832274527
				],
				[
					-0.8787223073484256,
					12.741032832274527
				],
				[
					-0.8787223073484256,
					12.301701053552108
				],
				[
					0,
					12.301701053552108
				],
				[
					0,
					11.423008121155533
				],
				[
					0,
					10.544315188758958
				],
				[
					0,
					9.665622256362383
				],
				[
					0,
					8.347568170291595
				],
				[
					0,
					7.46887523789502
				],
				[
					0.8786635574448383,
					7.029543459172601
				],
				[
					0.8786635574448383,
					5.71148937310187
				],
				[
					1.318054086070788,
					4.393464661982875
				],
				[
					1.318054086070788,
					2.6360787971897253
				],
				[
					1.318054086070788,
					1.318054086070731
				],
				[
					1.318054086070788,
					0.43936115367415596
				],
				[
					1.318054086070788,
					0
				],
				[
					1.318054086070788,
					-0.43933177872241913
				],
				[
					1.318054086070788,
					-0.8786929323966319
				],
				[
					1.7573858647931502,
					-0.8786929323966319
				],
				[
					2.1967176435155125,
					-0.43933177872241913
				],
				[
					2.1967176435155125,
					0
				],
				[
					2.1967176435155125,
					0.8786929323965751
				],
				[
					2.1967176435155125,
					2.6360787971897253
				],
				[
					2.1967176435155125,
					3.0754399508638812
				],
				[
					2.1967176435155125,
					4.393464661982875
				],
				[
					2.1967176435155125,
					5.2721575943794505
				],
				[
					3.075439950863938,
					6.590182305498445
				],
				[
					3.075439950863938,
					7.908236391569176
				],
				[
					3.9541035083086626,
					9.22626110268817
				],
				[
					4.832767065753501,
					10.98364696748132
				],
				[
					4.832767065753501,
					12.301701053552108
				],
				[
					4.832767065753501,
					12.741032832274527
				],
				[
					4.832767065753501,
					14.059057543393465
				],
				[
					4.832767065753501,
					14.93775047579004
				],
				[
					4.832767065753501,
					14.93775047579004
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 186,
			"versionNonce": 774675869,
			"isDeleted": false,
			"id": "duH75nAfnR5jiJk4SBxm-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.18376714694023,
			"y": 2.9969128263074367,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.61975513962284,
			"height": 16.25577518690909,
			"seed": 1723174653,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.8786929323965751
				],
				[
					-0.4393317787223623,
					1.3180247111189942
				],
				[
					-1.318054086070788,
					1.3180247111189942
				],
				[
					-3.075439950863938,
					2.6360787971897253
				],
				[
					-3.075439950863938,
					3.5147717295863004
				],
				[
					-4.393494036934726,
					3.9541035083087195
				],
				[
					-5.2721575943794505,
					4.393464661982875
				],
				[
					-5.2721575943794505,
					4.832796440705295
				],
				[
					-6.150821151824289,
					5.2721575943794505
				],
				[
					-6.150821151824289,
					5.71148937310187
				],
				[
					-6.590211680450238,
					5.71148937310187
				],
				[
					-6.590211680450238,
					6.590182305498445
				],
				[
					-6.590211680450238,
					7.029514084220864
				],
				[
					-5.2721575943794505,
					7.029514084220864
				],
				[
					-4.832825815657088,
					7.029514084220864
				],
				[
					-3.9541035083086626,
					7.029514084220864
				],
				[
					-3.075439950863938,
					7.029514084220864
				],
				[
					-2.1967176435155125,
					7.029514084220864
				],
				[
					-1.318054086070788,
					7.029514084220864
				],
				[
					-0.8787223073483119,
					6.1508505267760825
				],
				[
					0.8786635574448383,
					4.832796440705295
				],
				[
					0.8786635574448383,
					3.9541035083087195
				],
				[
					1.7573858647931502,
					3.0754105759121444
				],
				[
					1.7573858647931502,
					2.1967176435155693
				],
				[
					2.6360494222379884,
					1.7573858647931502
				],
				[
					2.6360494222379884,
					2.6360787971897253
				],
				[
					2.1967176435155125,
					2.6360787971897253
				],
				[
					2.1967176435155125,
					3.5147717295863004
				],
				[
					1.7573858647931502,
					3.5147717295863004
				],
				[
					0.8786635574448383,
					4.393464661982875
				],
				[
					0.8786635574448383,
					4.832796440705295
				],
				[
					0.4393317787223623,
					5.71148937310187
				],
				[
					0,
					7.029514084220864
				],
				[
					0,
					7.908207016617439
				],
				[
					0,
					10.544285813807164
				],
				[
					0,
					11.42297874620374
				],
				[
					0,
					12.301671678600371
				],
				[
					0,
					14.059057543393521
				],
				[
					0,
					14.498418697067677
				],
				[
					0,
					15.377111629464252
				],
				[
					0,
					15.816443408186672
				],
				[
					0,
					16.25577518690909
				],
				[
					0.4393317787223623,
					16.25577518690909
				],
				[
					0.8786635574448383,
					16.25577518690909
				],
				[
					0.8786635574448383,
					15.816443408186672
				],
				[
					1.7573858647931502,
					14.498418697067677
				],
				[
					2.1967176435155125,
					13.619725764671102
				],
				[
					2.6360494222379884,
					11.862339899877952
				],
				[
					3.075439950863938,
					11.42297874620374
				],
				[
					3.5147717295863004,
					10.544285813807164
				],
				[
					4.393435287031139,
					9.226261102688227
				],
				[
					4.832767065753501,
					8.786899949014014
				],
				[
					5.2721575943794505,
					8.786899949014014
				],
				[
					5.2721575943794505,
					7.908207016617439
				],
				[
					6.150821151824289,
					7.908207016617439
				],
				[
					6.150821151824289,
					7.029514084220864
				],
				[
					6.150821151824289,
					7.46887523789502
				],
				[
					5.7114893731019265,
					8.347568170291595
				],
				[
					5.2721575943794505,
					9.226261102688227
				],
				[
					4.832767065753501,
					10.104954035084802
				],
				[
					4.832767065753501,
					10.983646967481377
				],
				[
					4.832767065753501,
					12.301671678600371
				],
				[
					4.832767065753501,
					12.741032832274527
				],
				[
					4.832767065753501,
					13.619725764671102
				],
				[
					4.832767065753501,
					14.498418697067677
				],
				[
					4.393435287031139,
					14.937750475790097
				],
				[
					4.393435287031139,
					15.377111629464252
				],
				[
					4.393435287031139,
					16.25577518690909
				],
				[
					4.832767065753501,
					16.25577518690909
				],
				[
					5.2721575943794505,
					16.25577518690909
				],
				[
					5.2721575943794505,
					14.937750475790097
				],
				[
					6.150821151824289,
					14.059057543393521
				],
				[
					6.150821151824289,
					12.741032832274527
				],
				[
					7.029543459172601,
					12.741032832274527
				],
				[
					7.029543459172601,
					11.862339899877952
				],
				[
					7.029543459172601,
					10.983646967481377
				],
				[
					7.029543459172601,
					10.544285813807164
				],
				[
					7.029543459172601,
					10.104954035084802
				],
				[
					7.029543459172601,
					9.66559288141059
				],
				[
					7.029543459172601,
					9.226261102688227
				],
				[
					7.029543459172601,
					9.226261102688227
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "text",
			"version": 362,
			"versionNonce": 90235389,
			"isDeleted": false,
			"id": "i6ys19nw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -159.60591022052074,
			"y": 25.202507723029782,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 377792349,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 391,
			"versionNonce": 172857949,
			"isDeleted": false,
			"id": "h9Fm3hff",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -170.39227501189237,
			"y": -5.671770963796462,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12.5,
			"height": 25,
			"seed": 1100067773,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "v5-f9PRWJE8YTu4eXjWF6",
					"type": "arrow"
				},
				{
					"id": "5NnsIpV-impwrDEcI2ZNj",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+",
			"rawText": "+",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 1013,
			"versionNonce": 194921011,
			"isDeleted": false,
			"id": "v5-f9PRWJE8YTu4eXjWF6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -81.69567081408786,
			"y": 68.2261153681444,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 68.59457576580189,
			"height": 44.95251841781203,
			"seed": 872297501,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1718305041925,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "9KEnRtIk",
				"focus": -0.31399226953506904,
				"gap": 1.1416492617304357
			},
			"endBinding": {
				"elementId": "h9Fm3hff",
				"focus": 0.44394407698921223,
				"gap": 7.602028432002612
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-68.59457576580189,
					-44.95251841781203
				]
			]
		},
		{
			"type": "text",
			"version": 511,
			"versionNonce": 2057665405,
			"isDeleted": false,
			"id": "9KEnRtIk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -148.52954825688005,
			"y": 69.36776462987484,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 375.29583740234375,
			"height": 60,
			"seed": 968599677,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "v5-f9PRWJE8YTu4eXjWF6",
					"type": "arrow"
				}
			],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "- When stimulated little gaps open in membran\n- Sodium from outside rushes into the cell\n- The neurons negativ charge turns into positiv",
			"rawText": "- When stimulated little gaps open in membran\n- Sodium from outside rushes into the cell\n- The neurons negativ charge turns into positiv",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "- When stimulated little gaps open in membran\n- Sodium from outside rushes into the cell\n- The neurons negativ charge turns into positiv",
			"lineHeight": 1.25,
			"baseline": 54
		},
		{
			"type": "arrow",
			"version": 233,
			"versionNonce": 1839039443,
			"isDeleted": false,
			"id": "5NnsIpV-impwrDEcI2ZNj",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.93477890441773,
			"y": -159.4512948420196,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 53.57487699620333,
			"height": 137.5447621007657,
			"seed": 613126365,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1718305041925,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "1JYIJxOy",
				"focus": -1.1392971635594902,
				"gap": 2.824948584497591
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-53.57487699620333,
					137.5447621007657
				]
			]
		},
		{
			"type": "text",
			"version": 257,
			"versionNonce": 347041949,
			"isDeleted": false,
			"id": "IsvUD0G0",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -209.78379681973126,
			"y": -185.0594618627823,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 410.2717590332031,
			"height": 40,
			"seed": 301952317,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1718305041904,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "If enough positiv charge fires also Action Potential\n",
			"rawText": "If enough positiv charge fires also Action Potential\n",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "If enough positiv charge fires also Action Potential\n",
			"lineHeight": 1.25,
			"baseline": 34
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 703.3670043945312,
		"scrollY": 431.8735046386719,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%