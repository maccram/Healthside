---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# The app that got me back to waking up early
- Basically the problem i had was that once i got used to hitting the snooze button it was much harder to go back to waking up early. 
- So ideally you shouldn't ever start hitting it but probably that's not the reality.
- But i have a solution that helped me get back to waking up early without much effort.
- All the credits goes to Iman gadzhi he actually mentioned the app in one of his old videos.
# How to set up the app.
- The app I'm referring to is [Alarmy](https://alar.my/). Its basically a normal alarm app on steroids. And its completely free.
- First download the app and follow the next instructions.
## Step 1:
- Set up the time wake up.
- Set a eighter the barcode or photo challenge, go to your bathroom and eighter scan a barcode or make a photo that you can easily recreate every time you wake up. I use a photo of my sink.
- Then turn off the snooze function.
- So what all that does is that if the alarm goes off you only can turn it off by the challenge and you need to get up and go to your bathroom in order to do it.
## Step 2:
- Enjoy waking up at the times you want. Literally that's al that you need.
