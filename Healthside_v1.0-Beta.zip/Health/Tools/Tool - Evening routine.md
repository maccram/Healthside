---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Evening routine
- Shut down ritual:
	- Have some sort of steps you follow to wind down from work. So reflect on the day, plan what to do the next day. And most important don't work after it.
- Journaling + bed time tea:
	- The previous step goes hand in hand with this step. You'll use Journaling to get all your thoughts out.
	- Combined with journaling I'll drink my bed time tea which is [[Chamomile|chamomile]]. 
- Stretching/Mobility (optional):
	- You can eighter stretch through the day while making breaks of work or you can have a own session for it. The best time for such a session would be the evening.
- Meditation:
	- 10 min meditation or more depending on your preference.

# Rules for better sleep:
- First of all you should use the [[Sleep#The 12 3 2 1 0 Rule|12 3 2 1 0 rule]] as a guideline this will make things more easy.
- Also avoid blue and bright light (every light if bright enough will disrupt your sleep).
	- Could use blue light blockers (3-30 min before sleep)    Have to look more into it
	- Dim the lights and its better to have the lights set up on the floor then the roof.
- No caffein within 12h before bed.
## Related to:
- [[Sleep]]
## Tags:

