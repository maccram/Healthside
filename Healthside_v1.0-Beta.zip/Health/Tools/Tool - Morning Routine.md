---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Morning routine
- Wake up
	- Without hitting the snooze button (if can't try this: [[Tool - Waking up early the easy way]])
- Dream journal (optional):
	- I journal my dreams to later on get into lucid dreaming
- Get sunlight, ground yourself, do a breathwork session
	- Sunlight:
		- Best to get the sunlight of the first 45 min after sun rise.
	- Grounding:
		- Touch grass/dirt/sand simply the ground.
			- Does the same then [[PEMF matt]].
	- Breathwork:
		- Best also within 30 min after waking.
		- Use wim hof type one mentioned here: [[Tool - Breathwork]]
	- So basically you want to get outside stand barefoot on the ground and do your breathing exercise.
- Cold shower
	- Before the cold shower/plunge you can do a warm shower before if you want.
	- Do it for 3-6min of 8-10 degree Celsius
	- Hit the head, back of your neck and your back.
	- After it warm up naturally.
- **Start your day.**

- You can also change the order if you wish to but I would do the sunlight, grounding and breathwork together then you get 3 things at once. 
- Additionally you can also add affirmations somewhere if that's what you like to do.
# Caffein intake
- Wait for 90-120 minutes after waking for caffein intake.
- Why: [[Caffeine]]
## Related to:
- [[+He Can Predict When YOU DIE How To HEAL Your Inflammation & Fix Your Health - Gary Brecka]]
- [[Cold Exposure]]
- [[Sleep]]
- [[Light and its Health benefits]]
- [[Breathwork]]
- [[Grounding]]
## Tags:
  