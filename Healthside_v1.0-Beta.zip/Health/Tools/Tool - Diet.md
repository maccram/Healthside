---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# What to cut out:
- As already seen in the note [[The modern diet and its problems]].
- We want to cut out:
	- Ultra processed food with carbohydrates
	- Sugar and added sugar
	- Seed oils:
- And want to change to better options:
	- Changing the omega 6 to omega 3 ratio
	- Healthy fat from animal sources
	- With meat eat organ food cause its rich of nutrients
	- For carbs we want to get them from fruit, honey. (150g and for active people 350g)
# Vegetables
- For now I'll probably also reduce them cause i know they have high amounts of defense chemicals in them. I only will use onion, garlic, avocado and maybe brussel sprouts.
## Related to:
- [[How metabolism works]]
- [[Omega 3 vs Omega 6]]
- [[+Dr. Paul Saladino's Animal-Based Diet 101 - A step-by-step guide]]
## Tags:


# THIS WILL BE UPDATED IN NEAR FUTURE IN MORE DETAIL