---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Breathwork as a tool:
- Wim Hof style breathwork:
	- Beginner:
		- Start with 3 rounds of 5 breaths add 1 breath a day (Goal: 3 rounds 30)
		- Everything else is the same.
	- Advanced:
		- 3 rounds of 30 breaths
		- On 30th breath exhale fully and hold. Then when you can't hold anymore take deep breath and hold again. Then breath normally and start the next round.
			- Also put your tongue on the top of your mouth when holding the breath
			- When holding the breath breath and focus on noise around and try to get out of head.
		- For most efficiency try to use the entire lung and your diaphragm. You should also raise your shoulders and put your belly out.
	- This should be a part of your routine that you never miss. And its like exercise over time you'll get better at it.
## ==Important==
- **Do it in a sitting or lying position** because its normal that you get light headed.
- You'll also probably get tingly hands and feet.

## Related to:
- [[Breathwork]]
- [[+Breathwork - Ultimate Human Short]]
## Tags:
  