---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# Hydration:
- Add pinch of salt (baja sea salt, celtic salt) to water (for minerals, need to look more into that)
- ![[Water#Hydration]]
# The why behind it:
Go here: [[Water]]
## Related to:
- [[Water]]
## Tags:
  