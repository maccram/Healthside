---
"up:": 
tags:
  - 📝/⭐
aliases:
---
# How:
## Brushing:
- At least twice daily
- Soft toothbrush (medium/hard ones disrupt the gum)
- Circular motions and not to much pressure
- Brush the gum lightly (increase blood flow thus it better takes up nutrients, especially if sensitive teeth)
## Flossing
- At least twice daily
- Glide down and go up with a circular motion
## Tongue Brushing:
- You can eighter use a separater toothbrush or a tongue scrubber.
- You need to use both with low force but especially the tongue scrub.
# When:
## Morning
- I would recommend putting it after the [[morning routine]] to not waste the valuable time for sunlight exposure.
- For breakfast I'll rinse my mouth with water and maybe add a gum (zellies gum). (or even for morning don't know yet)
## Midday
- Put it after lunch.
## Evening
- You can eighter put it before, after or between the [[Tool - Evening routine]]. If you drink the tea though i would put it afterwards.
- The evening is the most important time to brush your teeth.

Whenever eating something and you aren't able or don't want to brush then rinse your mouth with water and get rid of food particles. 
## Acidic food:
- When you eat anything acidic you want to minimize the time your mouths pH is acidic so you should afterwards rinse the mouth with water
# The why behind it:
Here: [[Oral Health]]
# Recommended products 
- Here: [[Recommended Products#Tooth care|Products]]
## Related to:
- [[+How to Improve Oral Health & Its Critical Role in Brain & Body Health]]
- [[Oral Health]]
## Tags:
  